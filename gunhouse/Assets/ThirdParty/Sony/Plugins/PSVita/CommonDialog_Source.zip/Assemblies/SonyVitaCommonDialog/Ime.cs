using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace Vita
	{
		namespace Dialog
		{
			public class Ime
			{
				// ImeParam enterLabel
				public enum EnumImeDialogEnterLabel
				{
					ENTER_LABEL_DEFAULT,
					ENTER_LABEL_SEND,
					ENTER_LABEL_SEARCH,
					ENTER_LABEL_GO,
				}
				
				// ImeParam type
				public enum EnumImeDialogType
				{
					TYPE_DEFAULT,		    // UI for regular text input
					TYPE_BASIC_LATIN,	    // UI for alphanumeric character input
					TYPE_NUMBER,		    // UI for number input
					TYPE_EXTENDED_NUMBER,	// UI for extended number input
					TYPE_URL,	        	// UI for entering URL
					TYPE_MAIL,		        // UI for entering an email address
				}
				
				// ImeParam textBoxMode, can be OR'd together.
				[Flags] public enum FlagsTextBoxMode
				{
					TEXTBOX_MODE_DEFAULT = 0x00,       // Text box for regular sentence input
					TEXTBOX_MODE_PASSWORD = 0x01,      // Text box for password input
					TEXTBOX_MODE_WITH_CLEAR = 0x02,    // Text box with clear button
				};
				
				// ImeParam supported languages, can be OR'd together.
				[Flags] public enum FlagsSupportedLanguages
				{
					LANGUAGE_DANISH = 0x00000001,
					LANGUAGE_GERMAN = 0x00000002,
					LANGUAGE_ENGLISH_US = 0x00000004,
					LANGUAGE_SPANISH = 0x00000008,
					LANGUAGE_FRENCH = 0x00000010,
					LANGUAGE_ITALIAN = 0x00000020,
					LANGUAGE_DUTCH = 0x00000040,
					LANGUAGE_NORWEGIAN = 0x00000080,
					LANGUAGE_POLISH = 0x00000100,
					LANGUAGE_PORTUGUESE_PT = 0x00000200,
					LANGUAGE_RUSSIAN = 0x00000400,
					LANGUAGE_FINNISH = 0x00000800,
					LANGUAGE_SWEDISH = 0x00001000,
					LANGUAGE_JAPANESE = 0x00002000,
					LANGUAGE_KOREAN = 0x00004000,
					LANGUAGE_SIMPLIFIED_CHINESE = 0x00008000,
					LANGUAGE_TRADITIONAL_CHINESE = 0x00010000,
					LANGUAGE_PORTUGUESE_BR = 0x00020000,
					LANGUAGE_ENGLISH_GB = 0x00040000,
					LANGUAGE_TURKISH = 0x00080000,
				}

				// ImeParam option, can be OR'd together.
				[Flags] public enum FlagsTextBoxOption
				{
					OPTION_DEFAULT = 0x00,
					OPTION_MULTILINE = 0x01,              // Multiline input option. This option is not available for libime. This can be used only for the IME Dialog library.
					OPTION_NO_AUTO_CAPITALIZATION = 0x02, // Prohibits automatic capitalization
					OPTION_NO_ASSISTANCE = 0x04,          // Prohibits input assistance UIs, such as predictive text and conversion candidate
				}
				
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public class ImeDialogParams
				{
					public FlagsSupportedLanguages supportedLanguages;
					public bool languagesForced;
					public EnumImeDialogType type;
					public FlagsTextBoxOption option;
					public bool canCancel;
					public FlagsTextBoxMode textBoxMode;
					public EnumImeDialogEnterLabel enterLabel;
					public int maxTextLength;
					IntPtr _title;
					IntPtr _initialText;
					
					public string title
					{
						get { return Marshal.PtrToStringUni(_title); }
						set { _title = Marshal.StringToCoTaskMemUni(value); }
					}
					public string initialText
					{
						get { return Marshal.PtrToStringUni(_initialText); }
						set { _initialText = Marshal.StringToCoTaskMemUni(value); }
					}
					
					~ImeDialogParams()
					{
						Marshal.FreeCoTaskMem(_title);
						Marshal.FreeCoTaskMem(_initialText);
					}
				};
				
				public enum EnumImeDialogResult
				{
					RESULT_OK,				// User selected either close button or Enter button
					RESULT_USER_CANCELED,	// User performed cancel operation.
					RESULT_ABORTED,			// IME Dialog operation has been aborted.
				}
				
				public enum EnumImeDialogResultButton
				{
					BUTTON_NONE,	// IME Dialog operation has been aborted or canceled.
					BUTTON_CLOSE,	// User selected close button
					BUTTON_ENTER,	// User selected Enter button
				}
				
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public struct ImeDialogResult
				{
					public EnumImeDialogResult result;
					public EnumImeDialogResultButton button;
					IntPtr _text;
					public string text
					{
						get { return Marshal.PtrToStringAnsi(_text); }
					}
				};
				
				// Initialisation.
				[DllImport("CommonDialog")]
				private static extern int PrxImeDialogInitialise();
				
				// House keeping.
				[DllImport("CommonDialog")]
				private static extern void PrxImeDialogUpdate();
				
				// IME Dialog.
				[DllImport("CommonDialog")]
				private static extern bool PrxImeDialogIsDialogOpen();
				[DllImport("CommonDialog")]
				private static extern bool PrxImeDialogOpen(ImeDialogParams parameters);
				[DllImport("CommonDialog")]
				private static extern bool PrxImeDialogGetResult(out ImeDialogResult result);
				
				// Messages.
				[DllImport("CommonDialog")]
				private static extern bool PrxCommonDialogHasMessage();
				[DllImport("CommonDialog")]
				private static extern bool PrxCommonDialogGetFirstMessage(out Dialog.Messages.PluginMessage msg);
				[DllImport("CommonDialog")]
				private static extern bool PrxCommonDialogRemoveFirstMessage();
				
				// Event handlers.
				public static event Dialog.Messages.EventHandler OnGotIMEDialogResult;
				
				// Is the IME dialog open?
				public static bool IsDialogOpen
				{
					get { return PrxImeDialogIsDialogOpen(); }
				}

				public static bool Open(ImeDialogParams info)
				{
					bool ret = PrxImeDialogOpen(info);
					return ret;
				}
				
				public static ImeDialogResult GetResult()
				{
					ImeDialogResult result = new ImeDialogResult();
					PrxImeDialogGetResult(out result);
					return result;
				}
				
				public static void ProcessMessage(Dialog.Messages.PluginMessage msg)
				{
					// Interpret the message and trigger corresponding events.
					switch (msg.type)
					{
						case Dialog.Messages.MessageType.kDialog_GotIMEDialogResult:
						if (OnGotIMEDialogResult != null) OnGotIMEDialogResult(msg);
						break;
					}
				}
				
				public static void Initialise()
				{
					PrxImeDialogInitialise();
				}
				
				public static void Update()
				{
					PrxImeDialogUpdate();
	//				PumpMessages();
				}
			}
		} // Dialog
	} // Vita
} // Sony
