#ifndef _IMEDIALOG_H
#define _IMEDIALOG_H

//#include <np_toolkit.h>
#include <ime_dialog.h>
#include "prx.h"
#include "SimpleLock.h"

namespace UnityCommonDialog
{
	// IME Dialog Params, this is a class instead of a struct because we use a class in the C#
	// so that it can have a destructor to clean up memory allocated during marshaling. Strictly
	// speaking it doesn't matter in this native code but lets try and be consistent.
	class ImeDialogParams
	{
	public:
		int supportedLanguages;
		bool languagesForced;
		int type;
		int option;
		bool canCancel;
		int textBoxMode;
		int enterLabel;
		int maxTextLength;
		wchar_t* title;
		wchar_t* initialText;
	};

	struct ImeDialogResult
	{
		int result;
		int button;
		const char* text;
	};

	PRX_EXPORT bool PrxImeDialogIsDialogOpen();
	PRX_EXPORT bool PrxImeDialogOpen(ImeDialogParams* params);
	PRX_EXPORT bool PrxImeDialogGetResult(ImeDialogResult* result);

	typedef void(*ImeDialogResultCallback)(const SceImeDialogResult *result);

	class ImeDialog
	{
		SimpleLock m_Lock;
		bool m_DialogOpen;

		SceWChar16 m_ImeTitle[SCE_IME_DIALOG_MAX_TITLE_LENGTH];
		SceUInt32 m_ImeMaxTextLength;
		SceWChar16 m_ImeInitialText[SCE_IME_DIALOG_MAX_TEXT_LENGTH];
		SceWChar16 *m_ImeInputTextBuffer; /* needs (maxTextLength + 1) */
		ImeDialogResultCallback m_ResultCallback;

		// For use when calling directly from scripts.
		SceWChar16* m_DefaultInputBuffer;
		char* m_DefaultResultString;
		static void DefaultResultCallback(const SceImeDialogResult *result);

	public:
		struct Params
		{
			wchar_t* title;
			SceUInt32 maxTextLength;
			wchar_t* initialText;
			int supportedLanguages;
			bool languagesForced;
			int type;
			int option;
			bool canCancel;
			int textBoxMode;
			int enterLabel;
			SceWChar16 *inputTextBuffer;
			ImeDialogResultCallback callback;
		};

		ImeDialog();
		~ImeDialog();

		bool StartDialog(const ImeDialogParams* params);
		bool StartDialog(const Params& params);
		bool Update();
		bool IsDialogOpen() const { return m_DialogOpen; }

		// For use when calling directly from scripts.
		bool Get(ImeDialogResult* result);

	private:
		// For use when calling directly from scripts.
		Params m_CachedParams;
		ImeDialogResult m_CachedResult;
	};

	extern ImeDialog gImeDialog;
}

#endif // _IMEDIALOG_H
