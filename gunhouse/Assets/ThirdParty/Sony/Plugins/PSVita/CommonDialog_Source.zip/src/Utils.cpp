#include <string>
#include <common_dialog/common_api.h>
#include "Utils.h"

bool CommonDialogIsRunning()
{
	return sceCommonDialogIsRunning();
}

std::string WideCharToMultiByte(const wchar_t* source)
{
	char buffer[2048];
	wcstombs(buffer, source, sizeof(buffer));
	return std::string(buffer);
}
