#ifndef _ERRORCODES_H
#define _ERRORCODES_H

#include <np_toolkit.h>
#include "prx.h"
#include "SimpleLock.h"

namespace UnityCommonDialog
{
	const char* LookupErrorCode(int errorCode);
}

#endif // _ERRORCODES_H
