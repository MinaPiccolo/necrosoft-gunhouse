﻿#include "ImeDialog.h"
#include "MessagePipe.h"
#include "ErrorCodes.h"
#include "Utils.h"

namespace UnityCommonDialog
{
	PRX_EXPORT bool PrxImeDialogIsDialogOpen()
	{
		return gImeDialog.IsDialogOpen();
	}

	PRX_EXPORT bool PrxImeDialogOpen(ImeDialogParams* params)
	{
		return gImeDialog.StartDialog(params);
	}

	PRX_EXPORT bool PrxImeDialogGetResult(ImeDialogResult* result)
	{
		return gImeDialog.Get(result);
	}

	ImeDialog gImeDialog;

	ImeDialog::ImeDialog() :
	m_DialogOpen(false)
		,m_DefaultInputBuffer(NULL)
		,m_DefaultResultString(NULL)
	{
	}

	ImeDialog::~ImeDialog()
	{
		free(m_DefaultInputBuffer);
		free(m_DefaultResultString);
	}

	bool ImeDialog::StartDialog(const ImeDialogParams* params)
	{
		if(m_DialogOpen)
		{
			Messages::Log("ImeDialog is already open\n");
			return false;
		}

		if(CommonDialogIsRunning())
		{
			Messages::LogError("Common Dialog is already running\n");
			return false;
		}

		m_CachedParams.callback = DefaultResultCallback;
		if(m_DefaultInputBuffer)
		{
			free(m_DefaultInputBuffer);
		}
		m_DefaultInputBuffer = (SceWChar16*)malloc(sizeof(SceWChar16) * (params->maxTextLength+1));
		m_CachedParams.inputTextBuffer = m_DefaultInputBuffer;
		m_CachedParams.supportedLanguages = params->supportedLanguages;
		m_CachedParams.languagesForced = params->languagesForced;
		m_CachedParams.title = params->title;
		m_CachedParams.maxTextLength = params->maxTextLength;
		m_CachedParams.initialText = params->initialText;
		m_CachedParams.type = params->type;
		m_CachedParams.option = params->option;
		m_CachedParams.canCancel = params->canCancel;
		m_CachedParams.textBoxMode = params->textBoxMode;
		m_CachedParams.enterLabel = params->enterLabel;

		return StartDialog(m_CachedParams);
	}

	bool ImeDialog::StartDialog(const Params& params)
	{
		if(m_DialogOpen)
		{
			Messages::Log("ImeDialog is already open\n");
			return false;
		}

		m_DialogOpen = true;
		memset(m_ImeTitle, 0, sizeof(m_ImeTitle));
		if (params.title)
		{ 
			wcsncpy((wchar_t*)m_ImeTitle, (wchar_t*)params.title, sizeof(m_ImeTitle)/sizeof(wchar_t));
		}
		
		m_ImeMaxTextLength = params.maxTextLength;
		memset(m_ImeInitialText, 0, sizeof(m_ImeInitialText));
		if (params.initialText)
		{
			wcsncpy((wchar_t*)m_ImeInitialText, (wchar_t*)params.initialText, sizeof(m_ImeInitialText)/sizeof(wchar_t));
		}

		m_ImeInputTextBuffer = params.inputTextBuffer;
		m_ResultCallback = params.callback;

		SceImeDialogParam imeParams;
		sceImeDialogParamInit(&imeParams);

		imeParams.inputMethod = 0; /* not used */
		imeParams.supportedLanguages = params.supportedLanguages;
		imeParams.languagesForced = params.languagesForced;
		imeParams.type = params.type;
		imeParams.option = params.option;
		imeParams.filter = NULL;
		imeParams.dialogMode = params.canCancel ? SCE_IME_DIALOG_DIALOG_MODE_WITH_CANCEL : SCE_IME_DIALOG_DIALOG_MODE_DEFAULT;
		imeParams.textBoxMode = (params.option & SCE_IME_OPTION_MULTILINE) == 0 ? params.textBoxMode : SCE_IME_DIALOG_TEXTBOX_MODE_DEFAULT;
		imeParams.title = m_ImeTitle;
		imeParams.maxTextLength = m_ImeMaxTextLength;
		imeParams.initialText = m_ImeInitialText;
		imeParams.inputTextBuffer = m_ImeInputTextBuffer;
		imeParams.enterLabel = (params.option & SCE_IME_OPTION_MULTILINE) == 0 ? params.enterLabel : SCE_IME_ENTER_LABEL_DEFAULT;

		int ret = sceImeDialogInit(&imeParams);
		if (ret < 0)
		{
			Messages::LogError("ImeDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			m_DialogOpen = false;
			return false;
		}

		m_DialogOpen = true;
		return true;
	}

	bool ImeDialog::Update()
	{
		if (m_DialogOpen == false)
		{
			return true;
		}

		SceCommonDialogStatus cdStatus = sceImeDialogGetStatus();
		switch (cdStatus)
		{
		case SCE_COMMON_DIALOG_STATUS_NONE:
		case SCE_COMMON_DIALOG_STATUS_RUNNING:
			return true;
		case SCE_COMMON_DIALOG_STATUS_FINISHED:
			break;
		}

		SceImeDialogResult imeResult;
		memset(&imeResult, 0x00, sizeof(imeResult));
		int ret = sceImeDialogGetResult(&imeResult);
		if (ret < 0)
		{
			Messages::LogError("ImeDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			m_DialogOpen = false;
			return false;
		}

		ret = sceImeDialogTerm();
		if (ret < 0)
		{
			Messages::LogError("ImeDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			m_DialogOpen = false;
			return false;
		}

		if (m_ResultCallback)
		{
			m_ResultCallback(&imeResult);
			m_ResultCallback = NULL;
		}

		m_DialogOpen = false;
		return true;
	}

	void ImeDialog::DefaultResultCallback(const SceImeDialogResult *result)
	{
		if (result->result == SCE_COMMON_DIALOG_RESULT_OK)
		{
			if(gImeDialog.m_DefaultResultString)
			{
				free(gImeDialog.m_DefaultResultString);
			}

			size_t multiByteMaxLength = gImeDialog.m_CachedParams.maxTextLength * MB_CUR_MAX;
			gImeDialog.m_DefaultResultString = (char*)malloc(multiByteMaxLength + MB_CUR_MAX);
			wcstombs(gImeDialog.m_DefaultResultString, (wchar_t*)gImeDialog.m_DefaultInputBuffer, multiByteMaxLength);

			gImeDialog.m_CachedResult.result = result->result;
			gImeDialog.m_CachedResult.button = result->button;
			gImeDialog.m_CachedResult.text = gImeDialog.m_DefaultResultString;
		}
		else
		{
			gImeDialog.m_CachedResult.result = result->result;
			gImeDialog.m_CachedResult.button = result->button;
			gImeDialog.m_CachedResult.text = gImeDialog.m_DefaultResultString;
		}

		Messages::AddMessage(Messages::kDialog_GotIMEDialogResult);
	}

	// For use when calling directly from scripts.
	bool ImeDialog::Get(ImeDialogResult* result)
	{
		result->result = m_CachedResult.result;
		result->button = m_CachedResult.button;
		result->text = m_CachedResult.text;

		return true;
	}

} // namespace UnityNp
