#include "CommonDialog.h"
#include "MessagePipe.h"
#include "ErrorCodes.h"
#include "Utils.h"
#include <message_dialog.h>

namespace UnityCommonDialog
{
	PRX_EXPORT bool PrxCommonDialogIsDialogOpen()
	{
		return gDialog.IsDialogOpen();
	}

	PRX_EXPORT bool PrxCommonDialogErrorMessage(int errorCode)
	{
		return gDialog.StartDialogErrorMessage(errorCode);
	}

	PRX_EXPORT bool PrxCommonDialogSystemMessage(int type, bool infoBar, int value)
	{
		return gDialog.StartDialogSystemMessage(type, infoBar, value);
	}

	PRX_EXPORT bool PrxCommonDialogClose()
	{
		return gDialog.CloseDialog();
	}

	PRX_EXPORT bool PrxCommonDialogProgressBar(const char *str)
	{
		return gDialog.StartDialogProgressBar(str);
	}

	PRX_EXPORT bool PrxCommonDialogProgressBarSetPercent(int percent)
	{
		return gDialog.SetProgressBarPercent(percent);
	}

	PRX_EXPORT bool PrxCommonDialogProgressBarSetMessage(const char* str)
	{
		return gDialog.SetProgressBarMessage(str);
	}

	PRX_EXPORT bool PrxCommonDialogUserMessage(int type, bool infobar, const char* str, const char* button1, const char* button2, const char* button3)
	{
		return 	gDialog.StartDialogUserMessage(type, infobar, str, button1, button2, button3);

	}

	PRX_EXPORT int PrxCommonDialogGetResult()
	{
		return gDialog.GetResult();
	}

	CommonDialog gDialog;

	CommonDialog::CommonDialog()
		: m_DialogOpen(false)
		, m_DialogNeedsClosing(false)
		, m_DialogMode(SCE_MSG_DIALOG_MODE_INVALID)
		, m_UserMessageType(SCE_MSG_DIALOG_BUTTON_TYPE_OK)
		, m_SystemMessageType(SCE_MSG_DIALOG_SYSMSG_TYPE_INVALID)
		, m_DialogResult(RESULT_NOT_SET)
	{
	}

	CommonDialog::~CommonDialog()
	{
	}

	bool CommonDialog::CloseDialog()
	{
		if(!m_DialogOpen)
		{
			Messages::Log("Dialog is not open\n");
			return false;
		}

		m_DialogNeedsClosing = true;

		return true;
	}

	bool CommonDialog::StartDialogUserMessage(int type, bool infobar, const char* str, const char* button1, const char* button2, const char* button3)
	{
		if(m_DialogOpen)
		{
			Messages::Log("Dialog is already open\n");
			return false;
		}

		if(CommonDialogIsRunning())
		{
			Messages::LogError("Common Dialog is already running\n");
			return false;
		}

		m_DialogResult = RESULT_NOT_SET;

		SceMsgDialogParam msgParam;
		SceMsgDialogUserMessageParam userMsgParam;
		SceCommonDialogInfobarParam infobarParam;

		// initialize parameter of message dialog
		sceMsgDialogParamInit(&msgParam);
		msgParam.mode = SCE_MSG_DIALOG_MODE_USER_MSG;

		// initialize message dialog
		memset(&userMsgParam, 0, sizeof(SceMsgDialogUserMessageParam));
		msgParam.userMsgParam = &userMsgParam;
		msgParam.userMsgParam->msg = (SceChar8*)str;
		msgParam.userMsgParam->buttonType = type;
		m_UserMessageType = type;

		//Set strings in 3buttons. 
		if( SCE_MSG_DIALOG_BUTTON_TYPE_3BUTTONS == type )
		{
			SceMsgDialogButtonsParam buttonParam;
			memset(&buttonParam, 0, sizeof(SceMsgDialogButtonsParam));
			buttonParam.msg1 = (SceChar8*)button1;
			buttonParam.msg2 = (SceChar8*)button2;
			buttonParam.msg3 = (SceChar8*)button3;
			buttonParam.fontSize1 = SCE_MSG_DIALOG_FONT_SIZE_DEFAULT;
			buttonParam.fontSize2 = SCE_MSG_DIALOG_FONT_SIZE_DEFAULT;
			buttonParam.fontSize3 = SCE_MSG_DIALOG_FONT_SIZE_DEFAULT;
			msgParam.userMsgParam->buttonParam = &buttonParam;
		}

		// initialize parameters for infobar
		if (infobar)
		{
			memset(&infobarParam, 0, sizeof(infobarParam));
			infobarParam.visibility = true;
			infobarParam.color = 0;
			infobarParam.transparency = 0;
			msgParam.commonParam.infobarParam = &infobarParam;
		}
		else
		{
			msgParam.commonParam.infobarParam = NULL;
		}

		int ret = sceMsgDialogInit(&msgParam);
		if (ret < 0)
		{
			Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			return false;
		}

		m_DialogOpen = true;

		return true;
	}

	bool CommonDialog::StartDialogProgressBar(const char *str)
	{
		if(m_DialogOpen)
		{
			Messages::Log("Dialog is already open\n");
			return false;
		}

		if(CommonDialogIsRunning())
		{
			Messages::LogError("Common Dialog is already running\n");
			return false;
		}

		m_DialogResult = RESULT_NOT_SET;

		SceMsgDialogParam msgParam;
		SceMsgDialogProgressBarParam progBarParam;
		SceCommonDialogInfobarParam infobarParam;

		// initialize parameter of message dialog
		sceMsgDialogParamInit(&msgParam);
		msgParam.mode = SCE_MSG_DIALOG_MODE_PROGRESS_BAR;
		m_DialogMode = msgParam.mode;

		// initialize message dialog
		memset(&progBarParam, 0, sizeof(SceMsgDialogProgressBarParam));
		msgParam.progBarParam = &progBarParam;
		msgParam.progBarParam->barType = SCE_MSG_DIALOG_PROGRESSBAR_TYPE_PERCENTAGE;
		msgParam.progBarParam->msg = (const SceChar8*)str;

		// initialize parameters for infobar
		memset(&infobarParam, 0, sizeof(infobarParam));
		infobarParam.visibility = true;
		infobarParam.color = 0;
		infobarParam.transparency = 0;
		msgParam.commonParam.infobarParam = &infobarParam;
		msgParam.commonParam.dimmerColor = NULL;
		msgParam.commonParam.bgColor = NULL;

		int ret = sceMsgDialogInit(&msgParam);
		if (ret < 0)
		{
			Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			return false;
		}

		m_DialogOpen = true;

		return true;
	}

	bool CommonDialog::SetProgressBarPercent(int percent)
	{
		if(!m_DialogOpen || m_DialogMode != SCE_MSG_DIALOG_MODE_PROGRESS_BAR)
		{
			Messages::Log("ProgressBar dialog is not open\n");
			return false;
		}

		int ret = sceMsgDialogProgressBarSetValue(SCE_MSG_DIALOG_PROGRESSBAR_TARGET_BAR_DEFAULT, percent);
		if (ret < 0)
		{
			Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			return false;
		}

		return true;
	}

	bool CommonDialog::SetProgressBarMessage(const char* str)
	{
		if(!m_DialogOpen || m_DialogMode != SCE_MSG_DIALOG_MODE_PROGRESS_BAR)
		{
			Messages::Log("ProgressBar dialog is not open\n");
			return false;
		}

		int ret = sceMsgDialogProgressBarSetMsg(SCE_MSG_DIALOG_PROGRESSBAR_TARGET_BAR_DEFAULT, (const SceChar8*)str);
		if (ret < 0)
		{
			Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			return false;
		}

		return true;
	}

	bool CommonDialog::StartDialogSystemMessage(int type, bool infoBar, int value)
	{
		if(m_DialogOpen)
		{
			Messages::Log("Dialog is already open\n");
			return false;
		}

		if(CommonDialogIsRunning())
		{
			Messages::LogError("Common Dialog is already running\n");
			return false;
		}

		m_DialogResult = RESULT_NOT_SET;

		SceMsgDialogParam msgParam;
		SceMsgDialogSystemMessageParam sysMsgParam;
		SceCommonDialogInfobarParam infobarParam;

		// initialize parameter of message dialog
		sceMsgDialogParamInit(&msgParam);
		msgParam.mode = SCE_MSG_DIALOG_MODE_SYSTEM_MSG;
		m_DialogMode = msgParam.mode;

		// initialize message dialog
		memset(&sysMsgParam, 0, sizeof(SceMsgDialogSystemMessageParam));
		msgParam.sysMsgParam = &sysMsgParam;
		msgParam.sysMsgParam->sysMsgType = type;
		m_SystemMessageType = type;
		msgParam.sysMsgParam->value = value;

		// initialize parameters for infobar
		if (infoBar)
		{
			memset(&infobarParam, 0, sizeof(infobarParam));
			infobarParam.visibility = true;
			infobarParam.color = 0;
			infobarParam.transparency = 0;
			msgParam.commonParam.infobarParam = &infobarParam;
		}

		int ret = sceMsgDialogInit(&msgParam);
		if (ret < 0)
		{
			Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			return false;
		}

		m_DialogOpen = true;
		return true;
	}

	bool CommonDialog::StartDialogErrorMessage(int errorCode)
	{
		if(m_DialogOpen)
		{
			Messages::Log("ImeDailog is already open\n");
			return false;
		}

		if(CommonDialogIsRunning())
		{
			Messages::LogError("Common Dialog is already running\n");
			return false;
		}

		m_DialogResult = RESULT_NOT_SET;

		SceMsgDialogParam msgParam;
		SceMsgDialogErrorCodeParam errParam;

		// initialise parameter of message dialog
		sceMsgDialogParamInit(&msgParam);
		msgParam.mode = SCE_MSG_DIALOG_MODE_ERROR_CODE;
		m_DialogMode = msgParam.mode;

		// initialise message dialog
		memset(&errParam, 0, sizeof(SceMsgDialogErrorCodeParam));
		msgParam.errorCodeParam = &errParam;
		msgParam.errorCodeParam->errorCode = errorCode;

		int ret = sceMsgDialogInit(&msgParam);
		if (ret < 0)
		{
			Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			return false;
		}

		m_DialogOpen = true;
		return true;
	}

	int CommonDialog::Update(void)
	{
		SceCommonDialogStatus	cdStatus;
		SceMsgDialogResult		msgResult;

		int		res = SCE_OK;
		int		term_res = SCE_OK;

		// Get message dialog status
		cdStatus = sceMsgDialogGetStatus();

		if(m_DialogNeedsClosing && cdStatus == SCE_COMMON_DIALOG_STATUS_RUNNING )
		{
			// terminate message dialog
			int ret = sceMsgDialogClose();
			if (ret != SCE_OK)
			{
				Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			}
			else
			{
				m_DialogNeedsClosing = false;
			}
		}

		switch (cdStatus)
		{
			default:
			case SCE_COMMON_DIALOG_STATUS_NONE:
			case SCE_COMMON_DIALOG_STATUS_RUNNING:
				return cdStatus;

			case SCE_COMMON_DIALOG_STATUS_FINISHED:
				break;
		}

		// Get message dialog result
		memset(&msgResult, 0, sizeof(SceMsgDialogResult));
		res = sceMsgDialogGetResult(&msgResult);
		if (res != SCE_OK)
		{
			Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(res));
		}
		else
		{
			if (msgResult.result < 0)
			{
				Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(msgResult.result));
				res = msgResult.result;
			}
		}

		// Terminate message dialog
		term_res = sceMsgDialogTerm();
		if (term_res != SCE_OK)
		{
			Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(term_res));
			res = term_res;
		}

		if(msgResult.result == 0)
		{
			switch(msgResult.mode)
			{
				case SCE_MSG_DIALOG_MODE_USER_MSG:
					switch(m_UserMessageType)
					{
						case SCE_MSG_DIALOG_BUTTON_TYPE_OK:
							m_DialogResult = RESULT_BUTTON_OK;
							break;

						case SCE_MSG_DIALOG_BUTTON_TYPE_YESNO:
							m_DialogResult = msgResult.buttonId == SCE_MSG_DIALOG_BUTTON_ID_YES ? RESULT_BUTTON_YES : RESULT_BUTTON_NO;
							break;

						case SCE_MSG_DIALOG_BUTTON_TYPE_NONE:
							break;

						case SCE_MSG_DIALOG_BUTTON_TYPE_OK_CANCEL:
							m_DialogResult = msgResult.buttonId == SCE_MSG_DIALOG_BUTTON_ID_OK ? RESULT_BUTTON_OK : RESULT_BUTTON_CANCEL;
							break;

						case SCE_MSG_DIALOG_BUTTON_TYPE_CANCEL:
							m_DialogResult = RESULT_BUTTON_CANCEL;
							break;

						case SCE_MSG_DIALOG_BUTTON_TYPE_3BUTTONS:
							m_DialogResult = RESULT_BUTTON_1 + (msgResult.buttonId - SCE_MSG_DIALOG_BUTTON_ID_BUTTON1);
							break;

						default:
							Messages::LogError("CommonDialog::%s@L%d - button type not handeld %d", __FUNCTION__, __LINE__, m_UserMessageType);
							break;
					}
					break;

				case SCE_MSG_DIALOG_MODE_SYSTEM_MSG:
					switch(m_SystemMessageType)
					{
						case SCE_MSG_DIALOG_SYSMSG_TYPE_WAIT:
						case SCE_MSG_DIALOG_SYSMSG_TYPE_WAIT_SMALL:
						case SCE_MSG_DIALOG_SYSMSG_TYPE_WAIT_CANCEL:
							break;

						case SCE_MSG_DIALOG_SYSMSG_TYPE_NOSPACE:
							m_DialogResult = RESULT_BUTTON_OK;
							break;

						case SCE_MSG_DIALOG_SYSMSG_TYPE_NOSPACE_CONTINUABLE:
							m_DialogResult = RESULT_BUTTON_OK;
							break;

						case SCE_MSG_DIALOG_SYSMSG_TYPE_MAGNETIC_CALIBRATION:
							m_DialogResult = RESULT_BUTTON_CANCEL;
							break;

						case SCE_MSG_DIALOG_SYSMSG_TYPE_LOCATION_DATA_OBTAINING:
							m_DialogResult = RESULT_BUTTON_CANCEL;
							break;

						case SCE_MSG_DIALOG_SYSMSG_TYPE_LOCATION_DATA_FAILURE:
						case SCE_MSG_DIALOG_SYSMSG_TYPE_LOCATION_DATA_FAILURE_RETRY:
						case SCE_MSG_DIALOG_SYSMSG_TYPE_PATCH_FOUND:
							m_DialogResult = RESULT_BUTTON_OK;
							break;
					}
					break;

				case SCE_MSG_DIALOG_MODE_ERROR_CODE:
					m_DialogResult = RESULT_BUTTON_OK;
					break;

				case SCE_MSG_DIALOG_MODE_PROGRESS_BAR:
					break;
			}
		}
		else if(msgResult.result > 0)
		{
			switch(msgResult.result)
			{
				case SCE_COMMON_DIALOG_RESULT_USER_CANCELED:
					m_DialogResult = RESULT_CANCELED;
					break;

				case SCE_COMMON_DIALOG_RESULT_ABORTED:
					m_DialogResult = RESULT_ABORTED;
					break;
			}
		}

		//Messages::Log("Dialog closed, msgResult: %d, 0x%x, %d, dlgResult: %d",msgResult.mode, msgResult.result, msgResult.buttonId, m_DialogResult);

		if(m_DialogResult != RESULT_NOT_SET)
		{
			Messages::PluginMessage* msg = new Messages::PluginMessage();
			msg->type = Messages::kDialog_GotDialogResult;
			msg->SetData(m_DialogResult);
			Messages::AddMessage(msg);
		}

		m_DialogOpen = false;
		return res;
	}
	
	int CommonDialog::GetResult()
	{
		if(m_DialogOpen)
		{
			Messages::Log("CommonDialog::GetResult dialog still open\n");
			return false;
		}

		return m_DialogResult;
	}

}
