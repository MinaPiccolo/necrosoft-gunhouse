#ifndef _UTILS_H
#define _UTILS_H

bool CommonDialogIsRunning();
std::string WideCharToMultiByte(const wchar_t* source);

#endif
