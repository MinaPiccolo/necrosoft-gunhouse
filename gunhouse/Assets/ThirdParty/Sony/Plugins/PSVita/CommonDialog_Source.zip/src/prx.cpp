#include <stdio.h>
#include <kernel.h>
#include <moduleinfo.h>
#include <libsysmodule.h>

#include "prx.h"
#include "CommonDialog.h"
#include "ImeDialog.h"

SCE_MODULE_INFO(CommonDialog, SCE_MODULE_ATTR_NONE, 1, 1);

extern "C" int module_start(SceSize sz, const void* arg)
{
	return SCE_KERNEL_START_SUCCESS;
}

PRX_EXPORT int PrxCommonDialogInitialise()
{
	return 0;
}

PRX_EXPORT void PrxCommonDialogUpdate()
{
	UnityCommonDialog::gDialog.Update();
	UnityCommonDialog::gImeDialog.Update();
}
