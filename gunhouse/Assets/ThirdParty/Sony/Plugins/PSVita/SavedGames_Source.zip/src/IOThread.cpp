#include "IOThread.h"
#include "MessagePipe.h"
#include "ErrorCodes.h"

// It may or may not be required when saving data to explicitly create a slot before calling sceAppUtilSaveDataSlotGetParam()
// to ensure that the "AppUtil: Read Slot Status XXX " TRC check message is displayed even if it's the first time a game has
// been saved. Currently being discussed on dev-net @ https://psvita.scedev.net/forums/thread/72550/
#define EXPLICITLY_CREATE_SLOTS 0

namespace UnitySavedGames
{
	IOThread::IOThread()
		: m_ThreadID(-1)
		, m_SlotID(0)
		, m_Mode(IOMODE_NOT_SET)
		, m_Status(THREAD_STOPPED)
		, m_BufferSize(0)
		, m_Buffer(NULL)
		, m_Result(0)
		, m_RequiredSizeKiB(0)
		, m_LastResult("IOThread")
	{
	}

	IOThread::~IOThread()
	{
		Stop();
		free(m_Buffer);
	}
	
	void IOThread::SetBuffer(int bufferSize, void* buffer)
	{
		free(m_Buffer);
		if(buffer)
		{
			m_BufferSize = bufferSize + sizeof(Header);
			m_Buffer = malloc(m_BufferSize);
			Header* header = (Header*)m_Buffer;
			memcpy(header->ident, SAVEDATA_HEADER_IDENT, 4);
			header->bufferSize = bufferSize;
			void* data = (void*)(header + 1);
			memcpy(data, buffer, bufferSize);
		}
		else
		{
			m_BufferSize = 0;
			m_Buffer = NULL;
		}
	}

	ErrorCode IOThread::Start(IOThreadMode mode, int slotID)
	{
		SceKernelThreadEntry	entry;
		int		res;
		m_LastResult.Reset();

		if (m_ThreadID >= 0)
		{
			return m_LastResult.SetResult(SG_ERR_BAD_STATE, true, __FUNCTION__, __LINE__);
		}

		m_SlotID = slotID;
		m_Mode = mode;

		switch(mode)
		{
			case IOMODE_LOAD:
				entry = ThreadFuncLoad;
				break;

			case IOMODE_SAVE:
				if(m_BufferSize > SCE_APPUTIL_SAVEDATA_DATA_SAVE_MAXSIZE)
				{
					entry = ThreadFuncSaveLarge;
				}
				else
				{
					entry = ThreadFuncSave;
				}
				break;

			case IOMODE_DELETE:
				entry = ThreadFuncDelete;
				break;
		}

		res = sceKernelCreateThread(SAVEDATA_SUBTHREAD_NAME, entry,
									SCE_KERNEL_DEFAULT_PRIORITY_USER - 1,
									4096, 0,
									SCE_KERNEL_CPU_MASK_USER_ALL, SCE_NULL);
		if (res < SCE_OK)
		{
			return m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}
		m_ThreadID = res;

		static IOThread* userData;
		userData = this;
		res = sceKernelStartThread(m_ThreadID, 4, &userData);
		if (res < SCE_OK)
		{
			return m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}

		return m_LastResult.GetResult();
	}

	ErrorCode IOThread::Stop(void)
	{
		int		res;

		m_LastResult.Reset();
		m_Status = THREAD_STOPPED;

		if (m_ThreadID < 0)
		{
			// Already stopped.
			return m_LastResult.GetResult();
		}

		res = sceKernelWaitThreadEnd(m_ThreadID, SCE_NULL, SCE_NULL);
		if (res < SCE_OK)
		{
			return m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}
		res = sceKernelDeleteThread(m_ThreadID);
		if (res < SCE_OK)
		{
			return m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}

		m_ThreadID = -1;
		
		return m_LastResult.GetResult();
	}

	// Create the save slot, if the slot already exists then returns SCE_APPUTIL_ERROR_SAVEDATA_SLOT_EXISTS
	// This function should be called before calling sceAppUtilSaveDataSlotGetParam to comply with TRC 3170
	SceInt32 IOThread::CreateSlot()
	{
		SceAppUtilSaveDataSlotParam slotParam;
		memset(&slotParam, 0, sizeof(SceAppUtilSaveDataSlotParam));
		strncpy((char*)&slotParam.title, m_SlotParams.title.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_TITLE_MAXSIZE-1 );
		strncpy((char*)&slotParam.subTitle, m_SlotParams.subTitle.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_SUBTITLE_MAXSIZE-1 );
		strncpy((char*)&slotParam.detail, m_SlotParams.detail.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_DETAIL_MAXSIZE-1 );
		strncpy((char*)&slotParam.iconPath, m_SlotParams.iconPath.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_ICON_PATH_MAXSIZE-1 );
		return sceAppUtilSaveDataSlotCreate(m_SlotID, &slotParam, NULL);
	}

	SceInt32 IOThread::ThreadFuncSave(SceSize args, void *argc)
	{
		IOThread* thread = *(IOThread**)argc;
		SceAppUtilSaveDataSlotParam slotParam;
		SceAppUtilSaveDataDataSlot saveSlot;
		SceAppUtilSaveDataDataSaveItem saveData;
		SceAppUtilSaveDataDataRemoveItem removeData;
		char sdFile[SCE_APPUTIL_MOUNTPOINT_DATA_MAXSIZE + 256];

		SceInt32	res;

		thread->m_Status = THREAD_RUNNING;

		// open/create save data
		memset(sdFile, 0, sizeof(sdFile));
		snprintf(sdFile, sizeof(sdFile), "%s%04d%s", SAVEDATA_SAVE_FILENAME_BASE, thread->m_SlotID, SAVEDATA_SAVE_FILENAME_EXT);

#if EXPLICITLY_CREATE_SLOTS
		bool slotWasCreated = thread->CreateSlot() == SCE_OK;
#endif

		// Check if broken save data existed and if it does then remove it.
		memset(&slotParam, 0, sizeof(SceAppUtilSaveDataSlotParam));
		res = sceAppUtilSaveDataSlotGetParam(thread->m_SlotID, &slotParam, NULL);
		if (res == SCE_OK && slotParam.status == SCE_APPUTIL_SAVEDATA_SLOT_STATUS_BROKEN)
		{
			// set remove save data file parameters
			memset(&removeData, 0, sizeof(removeData));
			removeData.dataPath = (SceChar8*)sdFile;
			removeData.mode     = SCE_APPUTIL_SAVEDATA_DATA_REMOVE_MODE_DEFAULT;

			res = sceAppUtilSaveDataDataRemove(NULL, &removeData, 1, NULL);
			if (res != SCE_OK)
			{
				thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			}
		}

		// initialize save data parameters
		memset(&slotParam, 0, sizeof(SceAppUtilSaveDataSlotParam));
		strncpy((char*)&slotParam.title, thread->m_SlotParams.title.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_TITLE_MAXSIZE-1 );
		strncpy((char*)&slotParam.subTitle, thread->m_SlotParams.subTitle.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_SUBTITLE_MAXSIZE-1 );
		strncpy((char*)&slotParam.detail, thread->m_SlotParams.detail.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_DETAIL_MAXSIZE-1 );
		strncpy((char*)&slotParam.iconPath, thread->m_SlotParams.iconPath.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_ICON_PATH_MAXSIZE-1 );

		// set save data file slot parameters
		memset(&saveSlot, 0, sizeof(saveSlot));
		saveSlot.id        = thread->m_SlotID;
		saveSlot.slotParam = &slotParam;

		// set save data file parameters
		memset(&saveData, 0, sizeof(saveData));
		saveData.dataPath = (SceChar8*)sdFile;
		saveData.buf      = thread->m_Buffer;
		saveData.bufSize  = thread->m_BufferSize;
		saveData.offset   = 0;

		// save operation
		// NOTE: Returns required size in m_RequiredSizeKiB if SCE_APPUTIL_ERROR_SAVEDATA_NO_SPACE_QUOTA or SCE_APPUTIL_ERROR_SAVEDATA_NO_SPACE_FS error occurs.
		res = sceAppUtilSaveDataDataSave(&saveSlot, &saveData, 1, NULL, &thread->m_RequiredSizeKiB);

		thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);

#if EXPLICITLY_CREATE_SLOTS
		if (slotWasCreated && res != SCE_OK)
		{
			// If the save failed and this is the first time the slot has been written to, e.g. was created above
			// by the call to CreateSlot(), then remove the slot. This prevents an empty and invalid slot being
			// shown in save game lists.
			sceAppUtilSaveDataSlotDelete(thread->m_SlotID, NULL);
		}
#endif

		thread->m_Status = THREAD_END;
		thread->m_ThreadID = -1;
		thread->m_Result = res;

		// close save data dialog if open
		SceCommonDialogStatus stat = sceSaveDataDialogGetSubStatus();
		if(stat==SCE_COMMON_DIALOG_STATUS_RUNNING)
		{
			res = sceSaveDataDialogSubClose();
			if (res != SCE_OK)
			{
				thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			}
		}

		res = sceKernelExitDeleteThread(0);
		if (res != SCE_OK)
		{
			thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}

		return res;
	}

	SceInt32 IOThread::ThreadFuncSaveLarge(SceSize args, void *argc)
	{
		IOThread* thread = *(IOThread**)argc;
		SceAppUtilSaveDataSlotParam slotParam;
		SceAppUtilSaveDataDataSlot saveSlot;
		SceAppUtilSaveDataDataSaveItem saveData;
		SceAppUtilSaveDataDataRemoveItem removeData;
		char sdFile[SCE_APPUTIL_MOUNTPOINT_DATA_MAXSIZE + 256];

		SceInt32	res;

		thread->m_Status = THREAD_RUNNING;

		// open/create save data
		memset(sdFile, 0, sizeof(sdFile));
		snprintf(sdFile, sizeof(sdFile), "%s%04d%s", SAVEDATA_SAVE_FILENAME_BASE, thread->m_SlotID, SAVEDATA_SAVE_FILENAME_EXT);

#if EXPLICITLY_CREATE_SLOTS
		bool slotWasCreated = thread->CreateSlot() == SCE_OK;
#endif

		// Check if broken save data existed and if it does then remove it.
		memset(&slotParam, 0, sizeof(SceAppUtilSaveDataSlotParam));
		res = sceAppUtilSaveDataSlotGetParam(thread->m_SlotID, &slotParam, NULL);
		if (res == SCE_OK && slotParam.status == SCE_APPUTIL_SAVEDATA_SLOT_STATUS_BROKEN)
		{
			// set remove save data file parameters
			memset(&removeData, 0, sizeof(removeData));
			removeData.dataPath = (SceChar8*)sdFile;
			removeData.mode     = SCE_APPUTIL_SAVEDATA_DATA_REMOVE_MODE_DEFAULT;

			res = sceAppUtilSaveDataDataRemove(NULL, &removeData, 1, NULL);
			if (res != SCE_OK)
			{
				thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			}
		}

		// initialize save data parameters
		memset(&slotParam, 0, sizeof(SceAppUtilSaveDataSlotParam));
		strncpy((char*)&slotParam.title, thread->m_SlotParams.title.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_TITLE_MAXSIZE-1 );
		strncpy((char*)&slotParam.subTitle, thread->m_SlotParams.subTitle.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_SUBTITLE_MAXSIZE-1 );
		strncpy((char*)&slotParam.detail, thread->m_SlotParams.detail.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_DETAIL_MAXSIZE-1 );
		strncpy((char*)&slotParam.iconPath, thread->m_SlotParams.iconPath.c_str(), SCE_APPUTIL_SAVEDATA_SLOT_ICON_PATH_MAXSIZE-1 );

		// Set the slot's status to broken.
		slotParam.status = SCE_APPUTIL_SAVEDATA_SLOT_STATUS_BROKEN;

		// Reflect the broken status.
		res = sceAppUtilSaveDataSlotSetParam( thread->m_SlotID, &slotParam, NULL );

		if(res == SCE_OK || res == SCE_APPUTIL_ERROR_SAVEDATA_SLOT_NOT_FOUND)
		{
			// Save in sections of SCE_APPUTIL_SAVEDATA_DATA_SAVE_MAXSIZE or less...
			int sizeRemaining = thread->m_BufferSize;
			int offset = 0;
			char* bufPos = (char*)thread->m_Buffer; 

			while(sizeRemaining > SCE_APPUTIL_SAVEDATA_DATA_SAVE_MAXSIZE)
			{
				// set save data file parameters
				memset(&saveData, 0, sizeof(saveData));
				saveData.dataPath = (SceChar8*)sdFile;
				saveData.buf      = bufPos;
				saveData.bufSize  = SCE_APPUTIL_SAVEDATA_DATA_SAVE_MAXSIZE;
				saveData.offset   = offset;

				bufPos += saveData.bufSize;
				offset += saveData.bufSize;
				sizeRemaining -= saveData.bufSize;

				res = sceAppUtilSaveDataDataSave( NULL, &saveData, 1, NULL, &thread->m_RequiredSizeKiB);
				if(res != SCE_OK)
				{
					break;
				}
			}

			if(res == SCE_OK)
			{
				// set save data file parameters
				memset(&saveData, 0, sizeof(saveData));
				saveData.dataPath = (SceChar8*)sdFile;
				saveData.buf      = bufPos;
				saveData.bufSize  = sizeRemaining;
				saveData.offset   = offset;

				// set save data file slot parameters
				memset(&saveSlot, 0, sizeof(saveSlot));
				saveSlot.id        = thread->m_SlotID;
				saveSlot.slotParam = &slotParam;

				res = sceAppUtilSaveDataDataSave( &saveSlot, &saveData, 1, NULL, &thread->m_RequiredSizeKiB);
			}
		}

		thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);

#if EXPLICITLY_CREATE_SLOTS
		if (slotWasCreated && res != SCE_OK)
		{
			// If the save failed and this is the first time the slot has been written to, e.g. was created above
			// by the call to CreateSlot(), then remove the slot. This prevents an empty and invalid slot being
			// shown in save game lists.
			sceAppUtilSaveDataSlotDelete(thread->m_SlotID, NULL);
		}
#endif

		thread->m_Status = THREAD_END;
		thread->m_ThreadID = -1;
		thread->m_Result = res;

		// close save data dialog if open
		SceCommonDialogStatus stat = sceSaveDataDialogGetSubStatus();
		if(stat==SCE_COMMON_DIALOG_STATUS_RUNNING)
		{
			res = sceSaveDataDialogSubClose();
			if (res != SCE_OK)
			{
				thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			}
		}

		res = sceKernelExitDeleteThread(0);
		if (res != SCE_OK)
		{
			thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}

		return res;
	}

	SceInt32 IOThread::ThreadFuncLoad(SceSize args, void *argc)
	{
		IOThread* thread = *(IOThread**)argc;
		char		sdFile[SCE_APPUTIL_MOUNTPOINT_DATA_MAXSIZE + 256];
		SceUID		fd = -1;
		SceInt32	res;

		thread->m_Status = THREAD_RUNNING;

		// open save data
		memset(sdFile, 0, sizeof(sdFile));
		snprintf(sdFile, sizeof(sdFile), "%s:%s%04d%s", SAVEDATA_MOUNTPOINT_DATA, SAVEDATA_SAVE_FILENAME_BASE, thread->m_SlotID, SAVEDATA_SAVE_FILENAME_EXT);

		// Check the slot status and return an error code if it's broken ?
		SceAppUtilSaveDataSlotParam slotParam;
		memset(&slotParam, 0, sizeof(SceAppUtilSaveDataSlotParam));
		res = sceAppUtilSaveDataSlotGetParam(thread->m_SlotID, &slotParam, NULL);
		if (res == SCE_OK && slotParam.status == SCE_APPUTIL_SAVEDATA_SLOT_STATUS_BROKEN)
		{
			res = SCE_ERROR_ERRNO_EBADF;
			thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}
		else
		{
			// Slot is OK so open & read.
			fd = sceIoOpen(sdFile, SCE_O_RDONLY, 0);
			if(fd >= 0)
			{
				// load operation
				Header readHeader;
				res = sceIoRead(fd, &readHeader, sizeof(Header));
				if(res >= SCE_OK)
				{
					if(memcmp(readHeader.ident, SAVEDATA_HEADER_IDENT, 4) == 0)
					{
						free(thread->m_Buffer);
						thread->m_BufferSize = readHeader.bufferSize + sizeof(Header);
						thread->m_Buffer = malloc(thread->m_BufferSize);
						Header* header = (Header*)thread->m_Buffer;
						memcpy(header, &readHeader, sizeof(Header));
						void* data = (void*)(header + 1);

						res = sceIoRead(fd, data, readHeader.bufferSize);
						if(res < SCE_OK)
						{
							thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
						}
						else
						{
							res = SCE_OK;
						}
					}
					else
					{
						thread->m_LastResult.SetResultSCE(SCE_ERROR_ERRNO_EBADF, true, __FUNCTION__, __LINE__);
					}
				}
				else
				{
					thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
				}
			}
			else
			{
				res = fd;

				// If some error other than SCE_ERROR_ERRNO_ENOENT (file not found), log it.
				if(res != SCE_ERROR_ERRNO_ENOENT)
				{
					thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
				}
			}

			if (fd >= 0)
			{
				sceIoClose(fd);
			}
		}

		if (res != 0)
		{
			thread->m_Status = THREAD_END;
		}
		else
		{		
			thread->m_Status = THREAD_LOADED;
		}

		thread->m_ThreadID = -1;
		thread->m_Result = res;

		// close save data dialog if open
		SceCommonDialogStatus stat = sceSaveDataDialogGetSubStatus();
		if(stat == SCE_COMMON_DIALOG_STATUS_RUNNING)
		{
			res = sceSaveDataDialogSubClose();
			if (res != SCE_OK)
			{
				thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			}
		}

		res = sceKernelExitDeleteThread(0);
		if (res != SCE_OK)
		{
			thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}

		return res;
	}

	SceInt32 IOThread::ThreadFuncDelete(SceSize args, void *argc)
	{
		IOThread* thread = *(IOThread**)argc;
		SceAppUtilSaveDataDataSlot			saveSlot;
		SceAppUtilSaveDataDataRemoveItem	removeData;
		char		sdFile[SCE_APPUTIL_MOUNTPOINT_DATA_MAXSIZE + 256];
		SceInt32	res;

		thread->m_Status = THREAD_RUNNING;

		memset(sdFile, 0, sizeof(sdFile));
		snprintf(sdFile, sizeof(sdFile), "%s%04d%s", SAVEDATA_SAVE_FILENAME_BASE, thread->m_SlotID, SAVEDATA_SAVE_FILENAME_EXT);

		// set remove save data file parameters
		memset(&removeData, 0, sizeof(removeData));
		removeData.dataPath = (SceChar8*)sdFile;
		removeData.mode     = SCE_APPUTIL_SAVEDATA_DATA_REMOVE_MODE_DEFAULT;

		// set save data file slot parameters
		memset(&saveSlot, 0, sizeof(saveSlot));
		saveSlot.id        = thread->m_SlotID;
		saveSlot.slotParam = NULL;

		res = sceAppUtilSaveDataDataRemove(&saveSlot, &removeData, 1, NULL);
		if (res != SCE_OK)
		{
			thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}

		thread->m_Status = THREAD_END;
		thread->m_ThreadID = -1;
		thread->m_Result = res;

		// close save data dialog if open
		SceCommonDialogStatus stat = sceSaveDataDialogGetSubStatus();
		if(stat == SCE_COMMON_DIALOG_STATUS_RUNNING)
		{
			res = sceSaveDataDialogSubClose();
			if (res != SCE_OK)
			{
				thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			}
		}

		res = sceKernelExitDeleteThread(0);
		if (res != SCE_OK)
		{
			thread->m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}

		return res;
	}

} // UnitySavedGames
