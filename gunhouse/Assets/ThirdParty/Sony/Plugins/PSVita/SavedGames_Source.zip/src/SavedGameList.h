#ifndef _SAVEDGAMELIST_H
#define _SAVEDGAMELIST_H

#include "prx.h"
#include "SimpleLock.h"
#include "IOThread.h"
#include "MessagePipe.h"

#define	SAVEDATA_DEFAULT_MAX_SLOT_NUM	10
#define	SAVEDATA_MAX_ALLOWED_SLOTS		100

namespace UnitySavedGames
{
	struct SavedGameListSlotParams
	{
		const char* title;		// Title name.
		const char* subTitle;	// Subtitle name.
		const char* detail;		// detail info.
		const char* iconPath;	// Thumbnail icon path.
	};

	struct SavedGameListData
	{
		int dataSize;
		void* data;
	};

	PRX_EXPORT ErrorCode PrxSavedGameSetSlotCount(int slotCount);
	PRX_EXPORT ErrorCode PrxSavedGameListSave(void* data, int dataSize, SavedGameListSlotParams* slotParams, int controlFlags);
	PRX_EXPORT ErrorCode PrxSavedGameListLoad();
	PRX_EXPORT ErrorCode PrxSavedGameListDelete();

	// save data dialog mode
	enum DialogListMode
	{
		DIALOG_LIST_MODE_NONE,
		DIALOG_LIST_MODE_SAVE,
		DIALOG_LIST_MODE_LOAD,
		DIALOG_LIST_MODE_DELETE
	};

	// save data dialog state
	enum DialogListState
	{
		DIALOG_LIST_STEP_NONE,
		DIALOG_LIST_STEP_LIST,
		DIALOG_LIST_STEP_CONFIRM,
		DIALOG_LIST_STEP_SAVING,
		DIALOG_LIST_STEP_ALERT,
		DIALOG_LIST_STEP_FINISH,
		DIALOG_LIST_STEP_END,
		DIALOG_LIST_STEP_END_CANCELED
	};

	class SavedGameList
	{
		SimpleLock m_Lock;
		bool m_DialogOpen;
		DialogListState m_SavedDataDialogState;
		DialogListMode m_SavedDataDialogMode;
		IOThread* m_IOThread;
		SceAppUtilSaveDataSlotId m_SlotId;
		int m_NumberOfSlots;
		SceAppUtilSaveDataSlot* m_SlotList;
		SceAppUtilSaveDataSlotEmptyParam m_SlotEmptyParam;
		std::string m_SlotEmptyIconPath;
		Messages::MessageType m_DialogEndMessage;
		int m_ControlFlags;
		ResultCode m_LastResult;

	public:
		SavedGameList();
		~SavedGameList();

		ErrorCode GetLastError() const { return m_LastResult.GetResult(); }
		bool GetLastError(ResultCode* result) const { *result = m_LastResult; return m_LastResult.GetResult() == SG_OK; }

		ErrorCode SetEmptyIconPath(const char* iconPath);
		ErrorCode SetSlotCount(int slotCount);

		bool IsInitialized() { return m_IOThread != NULL; }
		bool IsBusy() { return m_DialogOpen; }
		bool IsDialogOpen() { return m_DialogOpen; }
		ErrorCode Save(void* data, int dataSize, SavedGameListSlotParams* slotParams, int controlFlags);
		ErrorCode Load();
		ErrorCode Delete();
		//bool Get(SavedGameListData* data);

		void SetIOThread(IOThread* thread) { m_IOThread = thread; }
		int Update(void);

	private:
		ErrorCode StartSaveLoad(IOThreadMode mode, int size, void *buffer);
		int InitDialog(DialogListMode dialogMode);
		int ShutdownIOThread(void);
		int ShutdownDialog(void);
	};

	extern SavedGameList gSavedGameList;
}

#endif // _SAVEDGAMELIST_H
