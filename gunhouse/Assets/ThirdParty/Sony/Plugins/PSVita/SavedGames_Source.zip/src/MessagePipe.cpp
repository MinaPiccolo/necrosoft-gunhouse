#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <list>

#include "prx.h"
#include "SimpleLock.h"
#include "MessagePipe.h"

PRX_EXPORT bool PrxSavedGamesHasMessage()
{
	return UnitySavedGames::Messages::HasMessage();
}

PRX_EXPORT bool PrxSavedGamesGetFirstMessage(UnitySavedGames::Messages::PluginMessage* result)
{
	return UnitySavedGames::Messages::GetFirstMessage(result);
}

PRX_EXPORT bool PrxSavedGamesRemoveFirstMessage()
{
	return UnitySavedGames::Messages::RemoveFirstMessage();
}

namespace UnitySavedGames
{
	namespace Messages
	{
		std::list<PluginMessage*> messages;
		SimpleLock lockMessages;

		void AddLogMessage(int type, const char* format, va_list alist)
		{
			char buffer[256];

			va_list args;
			va_copy (args, alist);
			va_start (args, format);
			vsnprintf (buffer,256,format, args);
			perror (buffer);
			va_end (args);

			PluginMessage* msg = new PluginMessage();
			msg->type = type;
			msg->SetDataFromString(buffer);
			AddMessage(msg);
		}

		void Log(const char* format, ...)
		{
			char buffer[1024];
			va_list args;
			va_start (args, format);
			vsnprintf (buffer, 1024, format, args);
			va_end (args);

			PluginMessage* msg = new PluginMessage();
			msg->type = kSavedGame_Log;
			msg->SetDataFromString(buffer);
			AddMessage(msg);
			UNITY_TRACE(buffer);
		}

		void LogWarning(const char* format, ...)
		{
			char buffer[1024];
			va_list args;
			va_start (args, format);
			vsnprintf (buffer, 1024, format, args);
			va_end (args);

			PluginMessage* msg = new PluginMessage();
			msg->type = kSavedGame_LogWarning;
			msg->SetDataFromString(buffer);
			AddMessage(msg);
			UNITY_TRACE("WARNING: %s\n", buffer);
		}

		void LogError(const char* format, ...)
		{
			char buffer[1024];
			va_list args;
			va_start (args, format);
			vsnprintf (buffer, 1024, format, args);
			va_end (args);

			PluginMessage* msg = new PluginMessage();
			msg->type = kSavedGame_LogError;
			msg->SetDataFromString(buffer);
			AddMessage(msg);
			UNITY_TRACE("ERROR: %s\n", buffer);
		}

		void AddMessage(MessageType msgType)
		{
			PluginMessage* msg = new UnitySavedGames::Messages::PluginMessage();
			msg->type = msgType;
			UnitySavedGames::Messages::AddMessage(msg);
		}
	
		void AddMessage(PluginMessage* msg)
		{
			SimpleLock::AutoLock lock(lockMessages);
			messages.push_back(msg);
		}

		bool HasMessage()
		{
			SimpleLock::AutoLock lock(lockMessages);
			return !messages.empty();
		}

		bool GetFirstMessage(PluginMessage* msg)
		{
			SimpleLock::AutoLock lock(lockMessages);
			if(!messages.empty())
			{
				*msg = *messages.front();
				return true;
			}

			return false;
		}

		bool RemoveFirstMessage()
		{
			SimpleLock::AutoLock lock(lockMessages);
			if(!messages.empty())
			{
				delete messages.front();
				messages.pop_front();
				return true;
			}

			return false;
		}
	} // Messages
} // UnitySavedGames
