#include <np_toolkit.h>
#include <ime_dialog.h>
#include "prx.h"
#include "MessagePipe.h"
#include "ErrorCodes.h"

#define CASE_ERROR_TO_STRING(errCode) case errCode: errorString = #errCode; break;

namespace UnitySavedGames
{
	bool gLogErrors = false;

	PRX_EXPORT bool PrxSavedGamesGetLoggingEnabled()
	{
		return gLogErrors;
	}

	PRX_EXPORT void PrxSavedGamesSetLoggingEnabled(bool logErrors)
	{
		gLogErrors = logErrors;
	}


	ErrorCode TranslateSceError(int sceError)
	{
		switch(sceError)
		{
		case SCE_OK:
			return SG_OK;

		case SCE_ERROR_ERRNO_EBADF:
			return SG_ERR_BAD_FILE;

		case SCE_APPUTIL_ERROR_NOT_MOUNTED:
			return SG_ERR_NO_MEM_CARD;

		case SCE_APPUTIL_ERROR_SAVEDATA_NO_SPACE_FS:
			return SG_ERR_NO_SPACE;

		case SCE_APPUTIL_ERROR_SAVEDATA_NO_SPACE_QUOTA:
			return SG_ERR_NO_SPACE_QUOTA;
		}

		return SG_ERR_FAILED;
	}

	const char* LookupErrorCode(ErrorCode errorCode)
	{
		static char defaultErrorString[16];
		const char* errorString = NULL;

		switch(errorCode)
		{
			CASE_ERROR_TO_STRING(SG_OK)
			CASE_ERROR_TO_STRING(SG_ERR_BUSY)							// The system is busy.
			CASE_ERROR_TO_STRING(SG_ERR_FAILED)							// General failure) check the log for more info.
			CASE_ERROR_TO_STRING(SG_ERR_BAD_STATE)						// Somethings gone wrong with the logic) most likely a bug in the native plugin code.
			CASE_ERROR_TO_STRING(SG_ERR_INDEX_OUT_OF_RANGE)				// An out of range array index was specified.
			CASE_ERROR_TO_STRING(SG_ERR_ICON_PATH_TOO_LONG)				// Icon path exceeds the maximum allowed length.
			CASE_ERROR_TO_STRING(SG_ERR_DIALOG_OPEN)					// Unable to start because a dialog is already open.
			CASE_ERROR_TO_STRING(SG_ERR_BAD_FILE)						// Bad file data or invalid header detected.
			CASE_ERROR_TO_STRING(SG_ERR_NO_SPACE_QUOTA)					// Save quota exceeded.
			CASE_ERROR_TO_STRING(SG_ERR_NO_SPACE)						// No space on the memory card.
			CASE_ERROR_TO_STRING(SG_ERR_NO_MEM_CARD)					// No memory card.
			CASE_ERROR_TO_STRING(SG_ERR_NO_DATA)						// No data loaded.

		default:
			sprintf(defaultErrorString, "0x%08x", errorCode);
			errorString = defaultErrorString;
			break;
		}

		return errorString;
	}

	ErrorCode ProcessSceResult(int sceError, bool log, const char* className, const char* function, int line, const char* message)
	{
		log &= gLogErrors;
		if(log && sceError != SCE_OK)
		{
			if(message)
			{
				Messages::LogError("%s::%s@L%d - %s - %s", className, function, line, message, LookupSceErrorCode(sceError));
			}
			else
			{
				Messages::LogError("%s::%s@L%d - %s", className, function, line, LookupSceErrorCode(sceError));
			}
		}
		return TranslateSceError(sceError);
	}

	ErrorCode ProcessSceResult(int sceError, bool log, const char* message)
	{
		log &= gLogErrors;
		if(log && sceError != SCE_OK)
		{
			Messages::LogError(message);
		}
		return TranslateSceError(sceError);
	}

	ErrorCode ProcessSceResult(int sceError, bool log)
	{
		log &= gLogErrors;
		if(log && sceError != SCE_OK)
		{
			Messages::LogError(LookupSceErrorCode(sceError));
		}
		return TranslateSceError(sceError);
	}

	ErrorCode ProcessResult(ErrorCode error, bool log, const char* className, const char* function, int line, const char* message)
	{
		log &= gLogErrors;
		if(log && error != SG_OK)
		{
			if(message)
			{
				Messages::LogError("%s::%s@L%d - %s - %s", className, function, line, message, LookupErrorCode(error));
			}
			else
			{
				Messages::LogError("%s::%s@L%d - %s", className, function, line, LookupErrorCode(error));
			}
		}
		return error;
	}

	ErrorCode ProcessResult(ErrorCode error, bool log, const char* message)
	{
		log &= gLogErrors;
		if(log && error != SG_OK)
		{
			Messages::LogError(message);
		}
		return error;
	}

	ErrorCode ProcessResult(ErrorCode error, bool log)
	{
		log &= gLogErrors;
		if(log && error != SG_OK)
		{
			Messages::LogError(LookupErrorCode(error));
		}
		return error;
	}

	ResultCode::ResultCode(const char* className)
		: m_className(className)
		, m_LastError(SG_OK)
		, m_LastErrorSCE(0)
	{
	}

	ErrorCode ResultCode::SetResultSCE(int sceError, bool log, const char* function, int line, const char* message)
	{
		m_LastErrorSCE = sceError;
		m_LastError = ProcessSceResult(sceError, log, m_className, function, line, message);
		return m_LastError;
	}

	ErrorCode ResultCode::SetResultSCE(int sceError, bool log, const char* message)
	{
		m_LastErrorSCE = sceError;
		m_LastError = ProcessSceResult(sceError, log, message);
		return m_LastError;
	}

	ErrorCode ResultCode::SetResultSCE(int sceError, bool log)
	{
		m_LastErrorSCE = sceError;
		m_LastError = ProcessSceResult(sceError, log);
		return m_LastError;
	}

	ErrorCode ResultCode::SetResult(ErrorCode errorCode, bool log, const char* function, int line, const char* message)
	{
		m_LastErrorSCE = 0;
		m_LastError = ProcessResult(errorCode, log, m_className, function, line, message);
		return m_LastError;
	}

	ErrorCode ResultCode::SetResult(ErrorCode errorCode, bool log, const char* message)
	{
		m_LastErrorSCE = 0;
		m_LastError = ProcessResult(errorCode, log, message);
		return m_LastError;
	}

	ErrorCode ResultCode::SetResult(ErrorCode errorCode, bool log)
	{
		m_LastErrorSCE = 0;
		m_LastError = ProcessResult(errorCode, log);
		return m_LastError;
	}

	const char* LookupSceErrorCode(int errorCode)
	{
		static char defaultErrorString[16];
		const char* errorString = NULL;

		switch(errorCode)
		{
			CASE_ERROR_TO_STRING(SCE_APPUTIL_ERROR_PARAMETER)
			CASE_ERROR_TO_STRING(SCE_APPUTIL_ERROR_NOT_INITIALIZED)
			CASE_ERROR_TO_STRING(SCE_APPUTIL_ERROR_NO_MEMORY)
			CASE_ERROR_TO_STRING(SCE_APPUTIL_ERROR_BUSY)
			CASE_ERROR_TO_STRING(SCE_APPUTIL_ERROR_NOT_MOUNTED)
			CASE_ERROR_TO_STRING(SCE_APPUTIL_ERROR_SAVEDATA_NO_SPACE_QUOTA)
			CASE_ERROR_TO_STRING(SCE_APPUTIL_ERROR_SAVEDATA_NO_SPACE_FS)
			CASE_ERROR_TO_STRING(SCE_APPUTIL_ERROR_SAVEDATA_SLOT_EXISTS)
			CASE_ERROR_TO_STRING(SCE_APPUTIL_ERROR_SAVEDATA_SLOT_NOT_FOUND)

			CASE_ERROR_TO_STRING(SCE_COMMON_DIALOG_ERROR_BUSY)
			CASE_ERROR_TO_STRING(SCE_COMMON_DIALOG_ERROR_NULL)
			CASE_ERROR_TO_STRING(SCE_COMMON_DIALOG_ERROR_NOT_RUNNING)
			CASE_ERROR_TO_STRING(SCE_COMMON_DIALOG_ERROR_NOT_FINISHED)
			CASE_ERROR_TO_STRING(SCE_COMMON_DIALOG_ERROR_NOT_IN_USE)
			CASE_ERROR_TO_STRING(SCE_COMMON_DIALOG_ERROR_INVALID_INFOBAR_PARAM)
			CASE_ERROR_TO_STRING(SCE_COMMON_DIALOG_ERROR_INVALID_BG_COLOR)
			CASE_ERROR_TO_STRING(SCE_COMMON_DIALOG_ERROR_INVALID_DIMMER_COLOR)
			CASE_ERROR_TO_STRING(SCE_COMMON_DIALOG_ERROR_UNEXPECTED_FATAL)

			CASE_ERROR_TO_STRING(SCE_ERROR_ERRNO_EBADF)

			default:
				sprintf(defaultErrorString, "0x%08x", errorCode);
				errorString = defaultErrorString;
				break;
		}

		return errorString;
	}

}	// namespace UnityNp
