#include <stdio.h>
#include <kernel.h>
#include <moduleinfo.h>
#include <libsysmodule.h>

#include "prx.h"
#include "PlayerInterface/UnityPrxPlugin.h"
#include "PlayerInterface/IPluginPSP2.h"
#include "SavedGame.h"
#include "SavedGameList.h"
#include "IOThread.h"
#include "MessagePipe.h"

SCE_MODULE_INFO(SavedGames, SCE_MODULE_ATTR_NONE, 1, 1);

extern "C" int module_start(SceSize sz, const void* arg)
{
	if (!ProcessPrxPluginArgs(sz, arg, "SavedGames"))
	{
		// Failed.
		return SCE_KERNEL_START_NO_RESIDENT;
	}

	return SCE_KERNEL_START_SUCCESS;
}

namespace UnitySavedGames
{
	IOThread s_IOThread;
	IPluginPSP2* g_IPSP2 = NULL;

	void SetupRuntimeInterfaces()
	{
		if(g_QueryInterface)
		{
			g_IPSP2 = GetRuntimeInterface<IPluginPSP2>(PRX_PLUGIN_IFACE_ID_PSP2);
		}
	}

	// Remap a Unix style path to a Vita style path if required.
	// Note that the remapped string is stored statically and is overwritten the next
	// time this function is called, also not thread safe.
	const char* RemapPath(const char* path)
	{
		if (g_IPSP2)
		{
			static char buffer[512];
			g_IPSP2->RemapUnixPath(buffer, path, sizeof(buffer));
			return buffer;
		}
		return path;
	}

	PRX_EXPORT int PrxSavedGamesInitialise()
	{
		SetupRuntimeInterfaces();
		gSavedGame.SetIOThread(&s_IOThread);
		gSavedGameList.SetIOThread(&s_IOThread);
		return 0;
	}

	PRX_EXPORT void PrxSavedGamesUpdate()
	{
		gSavedGame.Update();
		gSavedGameList.Update();
	}

	PRX_EXPORT bool PrxSavedGamesGetLastError(ResultCode* result)
	{
		if(!gSavedGame.GetLastError(result))
		{
			return false;
		}

		return gSavedGameList.GetLastError(result);
	}

	PRX_EXPORT ErrorCode PrxSetEmptySlotIconPath(const char* iconPath)
	{
		ErrorCode res = gSavedGame.SetEmptyIconPath(iconPath);
		if(res != SG_OK)
		{
			return res;
		}
		return gSavedGameList.SetEmptyIconPath(iconPath);
	}

	PRX_EXPORT bool PrxIsSavedGamesDialogOpen()
	{
		return gSavedGame.IsDialogOpen() || gSavedGameList.IsDialogOpen();
	}

	PRX_EXPORT bool PrxIsSavedGamesBusy()
	{
		return gSavedGame.IsBusy() || gSavedGameList.IsBusy();
	}

	PRX_EXPORT ErrorCode PrxSavedGameGetGameData(SavedGameData* data)
	{
		data->data = NULL;
		data->dataSize = 0;

		if(s_IOThread.GetBuffer())
		{
			data->data = s_IOThread.GetBuffer();
			data->dataSize = s_IOThread.GetBufferSize();
			return SG_OK;
		}
		return SG_ERR_NO_DATA;
	}

}; // UnitySavedGames
