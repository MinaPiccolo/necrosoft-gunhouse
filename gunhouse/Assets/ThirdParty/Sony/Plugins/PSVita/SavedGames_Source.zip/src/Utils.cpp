#include <string>
#include <common_dialog/common_api.h>
#include "Utils.h"

bool CommonDialogIsRunning()
{
	return sceCommonDialogIsRunning();
}
