#ifndef _ERRORCODES_H
#define _ERRORCODES_H

#include "prx.h"
#include <apputil.h>
#include "SimpleLock.h"

namespace UnitySavedGames
{
	// NOTE, if changing this enum you need to make the same changes to the enum in SavedGames\Assemblies\SonyVitaSavedGames\ErrorCodes.cs
	enum ErrorCode
	{
		SG_OK,
		SG_ERR_COMMON_DIALOG_BUSY,				// Something else is using the common dialog so the action could not be performed.
		SG_ERR_BUSY,							// The system is busy.
		SG_ERR_FAILED,							// General failure, check the log for more info.
		SG_ERR_BAD_STATE,						// Somethings gone wrong with the logic, most likely a bug in the native plugin code.
		SG_ERR_INDEX_OUT_OF_RANGE,				// An out of range array index was specified.
		SG_ERR_ICON_PATH_TOO_LONG,				// Icon path exceeds the maximum allowed length.
		SG_ERR_TOO_MANY_SLOTS,					// Requested number of slots exceeds maximum allowed.
		SG_ERR_DIALOG_OPEN,						// Unable to start because a dialog is already open.
		SG_ERR_BAD_FILE,						// Bad file data or invalid header detected.
		SG_ERR_NO_SPACE_QUOTA,					// Save quota exceeded.
		SG_ERR_NO_SPACE,						// No space on the memory card.
		SG_ERR_NO_MEM_CARD,						// No memory card.
		SG_ERR_NO_DATA,							// No data loaded.
		SG_ERR_SLOT_NOT_FOUND,					// Slot not found.
		SG_ERR_NOT_INITIALIZED,					// The system hasn't been initialized.
	};

	PRX_EXPORT bool PrxSavedGamesGetLoggingEnabled();
	PRX_EXPORT void PrxSavedGamesSetLoggingEnabled(bool enabled);

	// Helper functions, translates an sceError into an ErrorCode and logs.
	ErrorCode ProcessSceResult(int sceError, bool log, const char* className, const char* function, int line, const char* message);
	ErrorCode ProcessSceResult(int sceError, bool log, const char* message);
	ErrorCode ProcessSceResult(int sceError, bool log);

	// Helper functions, logs an ErrorCode.
	ErrorCode ProcessResult(ErrorCode error, bool log, const char* className, const char* function, int line, const char* message);
	ErrorCode ProcessResult(ErrorCode error, bool log, const char* message);
	ErrorCode ProcessResult(ErrorCode error, bool log);

	// Lookup an error and return a string version.
	const char* LookupErrorCode(ErrorCode errorCode);

	// Translate an SCE error code into a Unity NP error code.
	ErrorCode TranslateSceError(int sceErrorCode);

	// Lookup an SCE error and return a string version.
	const char* LookupSceErrorCode(int errorCode);

	class ResultCode
	{
	public:
		const char* m_className;
		ErrorCode m_LastError;
		int m_LastErrorSCE;

	public:
		ResultCode(const char* className);

		ErrorCode GetResult() const { return m_LastError; }
		int GetResultSCE() const { return m_LastErrorSCE; }
		void Reset() { m_LastError = SG_OK; m_LastErrorSCE = 0; }

		ErrorCode SetResultSCE(int sceErrorCode, bool log, const char* function, int line, const char* message=NULL);
		ErrorCode SetResultSCE(int sceErrorCode, bool log, const char* message);
		ErrorCode SetResultSCE(int sceError, bool log);
		ErrorCode SetResult(ErrorCode errorCode, bool log, const char* function, int line, const char* message=NULL);
		ErrorCode SetResult(ErrorCode errorCode, bool log, const char* message);
		ErrorCode SetResult(ErrorCode errorCode, bool log);
	};
}

#endif // _ERRORCODES_H
