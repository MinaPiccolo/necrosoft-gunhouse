#ifndef _UTILS_H
#define _UTILS_H

bool CommonDialogIsRunning();

#endif
