#include "SavedGame.h"
#include "ErrorCodes.h"
#include "Utils.h"
#include <savedata_dialog.h>
#include <rtc.h>

namespace UnitySavedGames
{
	PRX_EXPORT ErrorCode PrxSavedGameSave(void* data, int dataSize, int slotNumber, SavedGameSlotParams* slotParams, int controlFlags)
	{
		return gSavedGame.Save(data, dataSize, slotNumber, slotParams, controlFlags);
	}

	PRX_EXPORT ErrorCode PrxSavedGameLoad(int slotNumber)
	{
		return gSavedGame.Load(slotNumber);
	}
	
	PRX_EXPORT ErrorCode PrxSavedGameAutoSave(void* data, int dataSize, int slotNumber, SavedGameSlotParams* slotParams, int controlFlags)
	{
		return gSavedGame.AutoSave(data, dataSize, slotNumber, slotParams, controlFlags);
	}

	PRX_EXPORT ErrorCode PrxSavedGameAutoLoad(int slotNumber)
	{
		return gSavedGame.AutoLoad( slotNumber );
	}

	PRX_EXPORT ErrorCode PrxSavedGameAutoDeleteSlot(int slotNumber)
	{
		return gSavedGame.DeleteSlot(slotNumber, true);
	}

	PRX_EXPORT ErrorCode PrxSavedGameDeleteSlot(int slotNumber)
	{
		return gSavedGame.DeleteSlot(slotNumber, false);
	}

	PRX_EXPORT ErrorCode PrxSavedGameGetSlotInfo(int slotNumber, SavedGameSlotInfo* info)
	{
		return gSavedGame.GetSlotInfo(slotNumber, info);
	}

	PRX_EXPORT int PrxSavedGameGetQuota()
	{
		SceSize quotaSizeKiB;
		int res = sceAppUtilSaveDataGetQuota(&quotaSizeKiB, NULL, NULL);
		return quotaSizeKiB;
	}

	PRX_EXPORT int PrxSavedGameGetUsedSize()
	{
		SceSize usedSizeKiB;
		int res = sceAppUtilSaveDataGetQuota(NULL, &usedSizeKiB, NULL);
		return usedSizeKiB;
	}

	SavedGame gSavedGame;

	SavedGame::SavedGame()
		: m_DialogOpen(false)
		, m_Busy(false)
		, m_SavedDataDialogState(SAVEDATA_DIALOG_STEP_NONE)
		, m_SavedDataDialogMode(SAVEDATA_DIALOG_MODE_NONE)
		, m_IOThread(NULL)
		, m_ConfirmCancel(true)
		, m_autoMode(false)
		, m_DialogEndMessage(Messages::kSavedGame_NotSet)
		, m_ControlFlags(0)
		, m_LastResult("SavedGame")
	{
	}

	SavedGame::~SavedGame()
	{
	}
	
	ErrorCode SavedGame::SetEmptyIconPath(const char* iconPath)
	{
		const char* path = RemapPath(iconPath);
		m_LastResult.Reset();
		if(strlen(path) > SCE_APPUTIL_SAVEDATA_SLOT_ICON_PATH_MAXSIZE-1)
		{
			return m_LastResult.SetResult(SG_ERR_ICON_PATH_TOO_LONG, true, __FUNCTION__, __LINE__);
		}

		m_slotEmptyIconPath = path;
		return m_LastResult.GetResult();
	}

	ErrorCode SavedGame::GetSlotInfo(int slotNumber, SavedGameSlotInfo* info)
	{
		if (IsBusy())
		{
			return m_LastResult.SetResult(SG_ERR_BUSY, true, __FUNCTION__, __LINE__);
		}

		m_LastResult.Reset();

		static SceAppUtilSaveDataSlotParam slotParam;
		memset(&slotParam, 0, sizeof(SceAppUtilSaveDataSlotParam));
		int res = sceAppUtilSaveDataSlotGetParam(slotNumber, &slotParam, NULL);

		if (res == SCE_OK || res == SCE_APPUTIL_ERROR_SAVEDATA_SLOT_NOT_FOUND)
		{
			info->status = slotParam.status;
			info->sizeKiB = slotParam.sizeKiB;	// Always 0, probably need to ask SCE about this.
			info->title = (const char*)slotParam.title;		
			info->subTitle = (const char*)slotParam.subTitle;
			info->detail = (const char*)slotParam.detail;
			info->iconPath = (const char*)slotParam.iconPath;

			// Convert SceDateTime to .NET DateTime ticks.
			UInt64 ticks = 0;
			slotParam.modifiedTime.year += 1600;
			sceRtcGetTime64_t(&slotParam.modifiedTime, &ticks);
			ticks = ticks * 10000000 + 116444736000000000ULL;
			info->modifiedTime = ticks;

			if(res == SCE_APPUTIL_ERROR_SAVEDATA_SLOT_NOT_FOUND)
			{
				m_LastResult.SetResult(SG_ERR_SLOT_NOT_FOUND, false);
			}
		}
		else
		{
			m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
		}
		return m_LastResult.GetResult();
	}

	void SavedGame::InitIOThreadSlotParams(const SavedGameSlotParams* slotParams, IOThreadSlotParams& params)
	{
		params.title = slotParams->title ? slotParams->title : "";
		params.subTitle = slotParams->subTitle ? slotParams->subTitle : "";
		params.detail = slotParams->detail ? slotParams->detail : "";
		params.iconPath = slotParams->iconPath ? RemapPath(slotParams->iconPath) : "";
	}

	ErrorCode SavedGame::Save(void* data, int dataSize, int slotNumber, SavedGameSlotParams* slotParams, int controlFlags)
	{
		if(!IsInitialized())
		{
			return m_LastResult.SetResult(SG_ERR_NOT_INITIALIZED, true, __FUNCTION__, __LINE__);
		}

		if(IsBusy())
		{
			return m_LastResult.SetResult(SG_ERR_BUSY, true, __FUNCTION__, __LINE__);
		}

		if(CommonDialogIsRunning())
		{
			return m_LastResult.SetResult(SG_ERR_COMMON_DIALOG_BUSY, true, __FUNCTION__, __LINE__);
		}

		m_ControlFlags = controlFlags;
		IOThreadSlotParams params;
		InitIOThreadSlotParams(slotParams, params);
		m_IOThread->SetSlotParams(params);
		m_SlotNumber = slotNumber < 0 ? SAVEDATA_FIXED_TARGET_SLOT : slotNumber; 
		m_ConfirmCancel = true;
		m_autoMode = false;

		return StartSaveLoad(IOMODE_SAVE, dataSize, data);
	}
	
	ErrorCode SavedGame::Load(int slotNumber)
	{
		if(!IsInitialized())
		{
			return m_LastResult.SetResult(SG_ERR_NOT_INITIALIZED, true, __FUNCTION__, __LINE__);
		}

		if(IsBusy())
		{
			return m_LastResult.SetResult(SG_ERR_BUSY, true, __FUNCTION__, __LINE__);
		}

		if(CommonDialogIsRunning())
		{
			return m_LastResult.SetResult(SG_ERR_COMMON_DIALOG_BUSY, true, __FUNCTION__, __LINE__);
		}

		m_SlotNumber = slotNumber < 0 ? SAVEDATA_FIXED_TARGET_SLOT : slotNumber; 
		m_ConfirmCancel = true;
		m_autoMode = false;

		return StartSaveLoad(IOMODE_LOAD, 0, NULL);
	}

	ErrorCode SavedGame::DeleteSlot(int slotNumber, bool silent)
	{
		if(!IsInitialized())
		{
			return m_LastResult.SetResult(SG_ERR_NOT_INITIALIZED, true, __FUNCTION__, __LINE__);
		}

		if(IsBusy())
		{
			return m_LastResult.SetResult(SG_ERR_BUSY, true, __FUNCTION__, __LINE__);
		}

		if(CommonDialogIsRunning())
		{
			return m_LastResult.SetResult(SG_ERR_COMMON_DIALOG_BUSY, true, __FUNCTION__, __LINE__);
		}

		m_SlotNumber = slotNumber; 
		m_ConfirmCancel = false;
		m_autoMode = silent;

		return StartSaveLoad(IOMODE_DELETE, 0, NULL);
	}

	ErrorCode SavedGame::AutoSave(void* data, int dataSize, int slotNumber, SavedGameSlotParams* slotParams, int controlFlags)
	{
		if(!IsInitialized())
		{
			return m_LastResult.SetResult(SG_ERR_NOT_INITIALIZED, true, __FUNCTION__, __LINE__);
		}

		if(IsBusy())
		{
			return m_LastResult.SetResult(SG_ERR_BUSY, true, __FUNCTION__, __LINE__);
		}

		if(CommonDialogIsRunning())
		{
			return m_LastResult.SetResult(SG_ERR_COMMON_DIALOG_BUSY, true, __FUNCTION__, __LINE__);
		}

		m_ControlFlags = controlFlags;
		IOThreadSlotParams params;
		InitIOThreadSlotParams(slotParams, params);
		m_IOThread->SetSlotParams(params);
		m_SlotNumber = slotNumber; 
		m_ConfirmCancel = false;
		m_autoMode = true;

		return StartSaveLoad(IOMODE_SAVE, dataSize, data);
	}

	ErrorCode SavedGame::AutoLoad(int slotNumber)
	{
		if(!IsInitialized())
		{
			return m_LastResult.SetResult(SG_ERR_NOT_INITIALIZED, true, __FUNCTION__, __LINE__);
		}

		if(IsBusy())
		{
			return m_LastResult.SetResult(SG_ERR_BUSY, true, __FUNCTION__, __LINE__);
		}

		if(CommonDialogIsRunning())
		{
			return m_LastResult.SetResult(SG_ERR_COMMON_DIALOG_BUSY, true, __FUNCTION__, __LINE__);
		}

		m_SlotNumber = slotNumber; 
		m_ConfirmCancel = false;
		m_autoMode = true;

		return StartSaveLoad(IOMODE_LOAD, 0, NULL);
	}

	int SavedGame::InitDialog(DialogMode mode)
	{
		SceSaveDataDialogParam		sddParam;
		SceSaveDataDialogFixedParam	sddFixed;

		int		res = SCE_OK;

		sceSaveDataDialogParamInit(&sddParam);
		sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_FIXED;

		if (mode == SAVEDATA_DIALOG_MODE_SAVE)
		{
			sddParam.dispType = SCE_SAVEDATA_DIALOG_TYPE_SAVE;
			m_DialogEndMessage = Messages::kSavedGame_GameSaved;
		}
		else if (mode == SAVEDATA_DIALOG_MODE_LOAD)
		{
			sddParam.dispType = SCE_SAVEDATA_DIALOG_TYPE_LOAD;
			m_DialogEndMessage = Messages::kSavedGame_GameLoaded;
		}
		else if (mode == SAVEDATA_DIALOG_MODE_DELETE)
		{
			sddParam.dispType = SCE_SAVEDATA_DIALOG_TYPE_DELETE;
			m_DialogEndMessage = Messages::kSavedGame_GameDeleted;
		}
		else
		{
			return -1;
		}

		memset(&sddFixed, 0, sizeof(SceSaveDataDialogFixedParam));
		memset(&m_slotEmptyParam, 0, sizeof(SceAppUtilSaveDataSlotEmptyParam));

		sddParam.fixedParam = &sddFixed;
		sddFixed.targetSlot.id = m_SlotNumber;

		m_slotEmptyParam.iconPath = (SceChar8*)m_slotEmptyIconPath.c_str();

		if (!m_autoMode)	// if we are autoload/save we don't want to startup the dialog until required
		{
			res = sceSaveDataDialogInit(&sddParam);
			if (res != SCE_OK)
			{
				m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
				return res;
			}
			m_DialogOpen = true;
		}

		m_SavedDataDialogState = m_autoMode ? SAVEDATA_DIALOG_STEP_AUTO : SAVEDATA_DIALOG_STEP_FIXED;
		m_SavedDataDialogMode = mode;

		m_Busy = true;

		return res;
	}


	int SavedGame::InitDialogForAutoSaveError()
	{
		SceSaveDataDialogParam		sddParam;
		SceSaveDataDialogFixedParam	sddFixed;

		int		res = SCE_OK;

		sceSaveDataDialogParamInit(&sddParam);
		sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_FIXED;

		if (m_SavedDataDialogMode == SAVEDATA_DIALOG_MODE_SAVE)
		{
			sddParam.dispType = SCE_SAVEDATA_DIALOG_TYPE_SAVE;
		}
		else if (m_SavedDataDialogMode == SAVEDATA_DIALOG_MODE_LOAD)
		{
			sddParam.dispType = SCE_SAVEDATA_DIALOG_TYPE_LOAD;
		}
		else if (m_SavedDataDialogMode == SAVEDATA_DIALOG_MODE_DELETE)
		{
			sddParam.dispType = SCE_SAVEDATA_DIALOG_TYPE_DELETE;
		}
		else
		{
			return -1;
		}

		memset(&sddFixed, 0, sizeof(SceSaveDataDialogFixedParam));
		memset(&m_slotEmptyParam, 0, sizeof(SceAppUtilSaveDataSlotEmptyParam));

		sddParam.fixedParam = &sddFixed;
		sddFixed.targetSlot.id = m_SlotNumber;

		m_slotEmptyParam.iconPath = (SceChar8*)m_slotEmptyIconPath.c_str();

		res = sceSaveDataDialogInit(&sddParam);
		if (res != SCE_OK)
		{
			m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			return res;
		}

		m_DialogOpen = true;
		m_Busy = true;

		return res;
	}

	ErrorCode SavedGame::StartSaveLoad(IOThreadMode mode, int size, void *buffer)
	{
		DialogMode dialogMode;
		int res;

		m_LastResult.Reset();

		if (m_IOThread->GetStatus() != THREAD_STOPPED)
		{
			m_LastResult.SetResult(SG_ERR_BUSY, true, __FUNCTION__, __LINE__);
			Messages::AddMessage(Messages::kSavedGame_SaveGenericError);
			return m_LastResult.GetResult();
		}

		// Set IO thread parameters
		m_IOThread->SetBuffer(size, buffer);
		m_IOThread->SetResult(0);

		if (mode == IOMODE_SAVE)
		{
			dialogMode = SAVEDATA_DIALOG_MODE_SAVE;
		}
		else if (mode == IOMODE_LOAD)
		{
			dialogMode = SAVEDATA_DIALOG_MODE_LOAD;
		}
		else if (mode == IOMODE_DELETE)
		{
			dialogMode = SAVEDATA_DIALOG_MODE_DELETE;
		}

		// Open dialog
		res = InitDialog(dialogMode);
		if (res != SCE_OK)
		{
			m_LastResult.SetResult(SG_ERR_DIALOG_OPEN, true, __FUNCTION__, __LINE__);
			m_IOThread->SetStatus(THREAD_END);
			Messages::AddMessage(Messages::kSavedGame_SaveGenericError);
			return m_LastResult.GetResult();
		}

		return m_LastResult.GetResult();
	}

	int SavedGame::ShutdownIOThread(void)
	{
		m_IOThread->Stop();

		return SCE_OK;
	}

	int SavedGame::ShutdownDialog(void)
	{
		int		res;

		m_SavedDataDialogMode = SAVEDATA_DIALOG_MODE_NONE;

		// Terminate dialog
		res = sceSaveDataDialogTerm();
		if ( (res != SCE_OK) && (m_autoMode && (res != SCE_COMMON_DIALOG_ERROR_NOT_IN_USE)) )
		{
			m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			return res;
		}

		// Shutdown IO thread
		ShutdownIOThread();

		m_DialogOpen = false;
		m_Busy = false;

		return SCE_OK;
	}

	int SavedGame::Update(void)
	{
		if(!IsBusy())
		{
			return 0;
		}

		SceCommonDialogStatus				cdStatus;
		SceCommonDialogStatus				cdSubStatus;
		SceSaveDataDialogParam				sddParam;
		SceSaveDataDialogSystemMessageParam	sddSysMsg;
		SceSaveDataDialogErrorCodeParam		sddErrCode;
		SceSaveDataDialogFinishParam		sddFinish;
		SceSaveDataDialogResult				sddResult;
		SceSaveDataDialogSlotInfo			sddSlotInfo;
		SceAppUtilSaveDataSlotParam			sddSlotParam;
		int		res;

		if (m_SavedDataDialogState == SAVEDATA_DIALOG_STEP_NONE)
			return m_SavedDataDialogState;

		// if we are in automode ... we have no dialog to check, so wait for thread status to change 
		if (m_autoMode == true) 
		{
			if	((m_IOThread->GetStatus() == THREAD_INIT)||(m_IOThread->GetStatus() == THREAD_RUNNING) )
			{
				return SCE_COMMON_DIALOG_STATUS_RUNNING;
			}
			// ok automode completed ... now drop through and check the status
		}
		else
		{
			// Get dialog status
			cdStatus = sceSaveDataDialogGetStatus();

			switch (cdStatus)
			{
				default:
				case SCE_COMMON_DIALOG_STATUS_NONE:
					return cdStatus;

				case SCE_COMMON_DIALOG_STATUS_RUNNING:
					// Get dialog sub-status
					cdSubStatus = sceSaveDataDialogGetSubStatus();
					if (cdSubStatus != SCE_COMMON_DIALOG_STATUS_FINISHED)
					{
						return cdSubStatus;
					}
					break;

				case SCE_COMMON_DIALOG_STATUS_FINISHED:
					break;
			}


			// Get dialog result
			memset(&sddResult, 0, sizeof(SceSaveDataDialogResult));
			memset(&sddSlotInfo, 0, sizeof(SceSaveDataDialogSlotInfo));
			memset(&sddSlotParam, 0, sizeof(SceAppUtilSaveDataSlotParam));
			sddResult.slotInfo = &sddSlotInfo;
			sddResult.slotInfo->slotParam = &sddSlotParam;

			res = sceSaveDataDialogGetResult(&sddResult);
			if (res != SCE_OK)
			{
				m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
				return res;
			}

			if (sddResult.result < 0)
			{
				m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
				return sddResult.result;
			}

			if (sddResult.result == SCE_COMMON_DIALOG_RESULT_ABORTED)
			{
				m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_END_CANCELED;
			}
		}

		switch (m_SavedDataDialogState)
		{
			case SAVEDATA_DIALOG_STEP_FIXED:
				memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

				sceSaveDataDialogParamInit(&sddParam);
				sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
				sddParam.sysMsgParam = &sddSysMsg;
				sddSysMsg.targetSlot.id = m_SlotNumber;
				sddSysMsg.targetSlot.emptyParam = &m_slotEmptyParam;

				if (m_SavedDataDialogMode == SAVEDATA_DIALOG_MODE_SAVE)
				{
					// check save data exist
					if (sddResult.slotInfo->isExist)
						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_OVERWRITE;
					else
						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_CONFIRM;

					m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_CONFIRM;
				}
				else {
					// check save data exist
					if (sddResult.slotInfo->isExist)
					{
						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_CONFIRM;

						m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_CONFIRM;
					}
					else
					{
						m_DialogEndMessage = Messages::kSavedGame_LoadNoData;

						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_NODATA;
						// save data thread status to END
						m_IOThread->SetStatus(THREAD_END);
						sddSysMsg.targetSlot.emptyParam = NULL;

						m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_FINISH;
					}
				}

				res = sceSaveDataDialogContinue(&sddParam);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}
				break;

			case SAVEDATA_DIALOG_STEP_CONFIRM:
				// 'NO' button pushed or canceled
				if (sddResult.result == SCE_COMMON_DIALOG_RESULT_USER_CANCELED ||
					sddResult.buttonId == SCE_SAVEDATA_DIALOG_BUTTON_ID_NO )
				{
					if (m_ConfirmCancel)
					{
						memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

						sceSaveDataDialogParamInit(&sddParam);
						sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
						sddParam.sysMsgParam = &sddSysMsg;
						sddSysMsg.targetSlot.id = m_SlotNumber;
						sddSysMsg.targetSlot.emptyParam = &m_slotEmptyParam;
						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_CONFIRM_CANCEL;

						res = sceSaveDataDialogContinue(&sddParam);
						if (res != SCE_OK)
						{
							m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
							return res;
						}

						m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_CONFIRM_CANCEL;
					}
					else
					{
						m_DialogEndMessage = Messages::kSavedGame_Canceled;
						m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_FINISH;
					}
				}
				// 'YES' button pushed
				else if (sddResult.result == SCE_OK)
				{
					// broken save data existed, display error dialog
					if (m_SavedDataDialogMode == SAVEDATA_DIALOG_MODE_LOAD &&
						sddSlotParam.status == SCE_APPUTIL_SAVEDATA_SLOT_STATUS_BROKEN)
					{
							m_DialogEndMessage = Messages::kSavedGame_LoadCorrupted;

							memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

							sceSaveDataDialogParamInit(&sddParam);
							sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
							sddParam.sysMsgParam = &sddSysMsg;

							sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_FILE_CORRUPTED;
							sddSysMsg.targetSlot.id = m_SlotNumber;
							sddSysMsg.targetSlot.emptyParam = &m_slotEmptyParam;

							res = sceSaveDataDialogContinue(&sddParam);
							if (res != SCE_OK)
							{
								m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
								return res;
							}

							// save data thread status to END
							m_IOThread->SetStatus(THREAD_END);

							m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_FINISH;
							break;
					}

					memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

					sceSaveDataDialogParamInit(&sddParam);
					sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
					sddParam.sysMsgParam = &sddSysMsg;

					sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_PROGRESS;
					sddSysMsg.targetSlot.id = m_SlotNumber;
					sddSysMsg.targetSlot.emptyParam = &m_slotEmptyParam;

					res = sceSaveDataDialogContinue(&sddParam);
					if (res != SCE_OK)
					{
						m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
						return res;
					}

					switch (m_SavedDataDialogMode)
					{
					case SAVEDATA_DIALOG_MODE_SAVE:
						// start save thread
						m_IOThread->Start(IOMODE_SAVE, m_SlotNumber );
						break;

					case SAVEDATA_DIALOG_MODE_LOAD:
						// start load thread
						m_IOThread->Start(IOMODE_LOAD, m_SlotNumber );
						break;

					case SAVEDATA_DIALOG_MODE_DELETE:
						// start delete thread
						m_IOThread->Start(IOMODE_DELETE, m_SlotNumber );
						break;
					}

					m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_SAVING;
				}
				break;

			case SAVEDATA_DIALOG_STEP_AUTO:
				switch (m_SavedDataDialogMode)
				{
					case SAVEDATA_DIALOG_MODE_SAVE:
						// start save thread
						m_IOThread->Start(IOMODE_SAVE, m_SlotNumber );
						break;

					case SAVEDATA_DIALOG_MODE_LOAD:
						// start load thread
						m_IOThread->Start(IOMODE_LOAD, m_SlotNumber );
						break;

					case SAVEDATA_DIALOG_MODE_DELETE:
						// start delete thread
						m_IOThread->Start(IOMODE_DELETE, m_SlotNumber );
						break;
				}

				m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_AUTOSAVING;
				break;

			case SAVEDATA_DIALOG_STEP_CONFIRM_CANCEL:
				// 'NO' button pushed or canceled
				if (sddResult.result == SCE_COMMON_DIALOG_RESULT_USER_CANCELED ||
					sddResult.buttonId == SCE_SAVEDATA_DIALOG_BUTTON_ID_NO )
				{
						// retry confirmation of saving/loading
						m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_FIXED;
				}
				// 'YES' button pushed
				else if (sddResult.result == SCE_OK)
				{
					memset(&sddFinish, 0, sizeof(SceSaveDataDialogFinishParam));

					res = sceSaveDataDialogFinish(&sddFinish);
					if (res != SCE_OK)
					{
						m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
						return res;
					}

					// save data thread status to END
					m_IOThread->SetStatus(THREAD_END);

					m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_END_CANCELED;
				}
				break;

			case SAVEDATA_DIALOG_STEP_AUTOSAVING:
				res = m_IOThread->GetResult();
				m_LastResult = m_IOThread->GetLastResult();

				if(res == SCE_ERROR_ERRNO_ENOENT)
				{
					m_DialogEndMessage = Messages::kSavedGame_LoadNoData;
					m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_END;
					break;
				}

				if(res == SCE_OK)
				{
					m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_END;
					break;
				}

				// Auto save doesn't initialise the dialog, so initialise it here so we can display the error.
				InitDialogForAutoSaveError();

				// if there was a problem, then automode is turned off, and we create a dialog
				m_autoMode = false;
				if(m_SavedDataDialogMode == SAVEDATA_DIALOG_MODE_SAVE)
				{
					// Set state to saving (non-auto), the saving state will pick up the error and display the appropriate dialog.
					m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_SAVING;
				}
				else
				{
					// Set state to saving (non-auto), the saving state will pick up the error and display the appropriate dialog.
					m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_AUTOLOAD_FAILED;
				}
				break;

			case SAVEDATA_DIALOG_STEP_AUTOLOAD_FAILED:
				m_DialogEndMessage = Messages::kSavedGame_LoadCorrupted;

				memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

				sceSaveDataDialogParamInit(&sddParam);
				sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
				sddParam.sysMsgParam = &sddSysMsg;

				sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_FILE_CORRUPTED;
				sddSysMsg.targetSlot.id = m_SlotNumber;
				sddSysMsg.targetSlot.emptyParam = &m_slotEmptyParam;

				res = sceSaveDataDialogContinue(&sddParam);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}

				m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_FINISH;
				break;

			case SAVEDATA_DIALOG_STEP_SAVING:
				res = m_IOThread->GetResult();
				m_LastResult = m_IOThread->GetLastResult();

				// saving/loading completed
				if (res == SCE_OK)
				{
					memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

					sceSaveDataDialogParamInit(&sddParam);
					sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
					sddParam.sysMsgParam = &sddSysMsg;

					sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_FINISHED;
					sddSysMsg.targetSlot.id = m_SlotNumber;
					sddSysMsg.targetSlot.emptyParam = &m_slotEmptyParam;
				}
				// 'Not enough space for write save data error occurred
				else if (res == SCE_APPUTIL_ERROR_SAVEDATA_NO_SPACE_FS || res == SCE_APPUTIL_ERROR_SAVEDATA_NO_SPACE_QUOTA)
				{
					m_DialogEndMessage = Messages::kSavedGame_SaveNoSpace;

					memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

					sceSaveDataDialogParamInit(&sddParam);
					sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
					sddParam.sysMsgParam = &sddSysMsg;

					sddSysMsg.sysMsgType = (m_ControlFlags & NOSPACE_DIALOG_NOT_CONTINUABLE != 0) ? SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_NOSPACE : SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_NOSPACE_CONTINUABLE;
					sddSysMsg.targetSlot.id = m_SlotNumber;
					sddSysMsg.targetSlot.emptyParam = &m_slotEmptyParam;
					sddSysMsg.value = m_IOThread->GetRequiredSizeKiB();
				}
				// occurred no device error
				else if ( res == SCE_APPUTIL_ERROR_NOT_MOUNTED )
				{
					m_DialogEndMessage = Messages::kSavedGame_SaveNotMounted;

					// display need-mc system dialog.
					memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

					sceSaveDataDialogParamInit(&sddParam);
					sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
					sddParam.sysMsgParam = &sddSysMsg;

					sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_NEED_MC_OPERATION;
					sddSysMsg.targetSlot.id = m_SlotNumber;
					sddSysMsg.targetSlot.emptyParam = &m_slotEmptyParam;

					res = sceSaveDataDialogContinue(&sddParam);
					if (res != SCE_OK)
					{
						m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
						return res;
					}

					m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_ALERT;
					m_IOThread->SetStatus(THREAD_INIT);

					return SCE_OK;
				}
				// other error occurred
				else
				{
					m_DialogEndMessage = Messages::kSavedGame_SaveGenericError;

					memset(&sddErrCode, 0, sizeof(SceSaveDataDialogErrorCodeParam));

					sceSaveDataDialogParamInit(&sddParam);
					sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_ERROR_CODE;
					sddParam.errorCodeParam = &sddErrCode;

					sddErrCode.targetSlot.id = m_SlotNumber;
					sddErrCode.targetSlot.emptyParam = &m_slotEmptyParam;
					sddErrCode.errorCode = res;
				}

				res = sceSaveDataDialogContinue(&sddParam);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}

				m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_FINISH;
				break;

			case SAVEDATA_DIALOG_STEP_ALERT:
				m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_FINISH;
				m_IOThread->SetStatus(THREAD_END);

				break;

			case SAVEDATA_DIALOG_STEP_FINISH:
				memset(&sddFinish, 0, sizeof(SceSaveDataDialogFinishParam));

				res = sceSaveDataDialogFinish(&sddFinish);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}

				m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_END;
				break;

			case SAVEDATA_DIALOG_STEP_END:
				Messages::AddMessage(m_DialogEndMessage);
				ShutdownDialog();
				m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_NONE;
				break;

			case SAVEDATA_DIALOG_STEP_END_CANCELED:
				Messages::AddMessage(Messages::kSavedGame_Canceled);
				ShutdownDialog();
				m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_NONE;
				break;
		}

		return SCE_OK;
	}

}
