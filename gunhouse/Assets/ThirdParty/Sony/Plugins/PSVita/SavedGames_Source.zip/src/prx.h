#ifndef _PRX_H
#define _PRX_H

#define PRX_EXPORT extern "C" __declspec (dllexport)

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <libdbg.h>
#include <assert.h>
#define Assert assert
#include "ErrorCodes.h"

#if NDEBUG
#define UNITY_TRACE(...)
#define UNITY_TRACEIF(condition, ...)
#else
#define UNITY_TRACE(...)				printf(__VA_ARGS__)
#define UNITY_TRACEIF(condition, ...)	if (condition) printf(__VA_ARGS__)
#endif

enum ControlFlags
{
	NOSPACE_DIALOG_NOT_CONTINUABLE = (1<<0),	// If saving triggers the "no space" dialog make it non-continuable.
};

namespace UnitySavedGames
{
	const char* RemapPath(const char* path);
};

#endif

