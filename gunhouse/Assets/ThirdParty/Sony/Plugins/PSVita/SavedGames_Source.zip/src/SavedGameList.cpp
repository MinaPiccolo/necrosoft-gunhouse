#include "SavedGameList.h"
#include "ErrorCodes.h"
#include "Utils.h"
#include <savedata_dialog.h>

namespace UnitySavedGames
{
	PRX_EXPORT ErrorCode PrxSavedGameSetSlotCount(int slotCount)
	{
		return gSavedGameList.SetSlotCount(slotCount);
	}

	PRX_EXPORT ErrorCode PrxSavedGameListSave(void* data, int dataSize, SavedGameListSlotParams* slotParams, int controlFlags)
	{
		return gSavedGameList.Save(data, dataSize, slotParams, controlFlags);
	}

	PRX_EXPORT ErrorCode PrxSavedGameListLoad()
	{
		return gSavedGameList.Load();
	}

	PRX_EXPORT ErrorCode PrxSavedGameListDelete()
	{
		return gSavedGameList.Delete();
	}

	SavedGameList gSavedGameList;

	SavedGameList::SavedGameList()
		: m_DialogOpen(false)
		, m_SavedDataDialogState(DIALOG_LIST_STEP_NONE)
		, m_SavedDataDialogMode(DIALOG_LIST_MODE_NONE)
		, m_IOThread(NULL)
		, m_SlotList(NULL)
		, m_SlotId(0)
		, m_DialogEndMessage(Messages::kSavedGame_NotSet)
		, m_ControlFlags(0)
		, m_LastResult("SavedGameList")
	{
		SetSlotCount(SAVEDATA_DEFAULT_MAX_SLOT_NUM);
	}

	SavedGameList::~SavedGameList()
	{
		delete[] m_SlotList;
	}

	ErrorCode SavedGameList::SetEmptyIconPath(const char* iconPath)
	{
		const char* path = RemapPath(iconPath);
		m_LastResult.Reset();
		if(strlen(path) > SCE_APPUTIL_SAVEDATA_SLOT_ICON_PATH_MAXSIZE-1)
		{
			return m_LastResult.SetResult(SG_ERR_ICON_PATH_TOO_LONG, true, __FUNCTION__, __LINE__);
		}

		m_SlotEmptyIconPath = path;
		return m_LastResult.GetResult();
	}

	ErrorCode SavedGameList::SetSlotCount(int slotCount)
	{
		m_LastResult.Reset();
		if(slotCount > SAVEDATA_MAX_ALLOWED_SLOTS)
		{
			return m_LastResult.SetResult(SG_ERR_TOO_MANY_SLOTS, true, __FUNCTION__, __LINE__);
		}

		delete[] m_SlotList;
		m_NumberOfSlots = slotCount;
		m_SlotList = new SceAppUtilSaveDataSlot[m_NumberOfSlots];
		return m_LastResult.GetResult();
	}

	ErrorCode SavedGameList::Save(void* data, int dataSize, SavedGameListSlotParams* slotParams, int controlFlags)
	{
		if(!IsInitialized())
		{
			return m_LastResult.SetResult(SG_ERR_NOT_INITIALIZED, true, __FUNCTION__, __LINE__);
		}

		if(CommonDialogIsRunning())
		{
			return m_LastResult.SetResult(SG_ERR_COMMON_DIALOG_BUSY, true, __FUNCTION__, __LINE__);
		}

		m_ControlFlags = controlFlags;
		IOThreadSlotParams params;
		params.title = slotParams->title;
		params.subTitle = slotParams->subTitle;
		params.detail = slotParams->detail;
		params.iconPath = RemapPath(slotParams->iconPath);
		m_IOThread->SetSlotParams(params);

		return StartSaveLoad(IOMODE_SAVE, dataSize, data);
	}

	ErrorCode SavedGameList::Load(void)
	{
		if(!IsInitialized())
		{
			return m_LastResult.SetResult(SG_ERR_NOT_INITIALIZED, true, __FUNCTION__, __LINE__);
		}

		if(CommonDialogIsRunning())
		{
			return m_LastResult.SetResult(SG_ERR_COMMON_DIALOG_BUSY, true, __FUNCTION__, __LINE__);
		}

		return StartSaveLoad(IOMODE_LOAD, 0, NULL);
	}

	ErrorCode SavedGameList::Delete(void)
	{
		if(!IsInitialized())
		{
			return m_LastResult.SetResult(SG_ERR_NOT_INITIALIZED, true, __FUNCTION__, __LINE__);
		}

		if(CommonDialogIsRunning())
		{
			return m_LastResult.SetResult(SG_ERR_COMMON_DIALOG_BUSY, true, __FUNCTION__, __LINE__);
		}

		return StartSaveLoad(IOMODE_DELETE, 0, NULL);
	}

	ErrorCode SavedGameList::StartSaveLoad(IOThreadMode mode, int size, void *buffer)
	{
		DialogListMode dialogMode;
		int res;

		m_LastResult.Reset();

		if (m_IOThread->GetStatus() != THREAD_STOPPED)
		{
			m_LastResult.SetResult(SG_ERR_BUSY, true, __FUNCTION__, __LINE__);
			Messages::AddMessage(Messages::kSavedGame_SaveGenericError);
			return m_LastResult.GetResult();
		}

		// Set IO thread parameters
		m_IOThread->SetBuffer(size, buffer);
		m_IOThread->SetResult(0);

		if (mode == IOMODE_SAVE)
		{
			dialogMode = DIALOG_LIST_MODE_SAVE;
		}
		else if (mode == IOMODE_LOAD)
		{
			dialogMode = DIALOG_LIST_MODE_LOAD;
		}
		else if (mode == IOMODE_DELETE)
		{
			dialogMode = DIALOG_LIST_MODE_DELETE;
		}

		// Open dialog
		res = InitDialog(dialogMode);
		if (res != SCE_OK)
		{
			m_LastResult.SetResult(SG_ERR_DIALOG_OPEN, true, __FUNCTION__, __LINE__);
			m_IOThread->SetStatus(THREAD_END);
			Messages::AddMessage(Messages::kSavedGame_SaveGenericError);
			return m_LastResult.GetResult();
		}

		return m_LastResult.GetResult();
	}

	int SavedGameList::InitDialog(DialogListMode mode)
	{
		SceSaveDataDialogParam		sddParam;
		SceSaveDataDialogListParam	sddList;
		int		res;

		sceSaveDataDialogParamInit(&sddParam);
		sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_LIST;

		// initialize slot list parameters
		memset(m_SlotList, 0, sizeof(SceAppUtilSaveDataSlot)*m_NumberOfSlots);
		memset(&m_SlotEmptyParam, 0, sizeof(SceAppUtilSaveDataSlotEmptyParam));

		m_SlotEmptyParam.iconPath = (SceChar8*)m_SlotEmptyIconPath.c_str();

		if (mode == DIALOG_LIST_MODE_SAVE)
		{
			sddParam.dispType = SCE_SAVEDATA_DIALOG_TYPE_SAVE;
			m_DialogEndMessage = Messages::kSavedGame_GameSaved;

			// set slot list parameters for displaying empty items
			for (int i=0; i<m_NumberOfSlots; i++)
			{
				m_SlotList[i].id = i;
				m_SlotList[i].emptyParam = &m_SlotEmptyParam;
			}
		}
		else if (mode == DIALOG_LIST_MODE_LOAD)
		{
			sddParam.dispType = SCE_SAVEDATA_DIALOG_TYPE_LOAD;
			m_DialogEndMessage = Messages::kSavedGame_GameLoaded;

			// set slot list parameters
			for (int i=0; i<m_NumberOfSlots; i++)
			{
				m_SlotList[i].id = i;
			}
		}
		else if (mode == DIALOG_LIST_MODE_DELETE)
		{
			sddParam.dispType = SCE_SAVEDATA_DIALOG_TYPE_DELETE;

			// set slot list parameters
			for (int i=0; i<m_NumberOfSlots; i++)
			{
				m_SlotList[i].id = i;
			}
		}
		else
		{
			return -1;
		}

		memset(&sddList, 0, sizeof(SceSaveDataDialogListParam));
		sddParam.listParam = &sddList;

		sddList.slotList = m_SlotList;
		sddList.slotListSize = m_NumberOfSlots;
		sddList.focusPos = SCE_SAVEDATA_DIALOG_FOCUS_POS_LISTHEAD;

		res = sceSaveDataDialogInit(&sddParam);
		if (res != SCE_OK)
		{
			m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			return res;
		}

		m_SavedDataDialogState = DIALOG_LIST_STEP_LIST;
		m_SavedDataDialogMode = mode;

		m_DialogOpen = true;

		return res;
	}

	int SavedGameList::ShutdownIOThread(void)
	{
		m_IOThread->Stop();

		return SCE_OK;
	}

	int SavedGameList::ShutdownDialog(void)
	{
		int		res;

		m_SavedDataDialogMode = DIALOG_LIST_MODE_NONE;

		// Terminate dialog
		res = sceSaveDataDialogTerm();
		if (res != SCE_OK)
		{
			m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			return res;
		}

		// Shutdown IO thread
		ShutdownIOThread();

		m_DialogOpen = false;

		return SCE_OK;
	}

	int SavedGameList::Update(void)
	{
		if(!m_DialogOpen)
		{
			return 0;
		}

		SceCommonDialogStatus				cdStatus;
		SceCommonDialogStatus				cdSubStatus;

		SceSaveDataDialogParam				sddParam;
		SceSaveDataDialogListParam			sddList;
		SceSaveDataDialogSystemMessageParam	sddSysMsg;
		SceSaveDataDialogErrorCodeParam		sddErrCode;
		SceSaveDataDialogFinishParam		sddFinish;
		SceSaveDataDialogResult				sddResult;
		SceSaveDataDialogSlotInfo			sddSlotInfo;

		SceAppUtilSaveDataSlotParam			sddSlotParam;

		int		res;

		if (m_SavedDataDialogState == DIALOG_LIST_STEP_NONE)
			return m_SavedDataDialogState;

		// get save data dialog status
		cdStatus = sceSaveDataDialogGetStatus();

		switch (cdStatus)
		{
		default:
		case SCE_COMMON_DIALOG_STATUS_NONE:
			return cdStatus;

		case SCE_COMMON_DIALOG_STATUS_RUNNING:
			// get save data dialog sub-status
			cdSubStatus = sceSaveDataDialogGetSubStatus();
			if (cdSubStatus != SCE_COMMON_DIALOG_STATUS_FINISHED)
				return cdSubStatus;
			break;

		case SCE_COMMON_DIALOG_STATUS_FINISHED:
			break;
		}

		// get save data dialog result
		memset(&sddResult, 0, sizeof(SceSaveDataDialogResult));
		memset(&sddSlotInfo, 0, sizeof(SceSaveDataDialogSlotInfo));
		memset(&sddSlotParam, 0, sizeof(SceAppUtilSaveDataSlotParam));
		sddResult.slotInfo = &sddSlotInfo;
		sddResult.slotInfo->slotParam = &sddSlotParam;

		res = sceSaveDataDialogGetResult(&sddResult);
		if (res != SCE_OK)
		{
			m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
			return res;
		}

		if (sddResult.result < 0)
		{
			m_LastResult.SetResultSCE(sddResult.result, true, __FUNCTION__, __LINE__);
			return sddResult.result;
		}

		if (sddResult.result == SCE_COMMON_DIALOG_RESULT_ABORTED)
		{
			m_SavedDataDialogState = DIALOG_LIST_STEP_END_CANCELED;
		}

		switch (m_SavedDataDialogState)
		{
		case DIALOG_LIST_STEP_LIST:
			// 'X' button pushed
			if (sddResult.result == SCE_COMMON_DIALOG_RESULT_USER_CANCELED)
			{
				memset(&sddFinish, 0, sizeof(SceSaveDataDialogFinishParam));

				res = sceSaveDataDialogFinish(&sddFinish);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}

				// save data procedure status to END
				m_IOThread->SetStatus(THREAD_END);

				m_SavedDataDialogState = DIALOG_LIST_STEP_END_CANCELED;
			}
			// chosen a save data slot from list
			else
			{
				m_SlotId = sddResult.slotId;

				memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

				sceSaveDataDialogParamInit(&sddParam);
				sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
				sddParam.sysMsgParam = &sddSysMsg;
				sddSysMsg.targetSlot.id = m_SlotId;
				sddSysMsg.targetSlot.emptyParam = &m_SlotEmptyParam;

				if (m_SavedDataDialogMode == DIALOG_LIST_MODE_SAVE)
				{
					// check save data exist
					if (sddResult.slotInfo->isExist)
						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_OVERWRITE;
					else
						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_CONFIRM;

					m_SavedDataDialogState = DIALOG_LIST_STEP_CONFIRM;
				}
				else if (m_SavedDataDialogMode == DIALOG_LIST_MODE_LOAD)
				{
					// check save data exist
					if (sddResult.slotInfo->isExist)
					{
						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_CONFIRM;

						m_SavedDataDialogState = DIALOG_LIST_STEP_CONFIRM;
					}
					else
					{
						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_NODATA;

						// save data procedure status to END
						m_IOThread->SetStatus(THREAD_END);

						m_SavedDataDialogState = DIALOG_LIST_STEP_FINISH;
					}
				}
				else if (m_SavedDataDialogMode == DIALOG_LIST_MODE_DELETE)
				{
					// check save data exist
					if (sddResult.slotInfo->isExist)
					{
						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_CONFIRM;

						m_SavedDataDialogState = DIALOG_LIST_STEP_CONFIRM;
					}
					else
					{
						sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_NODATA;

						// save data procedure status to END
						m_IOThread->SetStatus(THREAD_END);

						m_SavedDataDialogState = DIALOG_LIST_STEP_FINISH;
					}
				}

				res = sceSaveDataDialogContinue(&sddParam);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}
			}
			break;

		case DIALOG_LIST_STEP_CONFIRM:
			// 'NO' button pushed or canceled
			if (sddResult.result == SCE_COMMON_DIALOG_RESULT_USER_CANCELED ||
				sddResult.buttonId == SCE_SAVEDATA_DIALOG_BUTTON_ID_NO )
			{
					// returns to the list selection
					memset(&sddList, 0, sizeof(SceSaveDataDialogListParam));

					sceSaveDataDialogParamInit(&sddParam);
					sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_LIST;
					sddParam.listParam = &sddList;

					sddList.slotList = m_SlotList;
					sddList.slotListSize = m_NumberOfSlots;
					sddList.focusPos = SCE_SAVEDATA_DIALOG_FOCUS_POS_LISTHEAD;

					res = sceSaveDataDialogContinue(&sddParam);
					if (res != SCE_OK)
					{
						m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
						return res;
					}

					m_SavedDataDialogState = DIALOG_LIST_STEP_LIST;
			}
			// 'YES' button pushed
			else if (sddResult.result == SCE_OK)
			{
				// broken savedata existed, display error dialog
				if (m_SavedDataDialogMode == DIALOG_LIST_MODE_LOAD &&
					sddSlotParam.status == SCE_APPUTIL_SAVEDATA_SLOT_STATUS_BROKEN)
				{
					m_DialogEndMessage = Messages::kSavedGame_LoadCorrupted;

					memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

					sceSaveDataDialogParamInit(&sddParam);
					sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
					sddParam.sysMsgParam = &sddSysMsg;

					sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_FILE_CORRUPTED;
					sddSysMsg.targetSlot.id = m_SlotId;

					if (m_SavedDataDialogMode == DIALOG_LIST_MODE_DELETE)
						sddSysMsg.targetSlot.emptyParam = NULL;
					else
						sddSysMsg.targetSlot.emptyParam = &m_SlotEmptyParam;

					res = sceSaveDataDialogContinue(&sddParam);
					if (res != SCE_OK)
					{
						m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
						return res;
					}

					// savedata procedure status to END
					m_IOThread->SetStatus(THREAD_END);

					m_SavedDataDialogState = DIALOG_LIST_STEP_FINISH;
					break;
				}

				memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

				sceSaveDataDialogParamInit(&sddParam);
				sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
				sddParam.sysMsgParam = &sddSysMsg;

				sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_PROGRESS;
				sddSysMsg.targetSlot.id = m_SlotId;

				if (m_SavedDataDialogMode == DIALOG_LIST_MODE_DELETE)
					sddSysMsg.targetSlot.emptyParam = NULL;
				else
					sddSysMsg.targetSlot.emptyParam = &m_SlotEmptyParam;

				res = sceSaveDataDialogContinue(&sddParam);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}

				if (m_SavedDataDialogMode == DIALOG_LIST_MODE_SAVE)
				{
					// start save thread
					m_IOThread->Start(IOMODE_SAVE, m_SlotId);
				}
				else if (m_SavedDataDialogMode == DIALOG_LIST_MODE_LOAD) {
					// start load thread
					m_IOThread->Start(IOMODE_LOAD, m_SlotId);
				}
				else if (m_SavedDataDialogMode == DIALOG_LIST_MODE_DELETE)
				{
					// start delete thread
					m_IOThread->Start(IOMODE_DELETE, m_SlotId);
				}

				m_SavedDataDialogState = DIALOG_LIST_STEP_SAVING;
			}
			break;

		case DIALOG_LIST_STEP_SAVING:
			res = m_IOThread->GetResult();
			m_LastResult = m_IOThread->GetLastResult();

			// saving/loading completed
			if (res == SCE_OK)
			{
				if (m_IOThread->GetMode() == IOMODE_DELETE)
				{
					Messages::AddMessage(Messages::kSavedGame_GameDeleted);
				}

				memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

				sceSaveDataDialogParamInit(&sddParam);
				sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
				sddParam.sysMsgParam = &sddSysMsg;

				sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_FINISHED;
				sddSysMsg.targetSlot.id = m_SlotId;

				if (m_SavedDataDialogMode == DIALOG_LIST_MODE_DELETE)
					sddSysMsg.targetSlot.emptyParam = NULL;
				else
					sddSysMsg.targetSlot.emptyParam = &m_SlotEmptyParam;
			}
			// 'Not enough space for write save data error occurred
			else if (res == SCE_APPUTIL_ERROR_SAVEDATA_NO_SPACE_FS || res == SCE_APPUTIL_ERROR_SAVEDATA_NO_SPACE_QUOTA)
			{
				m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
				m_DialogEndMessage = Messages::kSavedGame_SaveNoSpace;

				memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

				sceSaveDataDialogParamInit(&sddParam);
				sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
				sddParam.sysMsgParam = &sddSysMsg;

				sddSysMsg.sysMsgType = (m_ControlFlags & NOSPACE_DIALOG_NOT_CONTINUABLE != 0) ? SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_NOSPACE : SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_NOSPACE_CONTINUABLE;
				sddSysMsg.targetSlot.id = m_SlotId;
				sddSysMsg.targetSlot.emptyParam = &m_SlotEmptyParam;
				sddSysMsg.value = m_IOThread->GetRequiredSizeKiB();
			}
			// occurred no device error
			else if ( res == SCE_APPUTIL_ERROR_NOT_MOUNTED )
			{
				m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
				m_DialogEndMessage = Messages::kSavedGame_SaveNotMounted;

				// display need-mc system dialog, and return list-view dialog display state
				memset(&sddSysMsg, 0, sizeof(SceSaveDataDialogSystemMessageParam));

				sceSaveDataDialogParamInit(&sddParam);
				sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_SYSTEM_MSG;
				sddParam.sysMsgParam = &sddSysMsg;

				sddSysMsg.sysMsgType = SCE_SAVEDATA_DIALOG_SYSMSG_TYPE_NEED_MC_OPERATION;
				sddSysMsg.targetSlot.id = m_SlotId;
				sddSysMsg.targetSlot.emptyParam = &m_SlotEmptyParam;

				res = sceSaveDataDialogContinue(&sddParam);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}

				m_SavedDataDialogState = DIALOG_LIST_STEP_ALERT;
				m_IOThread->SetStatus(THREAD_INIT);

				return SCE_OK;
			}
			// other error occurred
			else
			{
				m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
				m_DialogEndMessage = Messages::kSavedGame_SaveGenericError;

				memset(&sddErrCode, 0, sizeof(SceSaveDataDialogErrorCodeParam));

				sceSaveDataDialogParamInit(&sddParam);
				sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_ERROR_CODE;
				sddParam.errorCodeParam = &sddErrCode;

				sddErrCode.targetSlot.id = m_SlotId;
				sddErrCode.targetSlot.emptyParam = &m_SlotEmptyParam;
				sddErrCode.errorCode = res;
			}

			res = sceSaveDataDialogContinue(&sddParam);
			if (res != SCE_OK)
			{
				m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
				return res;
			}

			m_SavedDataDialogState = DIALOG_LIST_STEP_FINISH;
			break;

		case DIALOG_LIST_STEP_ALERT:
			// returns to the list selection
			memset(&sddList, 0, sizeof(SceSaveDataDialogListParam));

			sceSaveDataDialogParamInit(&sddParam);
			sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_LIST;
			sddParam.listParam = &sddList;

			sddList.slotList = m_SlotList;
			sddList.slotListSize = m_NumberOfSlots;
			sddList.focusPos = SCE_SAVEDATA_DIALOG_FOCUS_POS_LISTHEAD;

			res = sceSaveDataDialogContinue(&sddParam);
			if (res != SCE_OK)
			{
				m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
				return res;
			}
			m_SavedDataDialogState = DIALOG_LIST_STEP_LIST;
			break;

		case DIALOG_LIST_STEP_FINISH:
			if (m_SavedDataDialogMode == DIALOG_LIST_MODE_LOAD)
			{
				memset(&sddFinish, 0, sizeof(SceSaveDataDialogFinishParam));

				res = sceSaveDataDialogFinish(&sddFinish);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}

				m_SavedDataDialogState = DIALOG_LIST_STEP_END;
				break;
			}
			else if (m_SavedDataDialogMode == DIALOG_LIST_MODE_SAVE)
			{
				memset(&sddFinish, 0, sizeof(SceSaveDataDialogFinishParam));

				res = sceSaveDataDialogFinish(&sddFinish);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}

				m_SavedDataDialogState = DIALOG_LIST_STEP_END;
				break;
			}
			else
			{
				// Deleted a game, keep the list open in case we want to delete another.
				sceSaveDataDialogParamInit(&sddParam);
				sddParam.mode = SCE_SAVEDATA_DIALOG_MODE_LIST;

				memset(&sddList, 0, sizeof(SceSaveDataDialogListParam));
				sddParam.listParam = &sddList;

				sddList.focusPos = SCE_SAVEDATA_DIALOG_FOCUS_POS_LISTHEAD;

				res = sceSaveDataDialogContinue(&sddParam);
				if (res != SCE_OK)
				{
					m_LastResult.SetResultSCE(res, true, __FUNCTION__, __LINE__);
					return res;
				}
				m_SavedDataDialogState = DIALOG_LIST_STEP_LIST;

				m_IOThread->SetStatus(THREAD_INIT);
			}
			break;

		case DIALOG_LIST_STEP_END:
			Messages::AddMessage(m_DialogEndMessage);
			ShutdownDialog();
			m_SavedDataDialogState = DIALOG_LIST_STEP_NONE;
			break;

		case DIALOG_LIST_STEP_END_CANCELED:
			if (m_IOThread->GetMode() != IOMODE_DELETE)
			{
				Messages::AddMessage(Messages::kSavedGame_Canceled);
			}
			m_IOThread->ClearMode();
			ShutdownDialog();
			m_SavedDataDialogState = DIALOG_LIST_STEP_NONE;
			break;
		}

		return SCE_OK;
	}

}
