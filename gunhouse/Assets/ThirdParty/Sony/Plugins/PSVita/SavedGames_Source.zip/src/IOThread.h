#ifndef _IOTHREAD_H
#define _IOTHREAD_H

#include "prx.h"
#include "SimpleLock.h"
#include <savedata_dialog.h>
#include <string>

#define	SAVEDATA_MOUNTPOINT_DATA		"savedata0"
#define	SAVEDATA_SUBTHREAD_NAME			"savedata_sub_thr"
#define	SAVEDATA_SAVE_FILENAME_BASE		"data"
#define	SAVEDATA_SAVE_FILENAME_EXT		".bin"
#define SAVEDATA_HEADER_IDENT			"SVGM"

namespace UnitySavedGames
{
	struct IOThreadSlotParams
	{
		std::string title;		// Title name.
		std::string subTitle;	// Subtitle name.
		std::string detail;		// detail info.
		std::string iconPath;	// Thumbnail icon path.
	};

	enum IOThreadStatus
	{
		THREAD_STOPPED,
		THREAD_INIT,
		THREAD_RUNNING,
		THREAD_LOADED,
		THREAD_END
	};

	enum IOThreadMode
	{
		IOMODE_NOT_SET,
		IOMODE_SAVE,
		IOMODE_LOAD,
		IOMODE_DELETE
	};

	class IOThread
	{
		SimpleLock m_Lock;

		SceUID m_ThreadID;
		int m_SlotID;
		IOThreadMode m_Mode;
		IOThreadSlotParams m_SlotParams;
		IOThreadStatus m_Status;
		int	m_BufferSize;
		void* m_Buffer;
		int m_Result;
		SceSize	m_RequiredSizeKiB;
		ResultCode m_LastResult;

	public:
		IOThread();
		~IOThread();

		ErrorCode Start(IOThreadMode mode, int slotID);
		ErrorCode Stop(void);

		void SetSlotParams(const IOThreadSlotParams& slotParams)
		{
			m_SlotParams = slotParams;
		}

		IOThreadStatus GetStatus() const { return m_Status; }
		void SetStatus(IOThreadStatus status) { m_Status = status; }

		struct Header
		{
			char ident[4];
			int bufferSize;
		};

		void SetBuffer(int bufferSize, void* buffer);
		void* GetBuffer() const
		{
			if(m_Buffer && m_BufferSize > 0)
			{
				Header* header = (Header*)m_Buffer;
				return (header + 1);
			}
			return NULL;
		}
		int GetBufferSize() const
		{
			if(m_Buffer && m_BufferSize > 0)
			{
				return m_BufferSize - sizeof(Header);
			}
			return 0;
		}

		IOThreadMode GetMode() const { return m_Mode; }
		void ClearMode() { m_Mode = IOMODE_NOT_SET; }
		int GetResult() const { return m_Result; }
		ResultCode GetLastResult() const { return m_LastResult; }
		void SetResult(int result) { m_Result = result; }
		SceSize	GetRequiredSizeKiB() const { return m_RequiredSizeKiB; }

	private:
		SceInt32 CreateSlot();

		static SceInt32 ThreadFuncSave(SceSize args, void *argc);
		static SceInt32 ThreadFuncSaveLarge(SceSize args, void *argc);
		static SceInt32 ThreadFuncLoad(SceSize args, void *argc);
		static SceInt32 ThreadFuncDelete(SceSize args, void *argc);
	};
}

#endif // _IOTHREAD_H
