#ifndef _SAVEDGAME_H
#define _SAVEDGAME_H

#include "prx.h"
#include "SimpleLock.h"
#include "IOThread.h"
#include "MessagePipe.h"

#define	SAVEDATA_FIXED_TARGET_SLOT	0		// Always use slot 0 for single fixed slot saving/loading.

typedef long long Int64;
typedef unsigned long long UInt64;

namespace UnitySavedGames
{
	struct SavedGameSlotParams
	{
		const char* title;		// Title name.
		const char* subTitle;	// Subtitle name.
		const char* detail;		// detail info.
		const char* iconPath;	// Thumbnail icon path.
	};

	struct SavedGameData
	{
		int dataSize;
		void* data;
	};

	// Structure for returning slot info to managed code.
	struct SavedGameSlotInfo
	{
		UInt64 modifiedTime;
		int status;
		int sizeKiB;
		const char* title;
		const char* subTitle;
		const char* detail;
		const char* iconPath;
	};

	PRX_EXPORT ErrorCode PrxSavedGameSave(void* data, int dataSize, int slotNumber, SavedGameSlotParams* slotParams, int controlFlags);
	PRX_EXPORT ErrorCode PrxSavedGameLoad(int slotNumber);
	PRX_EXPORT ErrorCode PrxSavedGameDeleteSlot(int slotNumber);
	PRX_EXPORT ErrorCode PrxSavedGameAutoSave(void* data, int dataSize, int slotNumber, SavedGameSlotParams* slotParams, int controlFlags);
	PRX_EXPORT ErrorCode PrxSavedGameAutoLoad(int slotNumber);
	PRX_EXPORT ErrorCode PrxSavedGameAutoDeleteSlot(int slotNumber);
	PRX_EXPORT ErrorCode PrxSavedGameGetSlotInfo(int slotNumber, SavedGameSlotInfo* info);
	PRX_EXPORT ErrorCode PrxSavedGameGetGameData(SavedGameData* data);

	// save data dialog mode
	enum DialogMode
	{
		SAVEDATA_DIALOG_MODE_NONE,
		SAVEDATA_DIALOG_MODE_SAVE,
		SAVEDATA_DIALOG_MODE_LOAD,
		SAVEDATA_DIALOG_MODE_DELETE,
	};

	// save data dialog state
	enum DialogState
	{
		SAVEDATA_DIALOG_STEP_NONE,
		SAVEDATA_DIALOG_STEP_FIXED,
		SAVEDATA_DIALOG_STEP_CONFIRM,
		SAVEDATA_DIALOG_STEP_CONFIRM_CANCEL,
		SAVEDATA_DIALOG_STEP_AUTO,
		SAVEDATA_DIALOG_STEP_AUTOSAVING,
		SAVEDATA_DIALOG_STEP_AUTOLOAD_FAILED,
		SAVEDATA_DIALOG_STEP_SAVING,
		SAVEDATA_DIALOG_STEP_ALERT,
		SAVEDATA_DIALOG_STEP_FINISH,
		SAVEDATA_DIALOG_STEP_END,
		SAVEDATA_DIALOG_STEP_END_CANCELED
	};

	class SavedGame
	{
		SimpleLock m_Lock;
		bool m_DialogOpen;
		bool m_Busy;
		DialogState m_SavedDataDialogState;
		DialogMode m_SavedDataDialogMode;
		IOThread* m_IOThread;
		SceAppUtilSaveDataSlotEmptyParam m_slotEmptyParam;
		std::string m_slotEmptyIconPath;
		int m_SlotNumber;
		bool m_ConfirmCancel;
		bool m_autoMode;
		Messages::MessageType m_DialogEndMessage;
		int m_ControlFlags;
		ResultCode m_LastResult;

	public:
		SavedGame();
		~SavedGame();

		ErrorCode GetLastError() const { return m_LastResult.GetResult(); }
		bool GetLastError(ResultCode* result) const { *result = m_LastResult; return m_LastResult.GetResult() == SG_OK; }

		ErrorCode SetEmptyIconPath(const char* iconPath);
		ErrorCode DeleteSlot(int slotNumber, bool silent);
		ErrorCode GetSlotInfo(int slotNumber, SavedGameSlotInfo* info);
		bool IsInitialized() { return m_IOThread != NULL; }
		bool IsBusy() { return m_Busy; }
		bool IsDialogOpen() { return m_DialogOpen; }
		void InitIOThreadSlotParams(const SavedGameSlotParams* slotParams, IOThreadSlotParams& params);
		ErrorCode Save(void* data, int dataSize, int slotNumber, SavedGameSlotParams* slotParams, int controlFlags);
		ErrorCode Load(int slotNumber);
		ErrorCode AutoSave(void* data, int dataSize, int slotNumber, SavedGameSlotParams* slotParams, int controlFlags);
		ErrorCode AutoLoad( int slotNumber );

		void SetIOThread(IOThread* thread) { m_IOThread = thread; }
		int Update(void);

	private:
		ErrorCode StartSaveLoad(IOThreadMode mode, int size, void *buffer);
		int InitDialog(DialogMode dialogMode);
		int InitDialogForAutoSaveError();
		int ShutdownIOThread(void);
		int ShutdownDialog(void);
	};

	extern SavedGame gSavedGame;
}

#endif // _SAVEDGAME_H
