﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace Vita
	{
		namespace SavedGame
		{
			public class SaveLoad
			{
				[Flags] public enum ControlFlags
				{
					NOSPACE_DIALOG_CONTINUABLE = 0,				// If saving triggers the "no space" dialog make continuable.
					NOSPACE_DIALOG_NOT_CONTINUABLE = (1<<0),	// If saving triggers the "no space" dialog make it non-continuable.
				};

				// Structure defining a save game slot.
                [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public struct SavedGameSlotParams
				{
					public string title;	// Title name.
					public string subTitle;	// Subtitle name.
					public string detail;	// detail info.
					public string iconPath;	// Thumbnail icon path.
				};

				// Structure for retrieving a saved game that's just been loaded.
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				struct SavedGameData
				{
					public int dataSize;		// Size of the data in bytes.
					IntPtr _data;
					public byte[] data			// Byte array containing the data.
					{
						get
						{
							if(_data != null && dataSize > 0)
							{
								byte[] bytes = new byte[dataSize];
								Marshal.Copy(_data, bytes, 0, dataSize);
								return bytes;
							}
							return null;
						}
					}
				}

				[DllImport("SavedGames")]
				private static extern bool PrxSavedGamesGetLastError(out ResultCode result);
				
				public static bool GetLastError(out ResultCode result)
				{
					PrxSavedGamesGetLastError(out result);
					return result.lastError == ErrorCode.SG_OK;
				}

				[DllImport("SavedGames")]
				private static extern int PrxSavedGamesInitialise();
				[DllImport("SavedGames")]
				private static extern void PrxSavedGamesUpdate();
				[DllImport("SavedGames")]
				private static extern bool PrxIsSavedGamesDialogOpen();
				[DllImport("SavedGames")]
				private static extern bool PrxIsSavedGamesBusy();
				[DllImport("SavedGames", CharSet = CharSet.Ansi)]
				private static extern ErrorCode PrxSetEmptySlotIconPath(string iconPath);
				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameSetSlotCount(int slotCount);

				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameSave(byte[] data, int dataSize, int slotNumber, ref SavedGameSlotParams slotParams, ControlFlags controlFlags);
				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameLoad(int slotNumber);
				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameAutoSave(byte[] data, int dataSize, int slotNumber, ref SavedGameSlotParams slotParams, ControlFlags controlFlags);
				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameAutoLoad(int slotNumber);
				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameGetGameData(out SavedGameData data);

				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameListSave(byte[] data, int dataSize, ref SavedGameSlotParams slotParams, ControlFlags controlFlags);
				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameListLoad();
				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameListDelete();

				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameDeleteSlot(int slotNumber);
				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameAutoDeleteSlot(int slotNumber);

				[DllImport("SavedGames")]
				private static extern int PrxSavedGameGetQuota();
				[DllImport("SavedGames")]
				private static extern int PrxSavedGameGetUsedSize();

				public enum SlotStatus
				{
					AVAILABLE,
					BROKEN,
					EMPTY
				};

				public const int kSaveDataDefaultSlot = 0;

				// Internal structure for returning the word filter result.
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 0)]
				struct SavedGameSlotInfoInternal
				{
					public long _modifiedTime;
					public SlotStatus status;
					public int sizeKiB;	// Always 0, probably need to ask SCE about this.
					IntPtr _title;
					IntPtr _subTitle;
					IntPtr _detail;
					IntPtr _iconPath;
					public DateTime modifiedTime
					{
						get
						{
							return new DateTime(_modifiedTime);
						}
					}
					public string title { get { return Marshal.PtrToStringAnsi(_title); } }
					public string subTitle { get { return Marshal.PtrToStringAnsi(_subTitle); } }
					public string detail { get { return Marshal.PtrToStringAnsi(_detail); } }
					public string iconPath { get { return Marshal.PtrToStringAnsi(_iconPath); } }
				};

				public struct SavedGameSlotInfo
				{
					public System.DateTime modifiedTime;
					public Sony.Vita.SavedGame.SaveLoad.SlotStatus status;
					public int slotNumber;
					public string title;
					public string subTitle;
					public string detail;
					public string iconPath;
				};

				[DllImport("SavedGames")]
				private static extern ErrorCode PrxSavedGameGetSlotInfo(int slotNumber, out SavedGameSlotInfoInternal slotInfo);

				// Event handlers.
				public static event Messages.EventHandler OnGameSaved;
				public static event Messages.EventHandler OnGameLoaded;
				public static event Messages.EventHandler OnGameDeleted;
				public static event Messages.EventHandler OnCanceled;
				public static event Messages.EventHandler OnSaveError;
				public static event Messages.EventHandler OnLoadError;
				public static event Messages.EventHandler OnLoadNoData;

				public static int GetQuota()
				{
					return PrxSavedGameGetQuota();
				}
				public static int GetUsedSize()
				{
					return PrxSavedGameGetUsedSize();
				}

				public static ErrorCode Delete(int slotNumber, bool useDialogs)
				{
					if (useDialogs)
					{
						return PrxSavedGameDeleteSlot(slotNumber);
					}
					else
					{
						return PrxSavedGameAutoDeleteSlot(slotNumber);
					}
				}

				[ObsoleteAttribute("This method is deprecated, please use Delete(int slotNumber, bool useDialogs) instead.", false)]
				public static ErrorCode DeleteSlot(int slotNumber)
				{
					return PrxSavedGameAutoDeleteSlot(slotNumber);
				}
				
				public static ErrorCode GetSlotInfo(int slotNumber, out SavedGameSlotInfo slotInfo)
				{
					SavedGameSlotInfoInternal slotInfoInt = new SavedGameSlotInfoInternal();
					ErrorCode res = PrxSavedGameGetSlotInfo(slotNumber, out slotInfoInt);
					if (res == Sony.Vita.SavedGame.ErrorCode.SG_OK)
					{
						// Slot has data.
						slotInfo.status = slotInfoInt.status;
						slotInfo.modifiedTime = slotInfoInt.modifiedTime;
						slotInfo.title = slotInfoInt.title;
						slotInfo.subTitle = slotInfoInt.subTitle;
						slotInfo.detail = slotInfoInt.detail;
						slotInfo.iconPath = slotInfoInt.iconPath;
					}
					else
					{
						// Slot is empty or an error occurred.
						slotInfo.status = SlotStatus.EMPTY;
						slotInfo.modifiedTime = DateTime.MinValue;
						slotInfo.title = "";
						slotInfo.subTitle = "";
						slotInfo.detail = "";
						slotInfo.iconPath = "";

						if (res == Sony.Vita.SavedGame.ErrorCode.SG_ERR_SLOT_NOT_FOUND)
						{
							// If errorCode == SG_ERR_SLOT_NOT_FOUND then change it to SG_OK since an empty slot is flagged by slotInfo.status.
							res = Sony.Vita.SavedGame.ErrorCode.SG_OK;
						}
					}
					slotInfo.slotNumber = slotNumber;
					return res;
				}

				// Is the save/load dialog open.
				public static bool IsDialogOpen
				{
					get { return PrxIsSavedGamesDialogOpen(); }
				}

				// Is the save/load process busy.
				public static bool IsBusy
				{
					get { return PrxIsSavedGamesBusy(); }
				}

				// Set the path and filename for the empty slot icon.
				public static ErrorCode SetEmptySlotIconPath(string iconPath)
				{
					return PrxSetEmptySlotIconPath(iconPath);
				}

				// Set the number of available slots when using the save list methods.
				public static ErrorCode SetSlotCount(int slotCount)
				{
					return PrxSavedGameSetSlotCount(slotCount);
				}

				// Save a game to slot 0 with OS dialogs, use this method if your game only requires 1 save slot.
				public static ErrorCode SaveGame(byte[] data, SavedGameSlotParams slotParams, ControlFlags controlFlags)
				{
					return PrxSavedGameSave(data, data.Length, kSaveDataDefaultSlot, ref slotParams, controlFlags);
				}

				// Save a game to slot with OS dialogs.
				public static ErrorCode SaveGame(byte[] data, int slotNumber, SavedGameSlotParams slotParams, ControlFlags controlFlags)
				{
					return PrxSavedGameSave(data, data.Length, slotNumber, ref slotParams, controlFlags);
				}

				// Load a game from slot 0 with OS dialogs, use this method if your game only requires 1 save slot.
				//
				// When loading is complete the OnGameLoaded event will fire at which point GetLoadedGame()
				// can be called to retrieve the data.
				public static ErrorCode LoadGame()
				{
					return PrxSavedGameLoad(kSaveDataDefaultSlot);
				}

				// Load a game from a slot with OS dialogs.
				//
				// When loading is complete the OnGameLoaded event will fire at which point GetLoadedGame()
				// can be called to retrieve the data.
				public static ErrorCode LoadGame(int slotNumber)
				{
					return PrxSavedGameLoad(slotNumber);
				}

				// Save a game to a specific slot with no dialogs (unless error)
				public static ErrorCode AutoSaveGame(byte[] data, int slotNumber, SavedGameSlotParams slotParams, ControlFlags controlFlags)
				{
					return PrxSavedGameAutoSave(data, data.Length, slotNumber, ref slotParams, controlFlags);
				}

				// Load a game from a specific slot with no dialogs (unless error)
				public static ErrorCode AutoLoadGame(int slotNumber)
				{
					return PrxSavedGameAutoLoad( slotNumber );
				}

				// Retrieve the data that was just loaded.
				public static byte[] GetLoadedGame()
				{
					SavedGameData data = new SavedGameData();
					if(PrxSavedGameGetGameData(out data) == ErrorCode.SG_OK)
					{
						return data.data;
					}
					
					return null;
				}

				// Save a game with a slot selection dialog.
				public static ErrorCode SaveGameList(byte[] data, SavedGameSlotParams slotParams, ControlFlags controlFlags)
				{
					return PrxSavedGameListSave(data, data.Length, ref slotParams, controlFlags);
				}

				// Load a game with a slot selection dialog.
				//
				// When loading is complete the OnGameLoaded event will fire at which point GetLoadedGame()
				// can be called to retrieve the data.
				public static ErrorCode LoadGameList()
				{
					return PrxSavedGameListLoad();
				}

				// Delete a saved game.
				public static ErrorCode DeleteGameList()
				{
					return PrxSavedGameListDelete();
				}

				// Process messages.
				public static void ProcessMessage(Messages.PluginMessage msg)
				{
					// Interpret the message and trigger corresponding events.
					switch (msg.type)
					{
						case Messages.MessageType.kSavedGame_GameSaved:
							if (OnGameSaved != null) OnGameSaved(msg);
							break;

						case Messages.MessageType.kSavedGame_GameLoaded:
							if (OnGameLoaded != null) OnGameLoaded(msg);
							break;

						case Messages.MessageType.kSavedGame_GameDeleted:
							if (OnGameDeleted != null) OnGameDeleted(msg);
							break;

						case Messages.MessageType.kSavedGame_Canceled:
							if (OnCanceled != null) OnCanceled(msg);
							break;

						case Messages.MessageType.kSavedGame_SaveNoSpace:
						case Messages.MessageType.kSavedGame_SaveNotMounted:
						case Messages.MessageType.kSavedGame_SaveGenericError:
							if (OnSaveError != null) OnSaveError(msg);
							break;

						case Messages.MessageType.kSavedGame_LoadCorrupted:
							if (OnLoadError != null) OnLoadError(msg);
							break;
						case Messages.MessageType.kSavedGame_LoadNoData:
							if (OnLoadNoData != null) OnLoadNoData(msg);
							break;
					}
				}

				// Initialise the saved game system.
				public static void Initialise()
				{
					PrxSavedGamesInitialise();
				}

				// Update the saved game system.
				public static void Update()
				{
					PrxSavedGamesUpdate();
				}
			}
		} // SavedGames
	} // Vita
} // Sony
