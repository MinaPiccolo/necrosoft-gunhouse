using System;
using System.Runtime.InteropServices;

namespace Sony
{
	namespace Vita
	{
		namespace SavedGame
		{
			public enum ErrorCode
			{
				SG_OK,
				SG_ERR_COMMON_DIALOG_BUSY,				// Something else is using the common dialog so the action could not be performed.
				SG_ERR_BUSY,							// The system is busy.
				SG_ERR_FAILED,							// General failure, check the log for more info.
				SG_ERR_BAD_STATE,						// Somethings gone wrong with the logic, most likely a bug in the native plugin code.
				SG_ERR_INDEX_OUT_OF_RANGE,				// An out of range array index was specified.
				SG_ERR_ICON_PATH_TOO_LONG,				// Icon path exceeds the maximum allowed length.
				SG_ERR_TOO_MANY_SLOTS,					// Requested number of slots exceeds maximum allowed.
				SG_ERR_DIALOG_OPEN,						// Unable to start because a dialog is already open.
				SG_ERR_BAD_FILE,						// Bad file data or invalid header detected.
				SG_ERR_NO_SPACE_QUOTA,					// Save quota exceeded.
				SG_ERR_NO_SPACE,						// No space on the memory card.
				SG_ERR_NO_MEM_CARD,						// No memory card.
				SG_ERR_NO_DATA,							// No data loaded.
				SG_ERR_SLOT_NOT_FOUND,					// Slot not found.
				SG_ERR_NOT_INITIALIZED,					// The system hasn't been initialized.
			}

			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 0)]
			public struct ResultCode
			{
				IntPtr _className;
				public ErrorCode lastError;
				public int lastErrorSCE;
				public string className
				{
					get { return Marshal.PtrToStringAnsi(_className); }
				}
			}
		}
	}
}
