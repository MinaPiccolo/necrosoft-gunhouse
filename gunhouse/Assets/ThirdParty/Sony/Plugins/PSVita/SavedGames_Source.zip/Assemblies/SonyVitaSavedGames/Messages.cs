using System;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

namespace Sony
{
	namespace Vita
	{
		namespace SavedGame
		{
			public class Messages
			{
				// Messages.
				[DllImport("SavedGames")]
				private static extern bool PrxSavedGamesHasMessage();
				[DllImport("SavedGames")]
				private static extern bool PrxSavedGamesGetFirstMessage(out PluginMessage msg);
				[DllImport("SavedGames")]
				private static extern bool PrxSavedGamesRemoveFirstMessage();
				
				public enum MessageType
				{
					kSavedGame_NotSet,
					kSavedGame_Log,
					kSavedGame_LogWarning,
					kSavedGame_LogError,				
					
					kSavedGame_GameSaved,			// Game saving has completed.
					kSavedGame_GameLoaded,			// Game loading has completed.
					kSavedGame_Canceled,			// Saving/loading was canceled.
					
					kSavedGame_SaveNoSpace,			// Saving failed because there was not enough space.
					kSavedGame_SaveNotMounted,		// Saving failed because there was save device mounted (missing memory card).
					kSavedGame_SaveGenericError,	// Saving failed due to some error.
					kSavedGame_LoadCorrupted,		// Load failed because the slot was corrupted.
					kSavedGame_LoadNoData,			// Load failed because there was nothing to load.

					kSavedGame_GameDeleted,			// A saved game has been deleted.
				};
				
				// Event handler.
				public delegate void EventHandler(PluginMessage msg);
				
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public struct PluginMessage
				{
					public MessageType type;
					public int dataSize;
					public IntPtr data;
					public string Text
					{
						get
						{
							switch (type)
							{
								case MessageType.kSavedGame_Log:
								case MessageType.kSavedGame_LogWarning:
								case MessageType.kSavedGame_LogError:
									return Marshal.PtrToStringAnsi(data);
							}
							return "no text";
						}
					}
				};
				
				public static bool HasMessage()
				{
					return PrxSavedGamesHasMessage();
				}
				
				public static void RemoveFirstMessage()
				{
					PrxSavedGamesRemoveFirstMessage();
				}
				
				public static void GetFirstMessage(out PluginMessage msg)
				{
					PrxSavedGamesGetFirstMessage(out msg);
				}
				
			}
		} // SavedGames
	} // Vita
} // Sony
