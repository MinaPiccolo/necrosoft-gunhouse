#ifndef _MUTEX_VITA_H
#define _MUTEX_VITA_H

#include "UnityNP.h"
#include <kernel.h>
#include <sce_atomic.h>

namespace UnityPlugin
{
	class NonCopyable
	{
	public:
		NonCopyable() {}

	private:
		NonCopyable(const NonCopyable&);
		NonCopyable& operator=(const NonCopyable&);
	};

	class PlatformMutex : private NonCopyable
	{
	public:
		PlatformMutex();
		~PlatformMutex();

		void Lock();
		void Unlock();

	private:
		void Create();
		void Destroy();

	private:
		SceUID m_Mutex;
	};


	class PlatformSemaphore : public NonCopyable
	{
	public:
		PlatformSemaphore();
		~PlatformSemaphore();

		void Reset();
		void WaitForSignal();
		void Signal();

	private:
		void Create();
		void Destroy();

	private:
		SceUID	m_Semaphore;
	};


	// AtomicAdd - Returns the new value, after the operation has been performed (as defined by OSAtomicAdd32Barrier)
	inline int AtomicAdd (int volatile* i, int value)
	{
		return sceAtomicAdd32((int32_t*)i, value) + value;		// on psp2 it returns the pre-increment value
	}

	// AtomicIncrement - Returns the new value, after the operation has been performed (as defined by OSAtomicAdd32Barrier)
	inline int AtomicIncrement (int volatile* i)
	{
		return AtomicAdd(i, 1);
	}

	// AtomicDecrement - Returns the new value, after the operation has been performed (as defined by OSAtomicAdd32Barrier)
	inline int AtomicDecrement (int volatile* i)
	{
		return AtomicAdd(i, -1);
	}

}

#endif
