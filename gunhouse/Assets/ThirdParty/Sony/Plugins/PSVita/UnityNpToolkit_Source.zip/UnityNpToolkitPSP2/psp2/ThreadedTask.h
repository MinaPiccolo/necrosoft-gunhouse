#pragma once

#include "Mutex.h"

namespace UnityPlugin
{
	class ThreadedTask
	{
	public:
		ThreadedTask();

		int ThreadStart(const char* name, SceKernelThreadEntry threadFunc, int stackSize=4096, int priority=SCE_KERNEL_DEFAULT_PRIORITY_USER-1, int affinity=SCE_KERNEL_THREAD_CPU_AFFINITY_MASK_DEFAULT);
		int ThreadEnd(int errorCode);
		bool IsBusy();

	private:
		void SetTid(SceUID tid);

	private:
		SceUID m_tid;
		SimpleLock m_Lock;
	};
}
