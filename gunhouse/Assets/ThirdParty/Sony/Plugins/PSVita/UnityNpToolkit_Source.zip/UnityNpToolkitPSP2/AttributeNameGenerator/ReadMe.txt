
Np Session Attribute Name Generator

Generates ASCII names that when hashed by NpToolkit result in an endian-agnostic byte palindrome.

Why we need this tool...

There is a known endian issue with the Sony npToolkit library when processing cross-play attributes.

Although both PS4 and Vita are little-endian the Vita npToolkit library always assumes that it will be talking
to a PS3 which is big-endian and so swaps the byte order for the attribute name hash values, but PS4 npToolkit
assumes that hash values are little-endian.

So, in order for the Vita and PS4 to recognize attributes from the other platforms the hashed attribute name must
be a byte palindrome, Sony use the Fowler�Noll�Vo hashing algorithm to hash attribute names and the resulting
32 bit pattern must be interchangeable on little and big endian systems, this means that the ASCII attribute
names must hash to a byte-palindrome, e.g. "WONKPxp" when hashed = 0x72, 0xfd, 0xfd, 0x72. This tool can be used
to generate names that fit this requirement.
