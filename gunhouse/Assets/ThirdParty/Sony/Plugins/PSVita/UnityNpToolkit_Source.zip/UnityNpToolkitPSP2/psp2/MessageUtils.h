#pragma once

#include "ThreadedTask.h"

class GetMsgAttachmentThread : public UnityPlugin::ThreadedTask
{
public:
	static const size_t kRecvBufferSize = 1 * 1024 * 1024;
	static const size_t kThreadStackSize = 64 * 1024;

	GetMsgAttachmentThread();
	~GetMsgAttachmentThread();

	int StartGetAttachment(const SceAppUtilSessionInvitationParam& inviteParam);
	bool PollForCompletion();
	SceChar8* GetAttachmentData() const;
	size_t GetAttachmentSize() const;

private:
	int InitWebAPI();
	static SceInt32 ThreadFunc(SceSize args, void* argc);
	int GetAttachement();

private:
	SceAppUtilSessionInvitationParam m_InviteParam;
	SceChar8* m_Buffer;
	size_t m_ReadSize;
	volatile bool m_Done;
};

extern GetMsgAttachmentThread g_GetMsgAttachmentThreaded;
