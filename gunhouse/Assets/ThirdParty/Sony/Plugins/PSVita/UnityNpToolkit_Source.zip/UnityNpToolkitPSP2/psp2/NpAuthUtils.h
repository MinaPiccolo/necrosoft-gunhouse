#pragma once

#include "ThreadedTask.h"

class GetNpAuthCodeThread : public UnityPlugin::ThreadedTask
{
public:
	static const size_t kThreadStackSize = 64 * 1024;

	GetNpAuthCodeThread();
	~GetNpAuthCodeThread();

	int StartGetAuthCode(const char* clientID, const char* scope);
	bool PollForCompletion();
    SceNpAuthorizationCode GetAuthCode() const { return m_AuthCode; }
    int GetIssuerID() const { return m_IssuerID; }

private:
	static SceInt32 ThreadFunc(SceSize args, void* argc);
	int GetNpAuthCode();

private:
    SceNpClientId m_ClientID;
    std::string m_Scope;
    SceNpAuthGetAuthorizationCodeParameter m_Params;

    volatile bool m_Done;
    SceNpAuthorizationCode m_AuthCode;
    int32_t m_IssuerID;
};

extern GetNpAuthCodeThread g_NpGetAuthCodeThreaded;
