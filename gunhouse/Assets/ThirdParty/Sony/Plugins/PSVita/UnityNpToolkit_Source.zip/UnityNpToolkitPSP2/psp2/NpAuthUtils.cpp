#include "UnityNP.h"
#include "MessagePipe.h"
#include "ErrorCodesSony.h"
#include "NpAuthUtils.h"

GetNpAuthCodeThread::GetNpAuthCodeThread() : m_Done(false), m_IssuerID(0)
{
    memset(&m_AuthCode, 0, sizeof(m_AuthCode));
}

GetNpAuthCodeThread::~GetNpAuthCodeThread()
{
}

bool GetNpAuthCodeThread::PollForCompletion()
{
    bool isDone = m_Done;
    m_Done = false;
    return isDone;
}

int GetNpAuthCodeThread::StartGetAuthCode(const char* clientID, const char* scope)
{
    memset(&m_ClientID, 0, sizeof(m_ClientID));
    strcpy(m_ClientID.id, clientID);
    m_Scope = scope;

    memset(&m_AuthCode, 0, sizeof(m_AuthCode));
    m_IssuerID = 0;

    return ThreadStart("GetNpUserAuthCodeThread", ThreadFunc, kThreadStackSize);
}

SceInt32 GetNpAuthCodeThread::ThreadFunc(SceSize args, void* argc)
{
    GetNpAuthCodeThread* thread = *(GetNpAuthCodeThread**)argc;
    return thread->GetNpAuthCode();
}

int GetNpAuthCodeThread::GetNpAuthCode()
{
    int32_t ret = SCE_OK;

    SceNpAuthOAuthRequestId reqId = sceNpAuthCreateOAuthRequest();
    if (reqId < 0)
    {
        UnityPlugin::Messages::LogError("sceNpAuthCreateOAuthRequest() failed: ret = 0x%x\n", ret);
        return ThreadEnd(ret);
    }

    SceNpAuthGetAuthorizationCodeParameter param;
    memset(&m_Params, 0, sizeof(m_Params));
    m_Params.size = sizeof(m_Params);
    m_Params.pClientId = &m_ClientID;
    m_Params.pScope = (const SceChar8*)m_Scope.c_str();

    ret = sceNpAuthGetAuthorizationCode(reqId, &m_Params, &m_AuthCode, &m_IssuerID);
    if (ret < 0)
    {
        UnityPlugin::Messages::LogError("sceNpAuthGetAuthorizationCode() failed: ret = 0x%x\n", ret);
        return ThreadEnd(ret);
    }

    ret = sceNpAuthDeleteOAuthRequest(reqId);
    if (ret < 0)
    {
        UnityPlugin::Messages::LogError("sceNpAuthDeleteOAuthRequest() failed: ret = 0x%x\n", ret);
        return ThreadEnd(ret);
    }

    m_Done = true;
    return ThreadEnd(ret);
}

GetNpAuthCodeThread g_NpGetAuthCodeThreaded;
