#ifndef _TOOLKIT_H
#define _TOOLKIT_H

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <display.h>
#include <libdbgfont.h>
#include <libsysmodule.h>
#include <netcheck_dialog.h>
#include <net/net.h>
#include <libnetctl.h>
#include <ime_dialog.h>

enum NpToolkitInitFlags
{
	kNpToolkitCreate_CacheTrophyIcons = 1 << 0,
	kNpToolkitCreate_NoRanking = 1 << 1,
	kNpToolkitCreate_DoNotInitializeTrophies = 1 << 2,
	kNpToolkitCreate_NoAgeRestriction = 1 << 3			// application uses nptoolkit but is suitable for all ages
};

namespace UnityPlugin
{
	enum NpServiceType
	{
		// Note, the following services are sharable across PS4, PSVita, and PS3
		// Ranking, Matching, Tss, Tus, Messaging, and Trophy

		// Note, the following services are only sharable across PS4 and PS Vita
		// GameCustomData, Sessions, and Presence

		NetInfo,		// A service providing information about the network connection.
		Profile,		// A service providing information about the current user's profile.
		Friends,		// A service managing friends lists and blocked lists etc.
		Messaging,		// A service sending messages to other PSN users.
		Ranking,		// A service managing scoreboards.
		Presence,		// A service providing status updates on the user's PSN profiles.
		Tus,			// A service for title user storage.
		Tss,			// A service for title small storage.
		Matching,		// A service providing matchmaking for online game play.
		Sns,			// A service providing access to social networking services.
		Commerce,		// A service providing in-game commerce functionality.
		Auth,			// A service used to retrieve a ticket from the PSN.
		Trophy,			// A service for managing trophies.
		WordFilter,		// A service for censoring or sanitizing comments (or singular words).
		Near,			// PS Vita only. A service providing "near" functionality.
		WebApi,			// PS Vita and PS4 only. A service managing web API calls.
		Sessions,		// PS Vita and PS4 only. A service providing sessions for invitation and session servers.
		GameCustomData, // PS Vita and PS4 only. A service providing game custom data messages to other PSN users.
		Challenges,		// PS Vita and PS4 only. A service providing challenges 
	};
}

extern unsigned int gCreationFlags;

int InitializeToolkit(unsigned int creationFlags, int npAgeRating);
void AddNpAgeRatingRestriction(const char* countryCode, int npAgeRating);

sce::Toolkit::NP::ServiceType GetSceNpServiceType(UnityPlugin::NpServiceType serviceType);
UnityPlugin::ErrorCode RegisterServiceLabel(UnityPlugin::NpServiceType serviceType, int serviceLabel);
UnityPlugin::ErrorCode RegisterNpCommsID(UnityPlugin::NpServiceType serviceType, const char* npCommsID, const unsigned char* npCommunicationPassphrase, const unsigned char* npCommunicationSignature);
UnityPlugin::ErrorCode RegisterServiceID(UnityPlugin::NpServiceType serviceType, const char* serviceID);

void Update();
void SigninConnect();
void ShutDownToolkit();

#endif
