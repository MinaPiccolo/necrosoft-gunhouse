#include "NetCtlStatus.h"
#include "MessagePipe.h"
#include "ErrorCodesSony.h"

namespace UnityPlugin
{
	int gNetCtlStatusCallbackID = 0;
	ResultCode gConnectionError = ResultCode("Connection");

	void NetCtlStatusCallback( int event_type, void* arg )
	{
		int error = SCE_OK;
		int ret = SCE_OK;
		if (event_type == SCE_NET_CTL_EVENT_TYPE_DISCONNECTED)
		{
			printf("[UnityNpToolkit] SCE_NET_CTL_EVENT_TYPE_DISCONNECTED\n");
			ret = sceNetCtlInetGetResult(event_type, &error);
			if (ret!= SCE_OK)
			{
				printf("NetCtlStatusCallback: Disconnected: %08x\n", error);
				return;
			}

			ErrorCode npError = NP_ERR_NOT_CONNECTED;

			if (error == SCE_NET_CTL_ERROR_FLIGHT_MODE_ENABLED)
			{
				npError = NP_ERR_NOT_CONNECTED_FLIGHT_MODE;
			}

			gConnectionError.SetResult(npError, error, false, __FUNCTION__, __LINE__);
			UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_ConnectionDown);
		}
		else if (event_type == SCE_NET_CTL_EVENT_TYPE_IPOBTAINED)
		{
			gConnectionError.Reset();
		}
	}

	void RegisterNetCtlStatusCallback()
	{
		// Initialise NetCtl, it might have already been initialised, i.e. if PlayerConnection is enabled but we need to be sure.
		int ret = sceNetCtlInit();
		if ((ret != SCE_OK) && (ret != SCE_NET_CTL_ERROR_NOT_TERMINATED))
		{
			printf("ERROR: sceNetCtlInit failed with error = 0x%08x\n", ret);
		}

		ret = sceNetCtlInetRegisterCallback(NetCtlStatusCallback, NULL, &gNetCtlStatusCallbackID);
		if(ret != SCE_OK) 
		{
			printf("ERROR: sceNetCtlInetRegisterCallback failed with error = 0x%08x\n", ret);
		}
	}

	DO_EXPORT( bool, PrxNetCtlGetLastConnectionError )(ResultCode* result)
	{
		*result = gConnectionError;
		return gConnectionError.GetResult() == NP_OK;
	}

};
