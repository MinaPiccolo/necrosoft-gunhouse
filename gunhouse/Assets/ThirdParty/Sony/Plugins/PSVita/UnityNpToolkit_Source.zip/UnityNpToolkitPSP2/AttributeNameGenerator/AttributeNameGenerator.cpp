#include "stdafx.h"

unsigned int generateFNV1Hash(const char* string_data)
{
	unsigned int hash = 0x811C9DC5;
	const char*	char_ptr = string_data;

	while (1) {
		hash *= 0x1000193;
		if (*char_ptr == '\0')
			break;

		hash ^= *char_ptr++;
	}

	return hash;
}

int generateValue(char** outputValue, int index)
{
	char* value = *outputValue;

	int levelDown = -1;
	if (value[index] != '\0' && index < 6)
	{
		levelDown = generateValue(outputValue, index + 1);
	}

	if (levelDown != -1) return levelDown;

	if (value[index] == '\0') value[index] = 'A';
	else value[index]++;

	if (value[index] == 0x5b)
	{
		value[index] = 0x61;
	}
	else if (value[index] == 0x7b)
	{
		value[index] = '\0';
		return -1;
	}

	index++;
	value[index] = '\0';

	return 0;
}

void Usage()
{
	printf("\nAttribute name generator\n");
	printf("\nGenerates ASCII names that when hashed by NpToolkit result in an endian-agnostic byte palindrome.\n");
	printf("\nUsage...\n");
	printf("\nAttributeNameGenerator <options>\n");
	printf("\nAvailable options...\n");
	printf("\n-count     Specifies how many attribute names to generate.\n");
	printf("-seed      A string that will be used as the seed for the generated names.\n");
	printf("-output    Specifies a file to write the attribute names to.\n");
	printf("\nExample...\n");
	printf("\nAttributeNameGenerator -count=10 -seed=ATTR -output=AttributeNames.txt\n");
}

int Error(const char* message)
{
	printf("%s\n", message);
	Usage();
	return 1;
}

int main(int argc, const char* argv[])
{
	int count = 30;
	char seed[1024];
	FILE* outFile = NULL;

	strcpy_s(seed, "ATTR");
	
	if (argc < 2)
	{
		Usage();
		return 0;
	}

	for(int i=1; i<argc; i++)
	{
		if (strncmp(argv[i], "-help", strlen("-help")) == 0)
		{
			Usage();
			return 0;
		}

		if (strncmp(argv[i], "-count", strlen("-count")) == 0)
		{
			const char* valpos = strstr(argv[i], "=");
			char value[1024];
			if (valpos)
			{
				strcpy_s(value, valpos + 1);
				if (sscanf_s(value, "%d", &count) != 1)
				{
					return Error("ERROR parsing option \"-count\"\n");
				}
			}
			else
			{
				return Error("ERROR parsing option \"-count\"\n");
			}
		}
		else if (strncmp(argv[i], "-seed", strlen("-seed")) == 0)
		{
			const char* valpos = strstr(argv[i], "=");
			char value[1024];
			if (valpos)
			{
				strcpy_s(value, valpos + 1);
				if (sscanf_s(value, "%s", seed, _countof(seed)) != 1)
				{
					return Error("ERROR parsing option \"-seed\"\n");
				}
			}
			else
			{
				return Error("ERROR parsing option \"-seed\"\n");
			}
		}
		else if (strncmp(argv[i], "-output", strlen("-output")) == 0)
		{
			const char* valpos = strstr(argv[i], "=");
			char value[1024];
			if (valpos)
			{
				strcpy_s(value, valpos + 1);
				if (strlen(value) < 3)
				{
					return Error("ERROR parsing option \"-output\"\n");
				}
				fopen_s(&outFile, value, "wb");
				if (outFile == NULL)
				{
					return Error("ERROR opening output file\n");
				}
			}
			else
			{
				return Error("ERROR parsing option \"-output\"\n");
			}
		}
	}

	char* value = new char[8];
	memcpy(value, seed, 8);

	while (count > 0)
	{
		if (generateValue(&value, 0) == -1)
			break;

		int myHash = generateFNV1Hash(value);
		int aux1 = (myHash & 0xff000000) >> 24;
		int aux2 = (myHash & 0x00ff0000) >> 16;
		int aux3 = (myHash & 0x0000ff00) >> 8;
		int aux4 = (myHash & 0x000000ff);
		if (aux1 == aux4 && aux2 == aux3)
		{
			printf("\"%s\", // = 0x%08x\n", value, myHash);
			if (outFile)
			{
				fprintf(outFile, "\"%s\", // = 0x%08x\n", value, myHash);
			}
			count --;
		}
	}

	delete[] value;

	if (outFile)
	{
		fclose(outFile);
	}
	return 0;
}

