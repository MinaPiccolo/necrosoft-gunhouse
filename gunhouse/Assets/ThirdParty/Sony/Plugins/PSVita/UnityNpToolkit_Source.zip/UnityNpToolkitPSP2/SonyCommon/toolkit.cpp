#include <np.h>
#include <string>
#include <appmgr.h>
#include <apputil.h>
#include <sce_atomic.h>

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <display.h>
#include <libdbgfont.h>
#include <libsysmodule.h>
#include <netcheck_dialog.h>
#include <net/net.h>
#include <libnetctl.h>
#include <ime_dialog.h>

#include "PlayerInterface/PrxPluginInterface.h"
#if defined(GLOBAL_EVENT_QUEUE)
#include "../psp2/PSP2SystemEvents.h"
#include "../psp2/PSP2SystemEventManager.h"
#endif
#include "../psp2/MessageUtils.h"
#include "../psp2/NpAuthUtils.h"



#include "UnityNP.h"
#include "ErrorCodesSony.h"
#include "NetCtlStatus.h"

#if	NP_HAS_ERROR_CODES
 #include "ErrorCodesSony.h"
#endif
#include "toolkit.h"
#include "MessagePipe.h"
#include "SignInSony.h"
#include "UserProfileSony.h"
#if NP_HAS_BANDWIDTH
 #include "NetInfo.h"
#endif
#if NP_HAS_FRIENDS_LIST
 #include "FriendsListSony.h"
#endif
#if	NP_HAS_ONLINE_PRESENCE
 #include "OnlinePresenceSony.h"
#endif
#if	NP_HAS_TROPHIES
 #include "TrophiesSony.h"
#endif
#if	NP_HAS_RANKING
 #include "RankingSony.h"
#endif
#if	NP_HAS_MATCHING
 #include "MatchingSony.h"
#endif
#if	NP_HAS_WORD_FILTER
 #include "WordFilterSony.h"
#endif
#if	NP_HAS_MESSAGING
 #include "MessagingSony.h"
#endif
#if	NP_HAS_TUSTSS
 #include "TusTssSony.h"
#endif
#if	NP_HAS_COMMERCE
 #include "CommerceSony.h"
#endif
#if	NP_HAS_NP_DIALOGS
 #include "NpDialogsSony.h"
#endif
#if	NP_HAS_NP_FACEBOOK
#include "FacebookSony.h"
#endif
#if NP_HAS_TWITTER
#include "TwitterSony.h"
#endif
#if NP_HAS_TICKETING
#include "Ticketing.h"
#endif
#if NP_HAS_NP_REQUESTS
#include "NpAsyncRequests.h"
#endif

#if defined(GLOBAL_EVENT_QUEUE)
UnityPlugin::PSP2SystemEventManager gSystemEventManager;
#endif

// Declare various interfaces to the player runtime.
IPluginUnity* g_IUnity = NULL;
IPluginSceAppParams* g_ISceAppParams = NULL;
IPluginSceNpParams* g_ISceNpParams = NULL;


IPluginPSP2* g_IPSP2 = NULL;

void SetupRuntimeInterfaces()
{
	if(g_QueryInterface)
	{
#if defined(GLOBAL_EVENT_QUEUE)
		UnityEventQueue::IEventQueue* eventQueue =  GetRuntimeInterface<UnityEventQueue::IEventQueue>(PRX_PLUGIN_IFACE_ID_GLOBAL_EVENT_QUEUE);
		if (eventQueue)
		{
			gSystemEventManager.Initialize(eventQueue);
		}
#endif
		g_IUnity = GetRuntimeInterface<IPluginUnity>(PRX_PLUGIN_IFACE_ID_UNITY);
		g_ISceAppParams = GetRuntimeInterface<IPluginSceAppParams>(PRX_PLUGIN_IFACE_ID_SCE_APP_PARAMS);
		g_ISceNpParams = GetRuntimeInterface<IPluginSceNpParams>(PRX_PLUGIN_IFACE_ID_SCE_NP_PARAMS);
		g_IPSP2 = GetRuntimeInterface<IPluginPSP2>(PRX_PLUGIN_IFACE_ID_PSP2);
	}
}

using namespace sce::Toolkit::NP;
using namespace sce::Toolkit::NP::Utilities;
using namespace UnityPlugin;

bool gInitialized = false;
unsigned int gCreationFlags = 0;
static	bool	bIsShuttingDown = false;


bool	IsShuttingDown( void )
{
	return	bIsShuttingDown;
}

void	SetShutDown(bool shuttingDown=true)
{
	bIsShuttingDown = shuttingDown;
}

void myNpToolkitCallback(const sce::Toolkit::NP::Event& event)
{
	if( IsShuttingDown() )
	{
		UnityPlugin::Messages::LogWarning("NP request completed after after shutdown: service = %d, event = %d\n", event.service, event.event);
		return;
	}
	
	switch(event.service)
	{
	case core:
		UNITY_TRACE("Received core callback %d\n",event.event);

		switch(event.event)
		{
			case Event::enetDown:
				// Do nothing (Vita & PS4), this event is now handled by NetCtlStatusCallback() which can be found in NetCtlStatus.cpp
				// On PS3 this still needs looking into, the callback code doesn't seem to work.
				break;

			case Event::enetUp:
				UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_ConnectionUp);
				break;

			case Event::loggedIn:
				UnityPlugin::gSignedInState.ProcessEvent(event);;
				break;

			case Event::loggedOut:
				UnityPlugin::gSignedInState.ProcessEvent(event);;
				break;

			default:
				DBG_LOG_WARNING("core service event not handled: %d", event.event);
				break;
		}
		break;

	case netInfo:
#if NP_HAS_BANDWIDTH
		if(UnityPlugin::gNetInfo.ProcessEvent(event)) return;
#endif
		if(UnityPlugin::gSignedInState.ProcessEvent(event)) return;
		DBG_LOG_WARNING("netInfo service event not handled: %d", event.event);
		break;

#if NP_HAS_FRIENDS_LIST
	case friends:
		if(UnityPlugin::gFriendsList.ProcessEvent(event)) return;
		DBG_LOG_WARNING("friends service event not handled: %d", event.event);
		break;
#endif
#if NP_HAS_MATCHING
	case matching:
		if(UnityPlugin::gMatching.ProcessEvent(event)) return;
		DBG_LOG_WARNING("matching service event not handled: %d", event.event);
		break;
#endif
	case profile:
		if(UnityPlugin::gUserProfile.ProcessEvent(event)) return;
		DBG_LOG_WARNING("profile service event not handled: %d", event.event);
		break;

#if NP_HAS_TROPHIES
	case trophy:
		if(UnityPlugin::gTrophies.ProcessEvent(event)) return;
		DBG_LOG_WARNING("trophy service event not handled: %d", event.event);
		break;
#endif
#if NP_HAS_RANKING
	case ranking:
		if(UnityPlugin::gRanking.ProcessEvent(event)) return;
		DBG_LOG_WARNING("ranking service event not handled: %d", event.event);
		break;
#endif
#if NP_HAS_ONLINE_PRESENCE
	case presence:
		if(UnityPlugin::gPresence.ProcessEvent(event)) return;
		DBG_LOG_WARNING("presence service event not handled: %d", event.event);
		break;
#endif
#if NP_HAS_WORD_FILTER
	case wordFilter:
		if(UnityPlugin::gWordFilter.ProcessEvent(event)) return;
		DBG_LOG_WARNING("wordfilter service event not handled: %d", event.event);
		break;
#endif
#if NP_HAS_COMMERCE
	case commerce:
		if(UnityPlugin::gCommerce->ProcessEvent(event)) return;
		DBG_LOG_WARNING("commerce service event not handled: %d", event.event);
		break;
#endif

	case auth:

#if NP_HAS_TICKETING
		if(UnityPlugin::gTicketing.ProcessEvent(event)) return;
#endif

		DBG_LOG_WARNING("auth service event not handled: %d", event.event);
		break;

#if NP_HAS_NP_FACEBOOK
	case sns:
		if(UnityPlugin::gFacebook.ProcessEvent(event)) return;
		DBG_LOG_WARNING("sns service event not handled: %d", event.event);
		break;
#endif

#if NP_HAS_MESSAGING
	case messaging:
		if(UnityPlugin::gMessaging.ProcessEvent(event)) return;
		DBG_LOG_WARNING("messaging service event not handled: %d", event.event);
		break;
#endif




#if NP_HAS_NEAR
	case near:
		DBG_LOG_WARNING("near service event not handled: %d", event.event);
		break;
#endif

#if NP_HAS_TUSTSS
	case tss:
		if(UnityPlugin::gTusTss.ProcessEvent(event)) return;
		DBG_LOG_WARNING("tss service event not handled: %d", event.event);
		break;

	case tus:
		if(UnityPlugin::gTusTss.ProcessEvent(event)) return;
		DBG_LOG_WARNING("tus service event not handled: %d", event.event);
		break;
#endif

	default:
		DBG_LOG_WARNING("unknown service event not handled: %d", event.event);
		break;
	}
}


// Initialise toolkit interfaces that can no longer be constructed as a global (require external allocator to be initialised)
void InitialiseToolkitInterfaces()
{
	gCommerce = new CachedCommerce();
}



#if PSP2_USING_WEBAPI
#include <libhttp.h>
#define LIBHTTP_POOL_SIZE	(512 * 1024)
#define LIBSSL_POOL_SIZE	(300 * 1024)
#endif

int InitializeToolkitPSP2(unsigned int creationFlags, int npAgeRating)
{
	int ret = 0 ;
	SceAppUtilInitParam initParam;
	SceAppUtilBootParam bootParam; 
	
#if PSP2_USING_WEBAPI
	// Initialise Http and Ssl libs, we need to do this here before calling NP::Interface::init()
	// because NP::Interface::init() also initialises them but with heap sizes which are too small
	// for our needs.
	sceHttpInit(LIBHTTP_POOL_SIZE);
	sceSslInit(LIBSSL_POOL_SIZE);
#endif

	memset( &initParam, 0, sizeof(SceAppUtilInitParam) );
	memset( &bootParam, 0, sizeof(SceAppUtilBootParam) );

	ret = sceAppUtilInit( &initParam, &bootParam );

	bool hasTrophyPack;
	SceNpCommunicationId* commID;
	SceNpCommunicationPassphrase* commPass;
	SceNpCommunicationSignature* commSig;
	if(g_ISceNpParams)
	{
		commID = (SceNpCommunicationId*)g_ISceNpParams->NpCommunicationsID();
		commPass = (SceNpCommunicationPassphrase*)g_ISceNpParams->NpCommunicationsPassphrase();
		commSig = (SceNpCommunicationSignature*)g_ISceNpParams->NpCommunicationsSignature();
		Assert(commID && commPass && commSig);
		hasTrophyPack = g_ISceNpParams->NpHasTrophyPack();
	}
	else
	{
		// DEPRECATED; for backwards compatibility with old versions of Unity that don't support plugin interfaces.
		commID = (SceNpCommunicationId*)g_AppInfo.m_NpCommunicationId;
		commPass = (SceNpCommunicationPassphrase*)g_AppInfo.m_NpCommunicationPassphrase;
		commSig = (SceNpCommunicationSignature*)g_AppInfo.m_NpCommunicationSignature;
		Assert(commID && commPass && commSig);
		hasTrophyPack = g_AppInfo.m_NpHasTrophyPack;
	}

	sce::Toolkit::NP::CommunicationId id(*commID, *commPass, *commSig);
	sce::Toolkit::NP::Parameters params(myNpToolkitCallback, id);
	if(g_ISceNpParams)
	{
		params.m_title = ServiceId(std::string(g_ISceNpParams->NpServiceID()));
		params.m_ageRating = (npAgeRating >= 0) ? npAgeRating : g_ISceNpParams->NpAgeRating();
	}
	else
	{
		// DEPRECATED; for backwards compatibility with old versions of Unity that don't support plugin interfaces.
		params.m_title = ServiceId(std::string(g_AppInfo.m_NpServiceID));
		params.m_ageRating = (npAgeRating >= 0) ? npAgeRating : g_AppInfo.m_NpAgeRating;
	}

	int skuFlags = 0;
	ret = sceAppUtilAppParamGetInt(SCE_APPUTIL_APPPARAM_ID_SKU_FLAG, &skuFlags);
	bool isTrial = skuFlags == SCE_APPUTIL_APPPARAM_SKU_FLAG_TRIAL;

	params.m_trial = isTrial;
	
	ret = sce::Toolkit::NP::Interface::init(params);
	if (ret < 0 )
	{
		UnityPlugin::Messages::LogError("NP Toolkit init failed, ret = 0x%x\n", ret);
		return ret;
	}

	InitialiseToolkitInterfaces();

	if(hasTrophyPack && !isTrial && ((creationFlags & kNpToolkitCreate_DoNotInitializeTrophies) == 0))
	{
		UnityPlugin::gTrophies.RegisterTrophyPack((creationFlags & kNpToolkitCreate_CacheTrophyIcons) != 0);
		// NOTE: NP initialization isn't complete until the trophy pack registration has
		// completed (asynchronous) so we let the trophy event handler send the kNPToolKit_NPInitialized
		// message once it knows it's completed.
	}
	else
	{
		// No trophy pack to register so send the NP Initialized message now.
		UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_NPInitialized);
	}
	gInitialized = true;

	return ret;
}



int InitializeToolkit(unsigned int creationFlags, int npAgeRating)
{
	if(gInitialized)
	{
		UnityPlugin::Messages::LogWarning("NP Toolkit already initialized\n");
		return 0;
	}

	// We might have previously called Shutdown, so clear the shutdown flag now.
	SetShutDown(false);

	gCreationFlags = creationFlags;

	RegisterNetCtlStatusCallback();

	SetupRuntimeInterfaces();


	return InitializeToolkitPSP2(creationFlags, npAgeRating);
}

sce::Toolkit::NP::ServiceType GetSceNpServiceType(NpServiceType serviceType)
{
	switch(serviceType)
	{
	case UnityPlugin::NetInfo:
		return sce::Toolkit::NP::netInfo;
	case UnityPlugin::Profile:
		return sce::Toolkit::NP::profile;
	case UnityPlugin::Friends:
		return sce::Toolkit::NP::friends;
	case UnityPlugin::Messaging:
		return sce::Toolkit::NP::messaging;
	case UnityPlugin::Ranking:
		return sce::Toolkit::NP::ranking;
	case UnityPlugin::Presence:
		return sce::Toolkit::NP::presence;
	case UnityPlugin::Tus:
		return sce::Toolkit::NP::tus;
	case UnityPlugin::Tss:
		return sce::Toolkit::NP::tss;
	case UnityPlugin::Matching:
		return sce::Toolkit::NP::matching;
	case UnityPlugin::Sns:
		return sce::Toolkit::NP::sns;
	case UnityPlugin::Commerce:
		return sce::Toolkit::NP::commerce;
	case UnityPlugin::Auth:
		return sce::Toolkit::NP::auth;
	case UnityPlugin::Trophy:
		return sce::Toolkit::NP::trophy;
	case UnityPlugin::WordFilter:
		return sce::Toolkit::NP::wordFilter;

	case UnityPlugin::Near:
		return sce::Toolkit::NP::near;

	case UnityPlugin::WebApi:
		return sce::Toolkit::NP::webApi;
	case UnityPlugin::Sessions:
		return sce::Toolkit::NP::sessions;
	case UnityPlugin::GameCustomData:
		return sce::Toolkit::NP::gameCustomData;
	case UnityPlugin::Challenges:
		return sce::Toolkit::NP::challenges;

	default:
		// return sce::Toolkit::NP::size to signify an error.
		return sce::Toolkit::NP::size;
	}
}

ErrorCode RegisterServiceLabel(NpServiceType serviceType, int serviceLabel)
{
	// Not supported on PS Vita and PS3.
	return NP_ERR_NOT_SUPPORTED;
}

ErrorCode RegisterNpCommsID(NpServiceType serviceType, const char* npCommsID, const unsigned char* npCommunicationPassphrase, const unsigned char* npCommunicationSignature)
{
#if __ORBIS__ && (SCE_ORBIS_SDK_VERSION>0x03500000u)
	return NP_ERR_NOT_SUPPORTED;
#else
	sce::Toolkit::NP::ServiceType type = GetSceNpServiceType(serviceType);
	if (type == sce::Toolkit::NP::size)
	{
		return NP_ERR_INVALID_NP_SERVICE_TYPE;
	}

	SceNpCommunicationId commsID;
	SceNpCommunicationPassphrase passphrase;
	SceNpCommunicationSignature signature;

	memset(&commsID, 0, sizeof(commsID));
	memcpy(&commsID.data[0], npCommsID, 9);
	const char* subIdString = &npCommsID[10];
	commsID.num = atoi(subIdString);

	memcpy(&passphrase.data[0], npCommunicationPassphrase, SCE_NP_COMMUNICATION_PASSPHRASE_SIZE);

	memcpy(&signature.data[0], npCommunicationSignature, SCE_NP_COMMUNICATION_SIGNATURE_SIZE);

	sce::Toolkit::NP::CommunicationId id(commsID, passphrase, signature);
	int ret = sce::Toolkit::NP::Interface::registerNpCommsId(id, type);
	return ProcessSceResult(ret, true, "NpToolkit", __FUNCTION__, __LINE__, "registerNpCommsId failed");
#endif
}

ErrorCode RegisterServiceID(NpServiceType serviceType, const char* serviceID)
{
#if __ORBIS__ && (SCE_ORBIS_SDK_VERSION>0x03500000u)
    return NP_ERR_NOT_SUPPORTED;
#else
    sce::Toolkit::NP::ServiceType type = GetSceNpServiceType(serviceType);
    if (type == sce::Toolkit::NP::size)
    {
        return NP_ERR_INVALID_NP_SERVICE_TYPE;
    }

    ServiceId id = ServiceId(serviceID);

    int ret = sce::Toolkit::NP::Interface::registerServiceId(id, type);
    return ProcessSceResult(ret, true, "NpToolkit", __FUNCTION__, __LINE__, "RegisterServiceID failed");
#endif
}


void	ShutDownToolkit( void )
{
	if( IsShuttingDown() )
	{
		return;
	}

#if defined(GLOBAL_EVENT_QUEUE)
	gSystemEventManager.Shutdown();
#endif

	SetShutDown();

	printf("Shutting down NPToolkit...\n");
	sce::Toolkit::NP::Interface::terminate();
	gInitialized = false;
}

// This should only be called if the Unity event queue is not available, e.g. Unity 4.3
int processAppMgrSystemEvents()
{
	int res = SCE_OK;
	SceAppMgrAppState appStatus;
	res = sceAppMgrGetAppState(&appStatus);
	if(res != SCE_OK)
	{
		UnityPlugin::Messages::LogError("sceAppMgrGetAppState() - %s\n", UnityPlugin::LookupSceErrorCode(res));
	}
	else if(appStatus.systemEventNum > 0)
	{
		for (SceUInt32 i = 0; i < appStatus.systemEventNum; i++)
		{
			SceAppMgrSystemEvent systemEvent;
			res =sceAppMgrReceiveSystemEvent(&systemEvent);
			if(res != SCE_OK)
			{
				UnityPlugin::Messages::LogError("sceAppMgrReceiveSystemEvent() - %s\n", UnityPlugin::LookupSceErrorCode(res));
			}
			else
			{
				// Handle Np messaging system events.
				if(UnityPlugin::gMessaging.ProcessSystemEvent(systemEvent))
				{
					return res;
				}

				// Handle Np commerce system events.
				if(UnityPlugin::gCommerce->ProcessSystemEvent(systemEvent))
				{
					return res;
				}

				// Event not handled above so...
				switch(systemEvent.systemEvent)
				{
					case SCE_APPMGR_SYSTEMEVENT_ON_RESUME:
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_SysResume);
						break;

					default:
						DBG_LOG_WARNING("Unknown system event received = %d", systemEvent.systemEvent);
						break;
				}
			}
		}
	}

	return res;
}

// This should only be called if the Unity event queue is not available, e.g. Unity 4.3
int processAppMgrAppEvents()
{
	int res = SCE_OK;
	SceAppMgrAppState appStatus;
	res = sceAppMgrGetAppState(&appStatus);
	if(res != SCE_OK)
	{
		UnityPlugin::Messages::LogError("sceAppMgrGetAppState() - %s\n", UnityPlugin::LookupSceErrorCode(res));
	}
	else if(appStatus.appEventNum > 0)
	{
		SceAppUtilAppEventParam	eventParam;
		memset(&eventParam, 0, sizeof(SceAppUtilAppEventParam));
		res = sceAppUtilReceiveAppEvent(&eventParam);
		if(res != SCE_OK)
		{
			UnityPlugin::Messages::LogError("sceAppUtilReceiveAppEvent() - %s\n", UnityPlugin::LookupSceErrorCode(res));
		}
		else
		{
			if(UnityPlugin::gMessaging.ProcessApplicationEvent(eventParam) == false)
			{
				switch(eventParam.type)
				{
					case SCE_APPUTIL_APPEVENT_TYPE_INVALID:
					case SCE_APPUTIL_APPEVENT_TYPE_LIVEAREA:
					case SCE_APPUTIL_APPEVENT_TYPE_SCREENSHOT_NOTIFICATION:
						DBG_LOG_WARNING("Application event not handled = %d", eventParam.type);
						break;

					default:
						DBG_LOG_WARNING("Unknown app event received = %d", eventParam.type);
						break;
				}
			}
		}
	}
	
	return res;
}


void Update()
{
	if( IsShuttingDown() )
	{
		return;
	}

	
	// Process system events, NOTE that if g_QueryInterface != NULL then the player runtime handles application
	// events and passes them through to all plugins using the global event queue, in which case we should not
	// call processAppMgrAppEvents, instead the events from the global queue are processed by PSP2SystemEventManager
	// and passed to the relevant systems.
	if (!g_QueryInterface)
	{
		// g_QueryInterface not set so handle App Manager events the old way, e.g. Unity 4.3. Unity 5.x uses the global event queue.
		processAppMgrSystemEvents();
	}
	// Process application events, NOTE that if g_IAppData != NULL then the player runtime handles application
	// events and passes them through to all plugins using the global event queue, in which case we should not
	// call processAppMgrAppEvents, instead the events from the global queue are processed by PSP2SystemEventManager
	// and passed to the relevant systems. Checking for g_IAppData looks a bit arbitrary but we know that g_IAppData
	// was added at the same time as the app event code was added to the runtime, so it's a good compatibility check.
	if (!g_ISceAppParams)
	{
		// Player does not process app manager app events, so we must process them ourselves.
		processAppMgrAppEvents();
	}

	if (g_GetMsgAttachmentThreaded.PollForCompletion())
	{
		gMessaging.ProcessInviteAttachement(g_GetMsgAttachmentThreaded.GetAttachmentData(), g_GetMsgAttachmentThreaded.GetAttachmentSize());
	}

    if (g_NpGetAuthCodeThreaded.PollForCompletion())
    {
        gTicketing.ProcessAuthCode();
    }

	UnityPlugin::gUserProfile.Update();

#if	NP_HAS_MESSAGING
	UnityPlugin::gMessaging.Update();
#endif
#if	NP_HAS_NP_DIALOGS
	UnityPlugin::gNpDialogs.Update();
#endif
#if	NP_HAS_TWITTER
	UnityPlugin::gTwitter.Update();
#endif
#if	NP_HAS_NP_COMMERCE
	UnityPlugin::gCommerce->Update();
#endif
#if NP_HAS_NP_REQUESTS
	UnityPlugin::gRequests.Update();
#endif
}

SCE_MODULE_INFO( UnityNpToolkit, SCE_MODULE_ATTR_NONE, 1, 1);


extern "C" int module_start(SceSize sz, const void* arg)
{
	if (!ProcessPrxPluginArgs(sz, arg, "UnityNpToolkit"))
	{
		// Failed.
		return SCE_KERNEL_START_NO_RESIDENT;
	}

	return SCE_KERNEL_START_SUCCESS;
}

