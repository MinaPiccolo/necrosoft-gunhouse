#pragma once


#define SONY_PLATFORM 1

#include "PlayerInterface/PrxPluginInterface.h"
#include <kernel.h>
#include <moduleinfo.h>
#include <libsysmodule.h>
#include <libdbg.h>
#include <np.h>
// Note that in order to incorporate fixes to the SCE npToolkit library that are not yet in the SDK
// we are linking with the library from the "sdklibs\release\" which is included in this source package
// instead of from the SDK at "$(SCE_PSP2_SDK_DIR)\target\lib\", see UnityNpToolkit project link settings.
// Specifically there is a fix for matching session member lists not being updated correctly when multiple
// users join a matching session at the same time which has not yet been included in an SDK patch.
//
// The np_toolkit.h file has not been modified so we can include the SDK version.
#include <np_toolkit.h>

#include "PlayerInterface/UnityPrxPlugin.h"
#include "PlayerInterface/IPluginUnity.h"
#include "PlayerInterface/IPluginSceAppParams.h"
#include "PlayerInterface/IPluginSceNpParams.h"
#include "PlayerInterface/IPluginPSP2.h"

//	COMPONENT CAPABILITIES DEFINED HERE
#define	NP_HAS_ERROR_CODES		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_RANKING			(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_BANDWIDTH		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_FRIENDS_LIST		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_ONLINE_PRESENCE	(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_TROPHIES			(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )	//	Already exists on PS3 and must be removed before we can let NPToolkit take on responsibilities	
#define	NP_HAS_MATCHING			(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_WORD_FILTER		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_MESSAGING		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_TUSTSS			(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_COMMERCE			(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__ )
#define	NP_HAS_NP_DIALOGS		(SN_TARGET_PSP2 || __ORBIS__ )	//	Does not exist on PS3
#define NP_HAS_NP_FACEBOOK		(SN_TARGET_PS3 || __ORBIS__  ) // Was also supported on PSP2 but removed in SDK 3.570
#define NP_HAS_TWITTER			0	// Was only supported on PSP2 but removed in SDK 3.570
#define	NP_HAS_NEAR				(SN_TARGET_PSP2)
#define NP_HAS_NP_COMMERCE		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__  )
#define	NP_HAS_TICKETING		(SN_TARGET_PSP2 || SN_TARGET_PS3 || __ORBIS__)
#define NP_HAS_NP_REQUESTS		(__ORBIS__)



#define PRX_EXPORT extern "C" __declspec (dllexport)
#define	DO_EXPORT( _type, _func ) PRX_EXPORT _type _func
#include <np_profile_dialog.h>
#include <np_friendlist_dialog.h>

