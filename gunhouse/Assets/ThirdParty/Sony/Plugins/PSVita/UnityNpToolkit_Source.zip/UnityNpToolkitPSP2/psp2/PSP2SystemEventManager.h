#pragma once

#if defined(GLOBAL_EVENT_QUEUE)
namespace UnityPlugin
{
	class PSP2SystemEventManager
	{
	public:
		PSP2SystemEventManager() : m_EventQueue(NULL) {}
		~PSP2SystemEventManager() {}

		void Initialize(UnityEventQueue::IEventQueue* eventQueue);
		void Shutdown();

		// System event handlers...

		// SCE_APPMGR_SYSTEMEVENT_ON_RESUME
		void HandleEvent(PSP2OnResume& data);

		// SCE_APPMGR_SYSTEMEVENT_ON_NP_MESSAGE_ARRIVED
		void HandleEvent(PSP2OnNpMessage& data);

		// SCE_APPMGR_SYSTEMEVENT_ON_STORE_PURCHASE:
		void HandleEvent(PSP2OnStorePurchase& data);

		// SCE_APPMGR_SYSTEMEVENT_ON_STORE_REDEMPTION
		void HandleEvent(PSP2OnStoreRedemption& data);

		// App event handlers...

		// SCE_APPUTIL_APPEVENT_TYPE_NP_INVITE_MESSAGE
		void HandleEvent(PSP2OnAppEventNpInviteMessage& data);

		// SCE_APPUTIL_APPEVENT_TYPE_NP_APP_DATA_MESSAGE
		void HandleEvent(PSP2OnAppEventNpDataMessage& data);

		// SCE_APPUTIL_APPEVENT_TYPE_NP_ACTIVITY
		void HandleEvent(PSP2OnAppEventNpActivity& data);

		// SCE_APPUTIL_APPEVENT_TYPE_SESSION_INVITATION
		void HandleEvent(PSP2OnAppEventSessionInvite& data);

		// SCE_APPUTIL_APPEVENT_TYPE_GAME_CUSTOM_DATA
		void HandleEvent(PSP2OnAppEventGameCustomData& data);

	private:
		UnityEventQueue::IEventQueue* m_EventQueue;
	};
}
#endif
