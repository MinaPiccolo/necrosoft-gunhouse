#include "SignInSony.h"
#include "toolkit.h"
#include "UserProfileSony.h"
#include "MatchingSony.h"
#include "MessagePipe.h"
#include "ErrorCodesSony.h"

#if NP_HAS_RANKING
 #include "RankingSony.h"
#endif
using namespace sce::Toolkit::NP;
using namespace sce::Toolkit::NP::Utilities;

namespace UnityPlugin
{
	SignedInState gSignedInState;
	int gCurrentPS4UserId=0;

	DO_EXPORT( ErrorCode, PrxSignin ) ()
	{
		return gSignedInState.SignIn();
	}

	DO_EXPORT( bool, PrxSigninIsBusy ) ()
	{
		return gSignedInState.IsBusy();
	}

	DO_EXPORT( bool, PrxIsSignedIn ) ()
	{
		return gSignedInState.IsSignedIn();
	}

	DO_EXPORT( bool, PrxSigninGetLastError ) (ResultCode* result)
	{
		return gSignedInState.GetLastError(result);
	}

	DO_EXPORT( int, PrxSetCurrentUserId ) (int UserId)
	{
		int lastValue = gCurrentPS4UserId;
		gCurrentPS4UserId = UserId;
		return lastValue;
	}

	DO_EXPORT( int, PrxGetCurrentUserId ) ()
	{
		return gCurrentPS4UserId;
	}

	DO_EXPORT( int, PrxLogOutUser ) (int UserId)
	{
		return 0;
	}

	DO_EXPORT( int, PrxGetUserSigninStatus ) (int userID, void **npid)
	{
		return 0;
	}

	
	
	SignedInState::SignedInState()
		: m_Busy(false)
		, m_DialogOpen(false)
		, m_PlatformSignedIn(false)
		, m_ApplicationSignedIn(false)
		, m_LastResult("SignIn")
	{
	}

	bool SignedInState::IsBusy()
	{
		Mutex::AutoLock lock(m_Lock);
		return m_Busy;
	}

	ErrorCode SignedInState::SignIn()
	{
		bool TriggerSignInSuccessful = false;
		{
			if(IsBusy())
			{
				return m_LastResult.SetResult(NP_ERR_BUSY, true);
			}

			Mutex::AutoLock lock(m_Lock);

			if(m_DialogOpen)
			{
				return m_LastResult.SetResult(NP_ERR_BUSY, true);
			}

			m_LastResult.Reset();

			int ret = sce::Toolkit::NP::NetInfo::Interface::psnLoginDialogStart();
			if(ret == SCE_TOOLKIT_NP_SUCCESS)
			{
				m_DialogOpen = true;
				m_Busy = true;
			}
			else
			{
				return m_LastResult.SetResultSCE(ret, true, __FUNCTION__, __LINE__);
			}
		}

		if (TriggerSignInSuccessful == true)	// this has to be done outside of the lock 
		{
			SignInSuccessful(0);
		}

		return m_LastResult.GetResult();
	}



	bool SignedInState::ProcessEvent(const sce::Toolkit::NP::Event& npevent)
	{
		Mutex::AutoLock lock(m_Lock);
		bool handled = false;
		
		switch(npevent.event)
		{
		case Event::loggedIn:
			// This only signifies that the user is logged into PSN, not that the application is.
			m_PlatformSignedIn = true;
			handled = true;
			break;

		case Event::loggedOut:
			m_PlatformSignedIn = false;
			m_ApplicationSignedIn = false;
			Messages::AddMessage(Messages::kNPToolKit_SignedOut);
			handled = true;
			break;
			
		case Event::netInfoDialogComplete:
			if(npevent.returnCode == SCE_NET_CTL_ERROR_FLIGHT_MODE_ENABLED)
			{
				m_LastResult.SetResult(NP_SIGNED_IN_FLIGHT_MODE, true);
			}

			if(npevent.returnCode == 0 || npevent.returnCode == SCE_NET_CTL_ERROR_FLIGHT_MODE_ENABLED)
			{
				SignInSuccessful(0);
			}
			else if(npevent.returnCode == 1)	// Dialog canceled.
			{
				m_LastResult.SetResult(NP_ERR_NOT_SIGNED_IN, true, __FUNCTION__, __LINE__);
				Messages::AddMessage(Messages::kNPToolKit_SignInError);
			}
			else
			{
				m_LastResult.SetResultSCE(npevent.returnCode, true, __FUNCTION__, __LINE__);
				Messages::AddMessage(Messages::kNPToolKit_SignInError);
			}

			m_Busy = false;
			m_DialogOpen = false;
			handled = true;
			break;

		default:
			break;
		}

		return handled;
	}


	// a user has successfully signed into PSN, the local UserId is passed in on platforms where it's relevant
	void SignedInState::SignInSuccessful(int UserId)
	{
		m_PlatformSignedIn = true;
		m_ApplicationSignedIn = true;
		Messages::AddUserMessage(Messages::kNPToolKit_SignedIn, UserId);
#if NP_HAS_RANKING
		if ((gCreationFlags & kNpToolkitCreate_NoRanking) == 0)
		{
			// Initialize ranking cache.
			const int boardLineCount = 8;
			const int writeLineCount = 20;
			const bool friendCache = true;
			const int rangeLineCount = 121;
			UnityPlugin::gRanking.RegisterCache(boardLineCount, writeLineCount, friendCache, rangeLineCount);
		}
#endif
		// Initialize user profile cache.
		UnityPlugin::gUserProfile.RequestUserProfile();
	}






	// Vita doesn't have multiplt users but the SCE Vita npToolkit does include user id in many structures to maintain parity with PS4.
	int GetUserId()
	{
		return 0;
	}



} // namespace UnityPlugin
