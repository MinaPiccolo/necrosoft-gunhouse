#include <stdio.h>
#include "PlatformMutex.h"

namespace UnityPlugin
{
	PlatformMutex::PlatformMutex()
	{
		Create();
	}

	PlatformMutex::~PlatformMutex()
	{
		Destroy();
	}

	void PlatformMutex::Create()
	{
		if(m_Mutex)
		{
			return;
		}

		SceUID ret = sceKernelCreateMutex("UnityPluginMutex", SCE_KERNEL_ATTR_TH_PRIO | SCE_KERNEL_MUTEX_ATTR_RECURSIVE, 0, NULL);
		Assert(ret >= 0);
		m_Mutex = ret;
		return;
	}

	void PlatformMutex::Destroy()
	{
		if(m_Mutex == 0)
		{
			return;
		}
		SceUID ret = sceKernelDeleteMutex(m_Mutex);
		Assert(ret == SCE_OK);
		m_Mutex = 0;
		return;
	}

	void PlatformMutex::Lock()
	{
		SceUID ret = sceKernelLockMutex(m_Mutex, 1, 0);
		Assert(ret == SCE_OK);
	}

	void PlatformMutex::Unlock()
	{
		SceUID ret = sceKernelUnlockMutex(m_Mutex, 1);
		Assert(ret == SCE_OK);
	}


	PlatformSemaphore::PlatformSemaphore()
	{
		Create();
	}

	PlatformSemaphore::~PlatformSemaphore()
	{
		Destroy();
	}

	void PlatformSemaphore::Reset()
	{
		Destroy();
		Create();
	}

	void PlatformSemaphore::Create()
	{
		m_Semaphore = sceKernelCreateSema("UnityPluginSemaphore", 0, 0, 128, NULL);
		Assert(!(m_Semaphore < SCE_OK));
	}

	void PlatformSemaphore::Destroy()
	{
		SceInt32 result;
		result = sceKernelDeleteSema(m_Semaphore);
		Assert(!(result < SCE_OK));
	}

	void PlatformSemaphore::WaitForSignal()
	{
		SceInt32 result;
		result = sceKernelWaitSema(m_Semaphore, 1, NULL);
		Assert(!(result < SCE_OK));
	}

	void PlatformSemaphore::Signal()
	{
		SceKernelSemaInfo info;
		info.size = sizeof(SceKernelSemaInfo);

		SceInt32 result;
		result = sceKernelGetSemaInfo(m_Semaphore, &info);
		Assert(!(result < SCE_OK));

		result = sceKernelSignalSema(m_Semaphore, 1);
		Assert(!(result < SCE_OK));
	}

} //namespace UnityPlugin
