#include <stdio.h>

#include "UnityNP.h"
#include "toolkit.h"
#include "MessagePipe.h"
#include <rtc.h>

extern IPluginPSP2* g_IPSP2;

// Remap a Unix style path to a Vita style path if required.
// Note that the remapped string is stored statically and is overwritten the next
// time this function is called, also not thread safe.
const char* RemapPath(const char* path)
{
	if (g_IPSP2)
	{
		static char buffer[512];
		g_IPSP2->RemapUnixPath(buffer, path, sizeof(buffer));
		return buffer;
	}
	return path;
}

namespace UnityPlugin
{
	DO_EXPORT( int, PrxInitialize ) (unsigned int creationFlags)
	{
		return InitializeToolkit(creationFlags, -1);
	}

    DO_EXPORT( int, PrxRegisterServiceID ) (int serviceType, const char* serviceID)
    {
        return RegisterServiceID((NpServiceType)serviceType, serviceID);
    }

	DO_EXPORT( int, PrxRegisterNpCommsID ) (int serviceType, const char* npCommsID, const unsigned char* npCommunicationPassphrase, const unsigned char* npCommunicationSignature)
	{
		return RegisterNpCommsID((NpServiceType)serviceType, npCommsID, npCommunicationPassphrase, npCommunicationSignature);
	}

	DO_EXPORT( int, PrxRegisterServiceLabel ) (int serviceType, int serviceLabel)
	{
		return RegisterServiceLabel((NpServiceType)serviceType, serviceLabel);
	}

	DO_EXPORT( int, PrxInitializeWithNpAgeRating ) (unsigned int creationFlags, int npAgeRating)
	{
		return InitializeToolkit(creationFlags, npAgeRating);
	}

	DO_EXPORT( void, PrxAddNpAgeRatingRestriction ) (const char* countryCode, int npAgeRating)
	{
		UnityPlugin::Messages::LogWarning("AddNpAgeRatingRestriction is not supported on this platform.\n");
	}
	
	std::string gSessionImageFilePath;

	DO_EXPORT( void, PrxSetSessionImage ) (const char* imageFilePath)
	{
		gSessionImageFilePath.assign(RemapPath(imageFilePath));
	}

	DO_EXPORT( void, PrxUpdate ) ()
	{
		Update();
	}

	DO_EXPORT( void, PrxShutDown ) ()
	{
		ShutDownToolkit();
	}

	DO_EXPORT( UInt64, PrxGetNetworkTime ) ()
	{
		SceRtcTick tick;
		if(sceRtcGetCurrentNetworkTick(&tick) < 0)
		{
			return 0;
		}
		return (UInt64)tick.tick * 10;
	}
}
