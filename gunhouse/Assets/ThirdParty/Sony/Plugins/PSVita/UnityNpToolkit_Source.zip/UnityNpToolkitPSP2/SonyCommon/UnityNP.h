#ifndef _UNITY_NP_H
#define _UNITY_NP_H

#define PRX_EXPORT extern "C" __declspec (dllexport)
#define	DO_EXPORT( _type, _func ) PRX_EXPORT _type _func

#include <assert.h>
#include <stdio.h>
#define Assert assert

#include "SonyCommonIncludes.h"
#include "ErrorCodesSony.h"

#include <assert.h>
#include <stdio.h>
#define Assert assert

#if NDEBUG
#define UNITY_TRACE(...)
#define UNITY_TRACEIF(condition, ...)
#else
#define UNITY_TRACE(...)				printf(__VA_ARGS__)
#define UNITY_TRACEIF(condition, ...)	if (condition) printf(__VA_ARGS__)
#endif

typedef unsigned char UInt8;
typedef unsigned short UInt16;
typedef unsigned int UInt32;
typedef unsigned long long UInt64;
typedef char Int8;
typedef short Int16;
typedef int Int32;
typedef long long Int64;


void	ShutDownToolkit( void );

const char* RemapPath(const char* path);

		#define MAX_NUM_USERS_SIGNED_IN (1)



// on PS4 some structures (e.g. CreateSessionRequest) constructors will initialise members (including non-zero availablePlatforms member) ... on other platforms they need to be zero-ed as they have no constructors
#if __ORBIS__ || PSP2_USING_WEBAPI || SN_TARGET_PS3
	#define INIT(x)
#else
	#define INIT(x) memset(&x, 0, sizeof(x))
#endif



#endif	//_UNITY_NP_H




