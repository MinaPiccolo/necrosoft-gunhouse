Unity NP Toolkit plugin extension for Vita.

Folders in this project...

psp2 - Contains a Visual Studio solution for building the native plugin.
Assemblies - Contains a MonoDevelop project which builds a managed assembly that interfaces between the native plugin and the scripts.
SonyCommon - Contains the majority of the source files(.cpp & .h) for the plugin, some others are in the psp2 folder.

Building the UnityNPToolkit native plugin.

When building the plugin the resulting module is automatically copied to the plugins folder in the example project, this is done as a post-build step by running copybuilds.bat, depending on the layout of your project you may need to edit this file to copy to the correct location.

Before building the native plugin you must first edit psp2/copybuilds.bat and make the following changes...

Set the UNITY_INTERNAL var to 0.
Set the UNITY_PROJECT_PATH var to where the plugin should be copied to, this should be the root of your Unity project.

Load UnityNpToolkit.sln into Visual Studio.
Select the build configuration, debug or release.
Build the solution.

Building the managed assembly.

Before building the managed assembly you must first edit Assemblies/SonyNP/copybuilds.bat and make the following changes...
Set the UNITY_PROJECT_PATH var to where the assembly should be copied to, this should be the root of your Unity project.

Navigate to the assembly project and load the SonyNP.sln into MonoDevelop. You must use MonoDevelop, not Visual Studio for this otherwise the assembly will not work with Unity.

After building the assembly the resulting DLL is automatically copied to the example project.

This is an example native plugin for Unity that provides a wrapper to SCE's NPToolkit libraries and functionality. Full native (C++) and managed (C#) source code is provided.
Please note that this example project should not be expected to be fully TRC compliant. Planning for TRC compliance should be done early in your project to minimize risk.
The source code is provided as is : you are free to extend / specialize / amend as your project requires. 
The Unity for PlayStation Development Team will also welcome submissions / suggestions for alterations to source code if they have general ongoing utility for other developers.