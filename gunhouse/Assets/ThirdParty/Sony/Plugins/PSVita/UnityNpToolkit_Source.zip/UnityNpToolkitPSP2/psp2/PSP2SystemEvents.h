#pragma once

#include <apputil.h>
#include <appmgr.h>
#include "PlayerInterface/UnityEventQueue.h"

// App events...

// SCE_APPUTIL_APPEVENT_TYPE_SCREENSHOT_NOTIFICATION.
struct PSP2OnAppEventScreenShot { SceAppUtilAppEventParam params; };
REGISTER_EVENT_ID(0xeca5ae80f4524a99ULL,0xb5900a043edbfa22ULL, PSP2OnAppEventScreenShot);

// SCE_APPUTIL_APPEVENT_TYPE_NP_INVITE_MESSAGE
struct PSP2OnAppEventNpInviteMessage { SceAppUtilAppEventParam params; };
REGISTER_EVENT_ID(0x7814797e726f49e7ULL,0xa29070f22fe140dbULL, PSP2OnAppEventNpInviteMessage);

// SCE_APPUTIL_APPEVENT_TYPE_NP_APP_DATA_MESSAGE
struct PSP2OnAppEventNpDataMessage { SceAppUtilAppEventParam params; };
REGISTER_EVENT_ID(0x3f8fc3ffbebd42c6ULL,0x88fba994f0d1b464ULL, PSP2OnAppEventNpDataMessage);

// SCE_APPUTIL_APPEVENT_TYPE_NEAR_GIFT
struct PSP2OnAppEventNearGiftMessage { SceAppUtilAppEventParam params; };
REGISTER_EVENT_ID(0x18e379392bb9445fULL,0xbacb0cc882b8a0c4ULL, PSP2OnAppEventNearGiftMessage);

// SCE_APPUTIL_APPEVENT_TYPE_LIVEAREA
struct PSP2OnAppEventLiveAreaMessage { SceAppUtilAppEventParam params; };
REGISTER_EVENT_ID(0x30a194d8d5da4980ULL,0xa8cd8782b81a9234ULL, PSP2OnAppEventLiveAreaMessage);

// SCE_APPUTIL_APPEVENT_TYPE_NP_ACTIVITY
struct PSP2OnAppEventNpActivity { SceAppUtilAppEventParam params; };
REGISTER_EVENT_ID(0x8419b5c3d89f4a06ULL,0x8312ee0f1c6b2ceaULL, PSP2OnAppEventNpActivity);

// SCE_APPUTIL_APPEVENT_TYPE_TELEPORT
struct PSP2OnAppEventTeleport { SceAppUtilAppEventParam params; };
REGISTER_EVENT_ID(0x983ce23e11e64dcdULL,0xb07cd781da90830bULL, PSP2OnAppEventTeleport);

// SCE_APPUTIL_APPEVENT_TYPE_SESSION_INVITATION
struct PSP2OnAppEventSessionInvite { SceAppUtilAppEventParam params; };
REGISTER_EVENT_ID(0x2ae9963c8ea3428eULL,0xbb0e9c1de6eca3a3ULL, PSP2OnAppEventSessionInvite);

// SCE_APPUTIL_APPEVENT_TYPE_GAME_CUSTOM_DATA
struct PSP2OnAppEventGameCustomData { SceAppUtilAppEventParam params; };
REGISTER_EVENT_ID(0x28b20df52e0f4128ULL,0xb092405910360ad3ULL, PSP2OnAppEventGameCustomData);

// System events...

// SCE_APPMGR_SYSTEMEVENT_ON_RESUME.
struct PSP2OnResume { SceAppMgrSystemEvent event; };
REGISTER_EVENT_ID(0xb01f45e2615a449fULL,0x8eaee82201ee553fULL,PSP2OnResume);

// SCE_APPMGR_SYSTEMEVENT_ON_NP_MESSAGE_ARRIVED.
struct PSP2OnNpMessage { SceAppMgrSystemEvent event; };
REGISTER_EVENT_ID(0x00f91ff2716b4255ULL,0xaa311c1b2072ee94ULL,PSP2OnNpMessage);

// SCE_APPMGR_SYSTEMEVENT_ON_STORE_PURCHASE.
struct PSP2OnStorePurchase { SceAppMgrSystemEvent event; };
REGISTER_EVENT_ID(0x419867f5b3594d15ULL,0xa0cd0a3677144d89ULL,PSP2OnStorePurchase);

// SCE_APPMGR_SYSTEMEVENT_ON_STORE_REDEMPTION.
struct PSP2OnStoreRedemption { SceAppMgrSystemEvent event; };
REGISTER_EVENT_ID(0xd9b92b20e7614fd5ULL,0x9685516037159eeeULL,PSP2OnStoreRedemption);
