#ifndef _NETCTLSTATUS_H
#define _NETCTLSTATUS_H

#include "UnityNP.h"

namespace UnityPlugin
{
	extern int gNetCtlStatusCallbackID;
	extern ResultCode gConnectionError;

	void RegisterNetCtlStatusCallback();
}

#endif
