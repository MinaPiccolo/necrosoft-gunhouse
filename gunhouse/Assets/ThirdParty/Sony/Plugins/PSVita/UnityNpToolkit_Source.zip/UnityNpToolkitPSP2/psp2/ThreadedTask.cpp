#include <kernel.h>
#include "ThreadedTask.h"

namespace UnityPlugin
{

ThreadedTask::ThreadedTask()
	: m_tid(-1)
{
}

int ThreadedTask::ThreadStart(const char* name, SceKernelThreadEntry threadFunc, int stackSize, int priority, int affinity)
{
	int returnCode = sceKernelCreateThread(name, threadFunc, priority, stackSize, 0, affinity, SCE_NULL);
	if (returnCode < SCE_OK)
	{
		printf("Error: sceKernelCreateThread %08x\n", returnCode);
		return returnCode;
	}
	SetTid(returnCode);

	void* arg = this;
	returnCode = sceKernelStartThread(m_tid, sizeof(arg), (const void*)&arg);
	if (returnCode < SCE_OK)
	{
		printf("Error: sceKernelStartThread %08x\n", returnCode);
	}
	return returnCode;
}

int ThreadedTask::ThreadEnd(int errorCode)
{
	SetTid(-1);
	sceKernelExitDeleteThread(errorCode);
	return errorCode;
}

bool ThreadedTask::IsBusy()
{
	return m_tid != -1;
}

void ThreadedTask::SetTid(SceUID tid)
{
	UnityPlugin::SimpleLock::AutoLock lock(m_Lock);
	m_tid = tid;
}

} // namespace UnityPlugin
