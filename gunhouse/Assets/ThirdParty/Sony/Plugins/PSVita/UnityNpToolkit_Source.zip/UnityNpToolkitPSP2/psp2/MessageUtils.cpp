#include "UnityNP.h"
#include "MessagePipe.h"
#include "ErrorCodesSony.h"
#include "MessageUtils.h"

#define WEBAPI_HEAP_SIZE (16 * 1024)

GetMsgAttachmentThread::GetMsgAttachmentThread()
	: m_Done(false)
	, m_ReadSize(0)
{
	m_Buffer = (SceChar8*)malloc(kRecvBufferSize);
}

GetMsgAttachmentThread::~GetMsgAttachmentThread()
{
	free(m_Buffer);
}

bool GetMsgAttachmentThread::PollForCompletion()
{
	bool isDone = m_Done;
	m_Done = false;
	return isDone;
}

int GetMsgAttachmentThread::StartGetAttachment(const SceAppUtilSessionInvitationParam& inviteParam)
{
	m_InviteParam = inviteParam;
	m_ReadSize = 0;
	InitWebAPI();
	return ThreadStart("GetMsgAttachmentThread", ThreadFunc, kThreadStackSize);
}

SceChar8* GetMsgAttachmentThread::GetAttachmentData() const
{
	return m_Buffer;
}

size_t GetMsgAttachmentThread::GetAttachmentSize() const
{
	return m_ReadSize;
}

int GetMsgAttachmentThread::InitWebAPI()
{
	int ret;

	if ((ret = sceSysmoduleIsLoaded(SCE_SYSMODULE_NP_WEBAPI)) == SCE_SYSMODULE_ERROR_UNLOADED)
	{
		if ((ret = sceSysmoduleLoadModule(SCE_SYSMODULE_NP_WEBAPI)) < 0)
		{
			UnityPlugin::Messages::LogError("Failed to load Np WebApi module (0x%08x)\n", ret);
			return -1;
		}
	}

	ret = sceNpWebApiInitialize(WEBAPI_HEAP_SIZE);
	if (ret < 0 && ret != SCE_NP_WEBAPI_ERROR_ALREADY_INITIALIZED)
	{

		UnityPlugin::Messages::LogError("sceNpWebApiInitialize error (0x%08x)\n", ret);
		return -1;
	}

	return 0;
}

SceInt32 GetMsgAttachmentThread::ThreadFunc(SceSize args, void* argc)
{
	GetMsgAttachmentThread* thread = *(GetMsgAttachmentThread**)argc;
	return thread->GetAttachement();
}

int GetMsgAttachmentThread::GetAttachement()
{
	int32_t ret = SCE_OK;
	int32_t readSize = 0;

	char apiGroup[] = "sessionInvitation";	// API group is "sessionInvitation"
	char uri[128] = {0};	/// Set obtain invitation data URI.
	SceNpId npId = {0};
	int64_t requestId = -1;
	SceNpWebApiContentParameter contentParameter = {0};
	SceNpWebApiHttpMethod method = SCE_NP_WEBAPI_HTTP_METHOD_GET;

	memset(m_Buffer, 0, kRecvBufferSize);

	// Obtain the user's own NP ID
	ret = sceNpManagerGetNpId(&npId);
	if (ret != 0)
	{
		UnityPlugin::Messages::LogError("sceNpManagerGetNpId() failed: ret = 0x%x\n", ret);
		return ThreadEnd(ret);
	}
	snprintf(uri, sizeof(uri), "/v1/users/%s/invitations/%s/invitationData", npId.handle.data, m_InviteParam.invitationId.data);

	// Create the request and send it.
	ret = sceNpWebApiCreateRequest(apiGroup, uri, method, &contentParameter, &requestId);
	if (ret < 0)
	{
		UnityPlugin::Messages::LogError("sceNpWebApiCreateRequest() failed: ret = 0x08%x\n", ret);
		if (requestId != -1) { sceNpWebApiDeleteRequest(requestId); }
		return ThreadEnd(ret);
	}

	ret = sceNpWebApiSendRequest2(requestId, NULL, 0, NULL);
	if (ret < 0)
	{
		UnityPlugin::Messages::LogError("sceNpWebApiSendRequest2() failed: ret = 0x%x\n", ret);
		sceNpWebApiDeleteRequest(requestId);
		return ThreadEnd(ret);
	}

	readSize = sceNpWebApiReadData(requestId, m_Buffer, kRecvBufferSize);
	if (readSize < 0)
	{
		ret = readSize;
		UnityPlugin::Messages::LogError("sceNpWebApiIntReadData() failed: ret = 0x%x\n", ret);
		sceNpWebApiDeleteRequest(requestId);
		return ThreadEnd(ret);
	}
	else
	{
		ret = readSize;
		m_ReadSize = readSize;
	}

	sceNpWebApiDeleteRequest(requestId);

	m_Done = true;
	return ThreadEnd(ret);
}

GetMsgAttachmentThread g_GetMsgAttachmentThreaded;
