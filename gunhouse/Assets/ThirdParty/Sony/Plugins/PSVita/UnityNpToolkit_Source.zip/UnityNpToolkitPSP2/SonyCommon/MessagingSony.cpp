#include "MessagingSony.h"
#include "MatchingSony.h"
#include "MessagePipe.h"
#include "ErrorCodesSony.h"
#include "SignInSony.h"
#include "../psp2/MessageUtils.h"


using namespace sce::Toolkit::NP;
using namespace sce::Toolkit::NP::Utilities;

extern IPluginSceNpParams* g_ISceNpParams;

namespace UnityPlugin
{

	extern std::string gSessionImageFilePath;

	CachedMessaging gMessaging;

	char CachedMessaging::sUnityMessageMagic[8] = {'U', 'n', 'i', 't', 'y', 'M', 's', 'g'};

	enum UnityPluginMessageType
	{
		MESSAGE_TYPE_GAME_INVITE,
		MESSAGE_TYPE_GAME_DATA,
	};

	struct UnityPluginMessageHeader
	{
		char magic[8];
		UnityPluginMessageType messageType;
		int dataSize;
	};

	DO_EXPORT( bool, PrxMessagingIsBusy ) ()
	{
		return gMessaging.IsBusy();
	}

	DO_EXPORT( bool, PrxMessagingSendMessage ) (const MsgRequest* request)	//const char* body, int expireMinutes, void* data, int dataSize)
	{
		return gMessaging.SendMessage(request);	//body, expireMinutes, data, dataSize);
	}

	DO_EXPORT( bool, PrxMessagingSendGameInvite ) (const MsgRequest* request)	//const char* body, int expireMinutes, void* data, int dataSize)
	{
		return gMessaging.SendGameInvite(request);	//body, expireMinutes, data, dataSize);
	}
	DO_EXPORT( bool, PrxMessagingSendInGameDataMessage ) (const unsigned char* npID, void* data, int dataSize)
	{
		return gMessaging.SendInGameDataMessage(npID, data, dataSize);
	}
	DO_EXPORT( bool, PrxMessagingShowMessageDialog ) ()
	{
		return gMessaging.ShowArrivedMessageDialog();
	}

	DO_EXPORT( bool, PrxMessagingShowInviteDialog ) ()
	{
		return gMessaging.ShowArrivedInviteDialog();
	}
	DO_EXPORT( bool, PrxMessagingGetMessageAttachment ) (MessageAttachment* attachment)
	{
		return gMessaging.GetMessageAttachement(attachment);
	}

	DO_EXPORT( bool, PrxMessagingGetGameInviteAttachment) (MessageAttachment* attachment)
	{
		return gMessaging.GetGameInviteAttachement(attachment);
	}

	DO_EXPORT( bool, PrxHasInGameDataMessage ) ()
	{
		return gMessaging.HasInGameDataMessages();
	}

	DO_EXPORT( bool, PrxGetFirstInGameDataMessage ) (InGameDataMessage* message)
	{
		return gMessaging.GetFirstInGameDataMessage(message);
	}

	DO_EXPORT( bool, PrxRemoveFirstInGameDataMessage ) ()
	{
		return gMessaging.RemoveFirstInGameDataMessage();
	}

	DO_EXPORT( bool, PrxMessagingGetPlayTogetherParams ) (PlayTogether* playTogether)
	{
#if __ORBIS__ && (SCE_ORBIS_SDK_VERSION > 0x03500000u)
		return gMessaging.GetPlayTogetherParams(playTogether);
#else
		return false;
#endif
	}

	CachedMessaging::CachedMessaging()
		: m_Busy(false)
		, m_SessionInviteMessageAttachment(NULL)
		, m_GameInviteAttachment(NULL)
		, m_MessageAttachment(NULL)
	{
		InitMessage();

		m_FutureAttachment = new sce::Toolkit::NP::Utilities::Future<sce::Toolkit::NP::MessageAttachment>();
	}

	CachedMessaging::~CachedMessaging()
	{
		Mutex::AutoLock lock(m_Lock);
		free(m_Message.attachment);
		delete m_SessionInviteMessageAttachment;
		delete m_GameInviteAttachment;
		delete m_MessageAttachment;
	}

	void	CachedMessaging::InitMessage( void )
	{
		//	m_Message is of type sce::Toolkit::NP::MessageData
		//	On PS3 this contains non-POD types (STL list)
		//	We must therefore initialize carefully and cannot use memset on a struct with non-POD data elements
#if   PSP2_USING_WEBAPI
		// Re-initialise using the MessageData constructor, don't use memset.
		m_Message = MessageData();
#else
		memset(&m_Message,0,sizeof(MessageData));
#endif

	}

	void InGameMessageFIFO::Add(InGameDataMessage& gameDataMsg)
	{
		SimpleLock::AutoLock lock(m_Lock);
		m_FIFO.push_back(gameDataMsg);
	}

	bool InGameMessageFIFO::HasData()
	{
		SimpleLock::AutoLock lock(m_Lock);
		return !m_FIFO.empty();
	}

	bool InGameMessageFIFO::GetFirst(InGameDataMessage* gameDataMsg)
	{
		SimpleLock::AutoLock lock(m_Lock);
		if(!m_FIFO.empty())
		{
			*gameDataMsg = m_FIFO.front();
			return true;
		}

		return false;
	}

	bool InGameMessageFIFO::RemoveFirst()
	{
		SimpleLock::AutoLock lock(m_Lock);
		if(!m_FIFO.empty())
		{
			InGameDataMessage img = m_FIFO.front();
			free(img.data);
			m_FIFO.pop_front();
			return true;
		}

		return false;
	}

	void InGameMessagePendingFIFO::Add(int gameDataMsgID)
	{
		SimpleLock::AutoLock lock(m_Lock);
		m_FIFO.push_back(gameDataMsgID);
	}

	bool InGameMessagePendingFIFO::HasData()
	{
		SimpleLock::AutoLock lock(m_Lock);
		return !m_FIFO.empty();
	}

	bool InGameMessagePendingFIFO::GetFirst(int* gameDataMsgID)
	{
		SimpleLock::AutoLock lock(m_Lock);
		if(!m_FIFO.empty())
		{
			*gameDataMsgID = m_FIFO.front();
			return true;
		}

		return false;
	}

	bool InGameMessagePendingFIFO::RemoveFirst()
	{
		SimpleLock::AutoLock lock(m_Lock);
		if(!m_FIFO.empty())
		{
			m_FIFO.pop_front();
			return true;
		}

		return false;
	}
	#define GETCOMMID attachment->getCommId().data
	bool CachedMessaging::ProcessEvent(const sce::Toolkit::NP::Event& event)
	{
		Mutex::AutoLock lock(m_Lock);
		bool handled = false;
		//int ret;

		switch(event.event)
		{
			case Event::messageSent:						// An event generated when a message has been sent.
				switch(event.returnCode)
				{
					case SCE_TOOLKIT_NP_SUCCESS:
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingSent);
						break;

					case 1:
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingCanceled);
						break;

					default:
						UnityPlugin::Messages::LogWarning("messageSent unknown return code - %s\n", LookupSceErrorCode(event.returnCode));
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingNotSent);
						break;
				}

				free(m_Message.attachment);
				m_Message.attachment = NULL;
				m_Message.attachmentSize = 0;

				m_Busy = false;
				handled = true;
				break;
			case Event::messageError:						// An event generated when a message failed to be received or sent. 
				// If the error is SCE_NP_BASIC_ERROR_BUSY then most likely the sending frequency is too high. SCE set limits on how often you can send a message.
				if(event.returnCode == SCE_NP_BASIC_ERROR_BUSY)
				{
					// Busy. Tokens have been used up.
					Messages::AddMessage(Messages::kNPToolKit_MessagingNotSentFreqTooHigh);
				}
				else
				{
					Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(event.returnCode));
				}
	
				m_Busy = false;
				handled = true;
				break;

			case Event::messageRetrieved:					// An event generated when a message attachment has been retrieved.
				if(m_FutureAttachment->getError() != SCE_TOOLKIT_NP_SUCCESS)
				{
					Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(m_FutureAttachment->getError()));
				}
				else
				{
					sce::Toolkit::NP::MessageAttachment* attachment = m_FutureAttachment->get();


					UnityPlugin::Messages::Log("messageRetrieved - %p, %d", attachment->getAttachmentData(), attachment->getAttachmentSize());
					UnityPlugin::Messages::Log("messageRetrieved - %p, %d, %s", attachment->getAttachmentData(), attachment->getAttachmentSize(), GETCOMMID );
					UnityPluginMessageHeader* header = (UnityPluginMessageHeader*)m_FutureAttachment->get()->getAttachmentData();
					if(memcmp(header->magic, sUnityMessageMagic, sizeof(header->magic)) == 0)
					{
						size_t dataSize = header->dataSize;
						SceChar8* data = (SceChar8*)(header + 1);

						switch(header->messageType)
						{
							case MESSAGE_TYPE_GAME_INVITE:
								{
									UnityPlugin::Messages::Log("messageRetrieved unityICD - %p, %d, %s", data, dataSize, GETCOMMID);


									delete m_GameInviteAttachment;
									m_GameInviteAttachment = new sce::Toolkit::NP::MessageAttachment();
									m_GameInviteAttachment->setAttachmentData(data, dataSize);
									m_GameInviteAttachment->setCommunicationID(attachment->getCommId());

									UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingCustomInviteRetrieved);
								}
								break;

							case MESSAGE_TYPE_GAME_DATA:
								{
									UnityPlugin::Messages::Log("messageRetrieved unityCD - %p, %d, %s", data, dataSize, GETCOMMID);

									delete m_MessageAttachment;
									m_MessageAttachment = new sce::Toolkit::NP::MessageAttachment();
									m_MessageAttachment->setAttachmentData(data, dataSize);
									m_MessageAttachment->setCommunicationID(attachment->getCommId());
									UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingDataMessageRetrieved);
								}
								break;

							default:
								UnityPlugin::Messages::LogError("messageRetrieved - Unknown message attachment type %d", header->messageType);
								break;
						}
					}
					else
					{
						// Assume it's a session invite.
						m_SessionInviteMessageAttachment = new sce::Toolkit::NP::MessageAttachment();
						m_SessionInviteMessageAttachment->setAttachmentData(attachment->getAttachmentData(), attachment->getAttachmentSize());
						m_SessionInviteMessageAttachment->setCommunicationID(attachment->getCommId());
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingSessionInviteRetrieved);	// trigger a OnSessionInviteMessageRetrieved event
					}
				}
				m_Busy = false;
				handled = true;
				break;

			case Event::messageDialogTerminated:			// An event generated when a message dialog box is terminated.
				m_Busy = false;
				handled = true;
				break;

			case Event::messageInGameDataReceived:			// An event generated when an in-game data message has been received.
				if(event.returnCode < 0)
				{
					Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(event.returnCode));
				}

				m_InGameDataMessagePendingFIFO.Add(event.returnCode);

				handled = true;
				break;

			case Event::messageInGameDataRetrievalDone:		// An event generated when an in-game data message has been retrieved.
				if(event.returnCode != SCE_TOOLKIT_NP_SUCCESS)
				{
					Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(event.returnCode));
				}

				{
					sce::Toolkit::NP::ReceivedInGameDataMessage& msg = *m_FutureInGameDataMessageRecieved.get();
	
					InGameDataMessage igmMsg;
					igmMsg.messageID = msg.messageId;
					igmMsg.npID = (unsigned char*)&msg.from;
					igmMsg.npIDSize = sizeof(SceNpId);
					igmMsg.dataSize = msg.message.dataSize;
					igmMsg.data = malloc(SCE_NP_BASIC_IN_GAME_MESSAGE_SIZE_MAX);
					memcpy(igmMsg.data, msg.message.data, SCE_NP_BASIC_IN_GAME_MESSAGE_SIZE_MAX);
					m_InGameDataMessageFIFO.Add(igmMsg);
				}

				Messages::AddMessage(Messages::kNPToolKit_MessagingInGameDataMessageRetrieved);

				m_Busy = false;
				handled = true;
				break;

 
			default:
				UnityPlugin::Messages::LogWarning("Unexpected event from messaging service: event=%d\n", event.event);
				handled = true;
				break;
		}

		return handled;
	}

	void CachedMessaging::ProcessInviteAttachement(SceChar8* data, size_t size)
	{
		m_SessionInviteMessageAttachment = new sce::Toolkit::NP::MessageAttachment();
		m_SessionInviteMessageAttachment->setAttachmentData(data, size);
		m_SessionInviteMessageAttachment->setCommunicationID(*(SceNpCommunicationId*)g_ISceNpParams->NpCommunicationsID());

		// Trigger a OnSessionInviteMessageRetrieved event.
		UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingSessionInviteRetrieved);
	}

	bool CachedMessaging::ProcessSystemEvent(SceAppMgrSystemEvent& event)
	{
		bool handled = false;

		switch(event.systemEvent)
		{
		case SCE_APPMGR_SYSTEMEVENT_ON_NP_MESSAGE_ARRIVED:
			UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_SysNpMessageArrived);
			handled = true;
			break;
		}

		return handled;
	}

	bool CachedMessaging::ProcessApplicationEvent(SceAppUtilAppEventParam& eventParam)
	{
		bool handled = false;
		int32_t ret;

		switch(eventParam.type)
		{
		case SCE_APPUTIL_APPEVENT_TYPE_NP_INVITE_MESSAGE:
			UnityPlugin::Messages::Log("Got app event - np invite message: %d", eventParam.type);
			ret = Messaging::Interface::retrieveMessageAttachment(&eventParam, m_FutureAttachment);
			if (ret != SCE_TOOLKIT_NP_SUCCESS)
			{
				UnityPlugin::Messages::LogError("Failed to retrieve attachment for NP invite message: 0x%08x", ret);
			}
			handled = true;
			break;

		case SCE_APPUTIL_APPEVENT_TYPE_NP_APP_DATA_MESSAGE:
			UnityPlugin::Messages::Log("Got app event - data message: %d", eventParam.type);
			ret = Messaging::Interface::retrieveMessageAttachment(&eventParam, m_FutureAttachment);
			if (ret != SCE_TOOLKIT_NP_SUCCESS)
			{
				UnityPlugin::Messages::LogError("Failed to retrieve attachment for data message: 0x%08x", ret);
			}
			handled = true;
			break;

		case SCE_APPUTIL_APPEVENT_TYPE_SESSION_INVITATION:
			// Game was booted by the messaging app as a result of accepting a session invite message.
			UnityPlugin::Messages::Log("Got app event - session invitation: %d", eventParam.type);
#if(0)
			// Why doesn't this work?
			//
			// It seems that the attachement sent by Matching::Interface::inviteToSession() is missing a 32bit type identifier
			// on the front so npToolkit doesn't recognize it. So, we have to retrieve the attachment ourselves and then add
			// the identifier before passing it into any np functions that neede it, e.g. Matching::Interface::joinInvitedSession()
			//
			ret = Messaging::Interface::retrieveMessageAttachment(&eventParam, m_FutureAttachment);
			if (ret != SCE_TOOLKIT_NP_SUCCESS)
			{
				UnityPlugin::Messages::LogError("Failed to retrieve attachment for session invitation: 0x%08x", ret);
			}
#else
			SceAppUtilSessionInvitationParam sessionInvitationParam;
			memset(&sessionInvitationParam, 0, sizeof(SceAppUtilSessionInvitationParam));

			// Parse SceAppUtilSessionInvitationParam and get result values.
			ret = sceAppUtilAppEventParseSessionInvitation(&eventParam, &sessionInvitationParam);
			if ((ret != SCE_OK) || (strlen(sessionInvitationParam.sessionId.data) == 0))
			{
				UnityPlugin::Messages::LogError("sceAppUtilAppEventParseSessionInvitation ret = 0x%08x", ret);
			}

			// Retrieve the attachement data (asynchronous).
			if (strlen(sessionInvitationParam.invitationId.data))
			{
				g_GetMsgAttachmentThreaded.StartGetAttachment(sessionInvitationParam);
			}
#endif
			handled = true;
			break;

		case SCE_APPUTIL_APPEVENT_TYPE_NP_ACTIVITY:
#if !PSP2_USING_WEBAPI
		case SCE_APPUTIL_APPEVENT_TYPE_NP_BASIC_JOINABLE_PRESENCE:
#endif
			UnityPlugin::Messages::LogWarning("Application NP event not handled = %d", eventParam.type);
			handled = true;
			break;
		}

		return handled;
	}

	bool CachedMessaging::IsBusy()
	{
		Mutex::AutoLock lock(m_Lock);
		return m_Busy;
	}
	bool CachedMessaging::SendInGameDataMessage(const unsigned char* npID, void* data, int dataSize)
	{
		Mutex::AutoLock lock(m_Lock);

		if(dataSize > SCE_NP_BASIC_IN_GAME_MESSAGE_SIZE_MAX)
		{
			Messages::LogError("Messaging::%s@L%d - data size > %d bytes", __FUNCTION__, __LINE__, SCE_NP_BASIC_IN_GAME_MESSAGE_SIZE_MAX);
			return false;
		}
		
		sce::Toolkit::NP::InGameDataMessage igm;
		memcpy(&igm.npId, npID, sizeof(SceNpId));
		igm.platformType = SCE_NP_PLATFORM_TYPE_VITA;
		memcpy(&igm.message.data, data, dataSize);
		igm.message.dataSize = dataSize;

		int ret = Messaging::Interface::sendInGameMessage(&igm);
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}

		m_Busy = true;
		return true;
	}

	bool CachedMessaging::SendMessage(const MsgRequest* request)
	{
		void* data = request->data;
		int dataSize = request->dataSize;

		if(data == NULL)
		{
			static char noData[] = "No data";
			data = noData;
			dataSize = strlen(noData)+1;
		}

		InitMessage();
		m_Message.body = request->body;
		m_Message.expireMinutes = request->expireMinutes;
		int ret;

#if __ORBIS__ || PSP2_USING_WEBAPI
		m_Message.dialogFlag = SCE_TOOLKIT_NP_DIALOG_TYPE_USER_EDITABLE;
		m_Message.dataDescription = request->dataDescription;
		m_Message.dataName = request->dataName;
		m_Message.npIds = NULL;		// Array of npIDs to send the message to.
		m_Message.npIdsCount = request->npIDCount;	// Number of IDs that can be selected in the message dialog, or if npIds != NULL the number of IDs in the array.
		m_Message.iconPath = RemapPath(request->iconPath);
		memset(&m_Message.npSessionId, 0, sizeof(m_Message.npSessionId));
#endif
		
		int msgSize = sizeof(UnityPluginMessageHeader) + dataSize;
		SceChar8* buffer = (SceChar8*)malloc(msgSize);
		UnityPluginMessageHeader* msgHeader = (UnityPluginMessageHeader*)buffer;
		SceChar8* msgData = (SceChar8*)(msgHeader + 1);

		memcpy(msgHeader->magic, sUnityMessageMagic, sizeof(msgHeader->magic));
		msgHeader->messageType = MESSAGE_TYPE_GAME_DATA;
		msgHeader->dataSize = dataSize;
		memcpy(msgData, data, dataSize);
		
		m_Message.attachment = buffer;
		m_Message.attachmentSize = msgSize;

		ret = Messaging::Interface::sendMessage(&m_Message,SCE_TOOLKIT_NP_MESSAGE_TYPE_CUSTOM_DATA);
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}

		return true;
	}

	// Game invite with custom data. NOTE for session invites use CachedMatching::InviteToSession instead.
	bool CachedMessaging::SendGameInvite(const MsgRequest* request)
	{
		void* data = request->data;
		int dataSize = request->dataSize;
		int expireMinutes = request->expireMinutes;

		if(data == NULL)
		{
			static char noData[] = "No data";
			data = noData;
			dataSize = strlen(noData)+1;
		}

		if(request->expireMinutes <= 0)		// Invites MUST have an expiry time > 0.
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, "expireMinutes invalid");
			expireMinutes = 30;
		}

		InitMessage();
		m_Message.body = request->body;
		m_Message.expireMinutes = expireMinutes;
		int msgSize = sizeof(UnityPluginMessageHeader) + dataSize;
		SceChar8* buffer = (SceChar8*)malloc(msgSize);
		UnityPluginMessageHeader* msgHeader = (UnityPluginMessageHeader*)buffer;
		SceChar8* msgData = (SceChar8*)(msgHeader + 1);

		memcpy(msgHeader->magic, sUnityMessageMagic, sizeof(msgHeader->magic));
		msgHeader->messageType = MESSAGE_TYPE_GAME_INVITE;
		msgHeader->dataSize = dataSize;
		memcpy(msgData, data, dataSize);

		m_Message.attachment = buffer;
		m_Message.attachmentSize = msgSize;
		
		int ret = Messaging::Interface::sendMessage(&m_Message, SCE_TOOLKIT_NP_MESSAGE_TYPE_INVITE, true);
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}

		return true;
	}

	bool CachedMessaging::ShowArrivedInviteDialog()
	{
		int ret = Messaging::Interface::displayReceivedMessages(SCE_TOOLKIT_NP_MESSAGE_TYPE_INVITE);
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}

		return true;
	}

	bool CachedMessaging::ShowArrivedMessageDialog()
	{
		int ret = Messaging::Interface::displayReceivedMessages(SCE_TOOLKIT_NP_MESSAGE_TYPE_CUSTOM_DATA);
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}

		return true;
	}

	sce::Toolkit::NP::MessageAttachment* CachedMessaging::GetSessionInviteAttachment()
	{
		Mutex::AutoLock lock(m_Lock);
		return m_SessionInviteMessageAttachment;
	}

	bool CachedMessaging::GetMessageAttachement(MessageAttachment* attachement)
	{
		Mutex::AutoLock lock(m_Lock);
		if(m_MessageAttachment)
		{
			attachement->data = m_MessageAttachment->getAttachmentData();
			attachement->dataSize = m_MessageAttachment->getAttachmentSize();
			return true;
		}

		return false;
	}

	bool CachedMessaging::GetGameInviteAttachement(MessageAttachment* attachement)
	{
		Mutex::AutoLock lock(m_Lock);
		if(m_GameInviteAttachment)
		{
			attachement->data = m_GameInviteAttachment->getAttachmentData();
			attachement->dataSize = m_GameInviteAttachment->getAttachmentSize();
			return true;
		}

		return false;
	}

	bool CachedMessaging::HasInGameDataMessages()
	{
		return m_InGameDataMessageFIFO.HasData();
	}

	bool CachedMessaging::GetFirstInGameDataMessage(InGameDataMessage* message)
	{
		return m_InGameDataMessageFIFO.GetFirst(message);
	}

	bool CachedMessaging::RemoveFirstInGameDataMessage()
	{
		return m_InGameDataMessageFIFO.RemoveFirst();
	}

	void CachedMessaging::Update()
	{
		if(m_FutureInGameDataMessageRecieved.isBusy() == false)
		{
			// Process the incoming in-game message FIFO.
			int msgID;
			if(m_InGameDataMessagePendingFIFO.GetFirst(&msgID))
			{
				m_InGameDataMessagePendingFIFO.RemoveFirst();
				int ret = sce::Toolkit::NP::Messaging::Interface::retrieveInGameMessage(msgID, &m_FutureInGameDataMessageRecieved);
				if(ret < 0)
				{
					Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
					m_Busy = false;
				}
			}
		}
	}

	// Retreive the message attachment from the invite message
	// ... will trigger a Event::messageRetrieved if successful
	// retrieveMessageAttachmentFromEvent() only exists on PS4

	void CachedMessaging::DumpSessionInviteMessageAttachment(SceChar8* messageData)
	{
		printf("dumping session invite message attachment\n");
		SessionInformation *sessionInfo = (SessionInformation *)messageData;	// only the data upto sessionAttributes is valid
		SessionInformation sessionCopy;
		size_t sessionAttribOffset = ((size_t)&sessionInfo->sessionAttributes - (size_t)&sessionInfo->sessionName) + sizeof(SceInt);

		memcpy(&sessionCopy, sessionInfo, sessionAttribOffset);

		printf("session name :%s\n", sessionInfo->sessionName);
		printf("numMembers:%d numSessionAttributes:%d\n", sessionInfo->numMembers, sessionInfo->numSessionAttributes);
			
		sce::Toolkit::NP::SessionAttribute *sessionAttributes = (sce::Toolkit::NP::SessionAttribute *)(messageData+sessionAttribOffset);
		for (int i=0; i<sessionInfo->numSessionAttributes; i++)
		{
			printf("Session Attribute %d, %s\n", i, sessionAttributes[i].attribute);
			sessionCopy.sessionAttributes.push_back(sessionAttributes[i]);
		}

		int memberOffset=sessionAttribOffset + (sessionInfo->numSessionAttributes * sizeof(sce::Toolkit::NP::SessionAttribute));
		for (int i=0; i<sessionInfo->numMembers; i++)
		{
			SessionMember *sessionMember = (SessionMember *)(messageData+memberOffset);
			SessionMember memberCopy;
			memcpy(&memberCopy, sessionMember, sizeof(SessionMember)- sizeof(SessionAttributeList));
			printf("member %d, %s\n",i, (char *)&sessionMember->userInfo);


			memberOffset += sizeof(SessionMember)- sizeof(SessionAttributeList);
			SceInt numMemAttributes;
			memcpy(&numMemAttributes, messageData+memberOffset, sizeof(SceInt));
			memberOffset += sizeof(SceInt);
			printf(" #Member Attributes:%d\n", numMemAttributes);
			sce::Toolkit::NP::SessionAttribute *memberAttributes = (sce::Toolkit::NP::SessionAttribute*) (messageData+memberOffset);
			for (int j=0; j<numMemAttributes; j++)
			{
				printf("attrib %d, %s\n", j, memberAttributes[j].attribute);
				memberCopy.memberAttributes.push_back(memberAttributes[j]);
			}
				
			sessionCopy.memberData.push_back(memberCopy);
			memberOffset+= (sizeof(sce::Toolkit::NP::SessionAttribute) * numMemAttributes );
		}
		
	}

}
