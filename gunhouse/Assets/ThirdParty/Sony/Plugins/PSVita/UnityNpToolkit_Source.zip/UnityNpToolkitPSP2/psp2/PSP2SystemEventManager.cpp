#if defined(GLOBAL_EVENT_QUEUE)
#include <appmgr.h>
#include "UnityNP.h"

#include "PlayerInterface/UnityEventQueue.h"
#include "PSP2SystemEvents.h"
#include "PSP2SystemEventManager.h"

#include "MessagePipe.h"
#include "MessagingSony.h"
#include "CommerceSony.h"

namespace UnityPlugin
{
	// System events...
	UnityEventQueue::ClassBasedEventHandler<PSP2OnResume, PSP2SystemEventManager>           g_OnResumeAdapter;
	UnityEventQueue::ClassBasedEventHandler<PSP2OnNpMessage, PSP2SystemEventManager>        g_OnNpMessageAdapter;
	UnityEventQueue::ClassBasedEventHandler<PSP2OnStorePurchase, PSP2SystemEventManager>    g_OnStorePurchase;
	UnityEventQueue::ClassBasedEventHandler<PSP2OnStoreRedemption, PSP2SystemEventManager>  g_OnStoreRedemption;

	// App events...
	UnityEventQueue::ClassBasedEventHandler<PSP2OnAppEventNpInviteMessage, PSP2SystemEventManager>  g_OnAppEventNpInviteMessage;
	UnityEventQueue::ClassBasedEventHandler<PSP2OnAppEventNpDataMessage, PSP2SystemEventManager>	g_OnAppEventNpDataMessage;
	UnityEventQueue::ClassBasedEventHandler<PSP2OnAppEventNpActivity, PSP2SystemEventManager>		g_OnAppEventNpActivity;
	UnityEventQueue::ClassBasedEventHandler<PSP2OnAppEventSessionInvite, PSP2SystemEventManager>	g_OnAppEventSessionInvite;
	UnityEventQueue::ClassBasedEventHandler<PSP2OnAppEventGameCustomData, PSP2SystemEventManager>	g_OnAppEventGameCustomData;

	void PSP2SystemEventManager::Initialize(UnityEventQueue::IEventQueue* eventQueue)
	{
		m_EventQueue = eventQueue;

		if (m_EventQueue)
		{
			m_EventQueue->AddHandler(g_OnResumeAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnNpMessageAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnStorePurchase.SetObject(this));
			m_EventQueue->AddHandler(g_OnStoreRedemption.SetObject(this));

			m_EventQueue->AddHandler(g_OnAppEventNpInviteMessage.SetObject(this));
			m_EventQueue->AddHandler(g_OnAppEventNpDataMessage.SetObject(this));
			m_EventQueue->AddHandler(g_OnAppEventNpActivity.SetObject(this));
			m_EventQueue->AddHandler(g_OnAppEventSessionInvite.SetObject(this));
			m_EventQueue->AddHandler(g_OnAppEventGameCustomData.SetObject(this));
		}
	}

	void PSP2SystemEventManager::Shutdown()
	{
		if (m_EventQueue)
		{
			m_EventQueue->RemoveHandler(&g_OnResumeAdapter);
			m_EventQueue->RemoveHandler(&g_OnNpMessageAdapter);
			m_EventQueue->RemoveHandler(&g_OnStorePurchase);
			m_EventQueue->RemoveHandler(&g_OnStoreRedemption);

			m_EventQueue->RemoveHandler(&g_OnAppEventNpInviteMessage);
			m_EventQueue->RemoveHandler(&g_OnAppEventNpDataMessage);
			m_EventQueue->RemoveHandler(&g_OnAppEventNpActivity);
			m_EventQueue->RemoveHandler(&g_OnAppEventSessionInvite);
			m_EventQueue->RemoveHandler(&g_OnAppEventGameCustomData);
		}
	}

	// System events...

	void PropogateSystemEvents(SceAppMgrSystemEvent event)
	{
		// Let any interested parties have a go with the system events.
		if(UnityPlugin::gMessaging.ProcessSystemEvent(event))
		{
			return;
		}
		if(UnityPlugin::gCommerce->ProcessSystemEvent(event))
		{
			return;
		}
	}

	void PSP2SystemEventManager::HandleEvent(PSP2OnResume& data)
	{
		UNITY_TRACE("PSP2SystemEventManager::HandleEvent: PSP2OnResume\n");
		UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_SysResume);
		PropogateSystemEvents(data.event);
	}

	void PSP2SystemEventManager::HandleEvent(PSP2OnNpMessage& data)
	{
		UNITY_TRACE("PSP2SystemEventManager::HandleEvent: PSP2OnNpMessage\n");
		PropogateSystemEvents(data.event);
	}

	void PSP2SystemEventManager::HandleEvent(PSP2OnStorePurchase& data)
	{
		UNITY_TRACE("PSP2SystemEventManager::HandleEvent: PSP2OnStorePurchase\n");
		PropogateSystemEvents(data.event);
	}

	void PSP2SystemEventManager::HandleEvent(PSP2OnStoreRedemption& data)
	{
		UNITY_TRACE("PSP2SystemEventManager::HandleEvent: PSP2OnStoreRedemption\n");
		PropogateSystemEvents(data.event);
	}

	// App events...

	void PropogateAppEvents(SceAppUtilAppEventParam& event)
	{
		// Let any interested parties have a go with the application events.
		UnityPlugin::gMessaging.ProcessApplicationEvent(event);
	}

	void PSP2SystemEventManager::HandleEvent(PSP2OnAppEventNpInviteMessage& data)
	{
		UNITY_TRACE("PSP2SystemEventManager::HandleEvent: PSP2OnAppEventNpInviteMessage\n");
		PropogateAppEvents(data.params);
	}

	void PSP2SystemEventManager::HandleEvent(PSP2OnAppEventNpDataMessage& data)
	{
		UNITY_TRACE("PSP2SystemEventManager::HandleEvent: PSP2OnAppEventNpDataMessage\n");
		PropogateAppEvents(data.params);
	}

	void PSP2SystemEventManager::HandleEvent(PSP2OnAppEventNpActivity& data)
	{
		UNITY_TRACE("PSP2SystemEventManager::HandleEvent: PSP2OnAppEventNpActivity\n");
		PropogateAppEvents(data.params);
	}

	void PSP2SystemEventManager::HandleEvent(PSP2OnAppEventSessionInvite& data)
	{
		UNITY_TRACE("PSP2SystemEventManager::HandleEvent: PSP2OnAppEventSessionInvite\n");
		PropogateAppEvents(data.params);
	}

	void PSP2SystemEventManager::HandleEvent(PSP2OnAppEventGameCustomData& data)
	{
		UNITY_TRACE("PSP2SystemEventManager::HandleEvent: PSP2OnAppEventGameCustomData\n");
		PropogateAppEvents(data.params);
	}
}
#endif
